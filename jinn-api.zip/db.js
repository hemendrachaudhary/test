
//config for Nodeserver
// const mongoose = require("mongoose");
// require("dotenv").config();
// const mongoDBErrors = require("mongoose-mongodb-errors");

// mongoose.Promise = global.Promise;
// mongoose.plugin(mongoDBErrors);
// database = {
//     username: "brain1uMMong0User",
//     password: "PL5qnU9nuvX0pBa",
//     authDb: "admin",
//     port: 27017,
//     host: "nodeserver.mydevfactory.com",
//     dbName: "broji_marketplace"
// } //liveserver
// //mongoose.connect(process.env.MONGOURI,{ useNewUrlParser: true,useUnifiedTopology: true,useFindAndModify: false });
// mongoose.Promise = require('bluebird');
// var options = { useNewUrlParser: true, useUnifiedTopology: true,useFindAndModify: false };
// var connectionString = "mongodb://" + database.username + ":" + database.password + "@" + database.host + ":" +database.port + "/" + database.dbName + "?authSource=" + database.authDb   //live server
// console.log(connectionString);
// //var connectionString = "mongodb://localhost/my_mart"   //local server
// //mongodb://brain1uMMong0User:PL5qnU9nuvX0pBa@nodeserver.mydevfactory.com:27017/broji_marketplace?authSource=admin
// mongoose.connect(connectionString, options);

// // Connected handler
// mongoose.connection.on('connected', function (err) {

//   console.log("Connected to DB using chain: " + database.dbName);//live
//   //console.log("Connected to DB using chain: ");//local


// }); //live

// // mongoose.connection.on('connected', function (err) {

// //   console.log("Connected to DB using chain:");

// // }); //local

// // Error handler
// mongoose.connection.on('error', function (err) {
//   console.log("MongoDB Error: ", err);
// })

//config for Mymartserver

const mongoose = require("mongoose");
require("dotenv").config();
const mongoDBErrors = require("mongoose-mongodb-errors");
const serverConfig = require('./server');
var tunnel = require('tunnel-ssh');

var config = {
    username : 'myMaet',
    host: '15.184.114.208',
    privateKey:require('fs').readFileSync(serverConfig.__key),
    port:22,
    dstPort:27010,
    localPort: 2001,
    dbName: "test",
};

var server = tunnel(config, function (error, server) {

    if(error){
        console.log("SSH connection error: " + error);
    }

    mongoose.Promise = require('bluebird');
    var options = { useNewUrlParser: true, useUnifiedTopology: true,useFindAndModify: false };
    var connectionString = "mongodb://myMaet:myM(A)et2o21@localhost:27017/?authSource=admin&readPreference=primary&appname=MongoDB%20Compass&ssl=false"
    mongoose.connect(connectionString, options);

    var db = mongoose.connection;
    db.on('error', console.error.bind(console, 'DB connection error:'));
    db.once('open', function() {
        console.log("DB connection successful");
    });

});
