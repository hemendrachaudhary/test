const express = require ('express');
require ('express-async-errors');
const cors = require ('cors');
const app = express ();
const mongoose = require ('mongoose');
const bodyParser = require ('body-parser');
const path = require('path');
const https = require('https');
const fs = require('fs');

const cron = require('node-cron');
let shell = require('shelljs');

var socket_io = require("socket.io");
var io = socket_io();
//database connection
require ('./config/db');
const config = require('./config/server');
//Models
require ('./models/ParentCategory');
require ('./models/Users');
require ('./models/Seller');
require ('./models/BankDetails');
require ('./models/AboutContent');
require ('./models/PrivacyContent');
require ('./models/TermsContent');
require ('./models/uploadFiles');
require ('./models/Products');
require ('./models/Brand');
require ('./models/BrandRequest');
require ('./models/ProductType');
require ('./models/Request');
require ('./models/Attribute');
require ('./models/AttributeRequest');
require ('./models/Variation');
require ('./models/Countries');
require ('./models/ProductVariations');
require ('./models/ProductAttributes');
require ('./models/SellerProducts');
require ('./models/SellerProductVariation');
require ('./models/CouponDiscount');
require ('./models/Cart');
require ('./models/UserAddress');
require ('./models/WishList');
require ('./models/DeliveryRule');
require ('./models/Order');
require ('./models/FollowedStore');
require ('./models/RatingsAndReview');
require ('./models/NewsLetter');
require ('./models/Faqs');
require ('./models/LegalNoticeInfo');
require ('./models/ContactUs');
require ('./models/ScheduleProducts');
require ('./models/DeliveryRuleSeller');
require ('./models/PopularCategory');
require ('./models/VoucherClaim');
require ('./models/PopularCategorySeller');
require ('./models/BankNames');
require ('./models/SellerTransaction');
require ('./models/PaymentsMethod');
require ('./models/ReturnsAndRefunds');
require ('./models/ShippingAndDelivery');
require ('./models/Banner');
//Middleware
app.use(bodyParser.json({
  limit: '50mb'
}));

app.use(bodyParser.urlencoded({
  limit: '50mb',
  parameterLimit: 100000,
  extended: true 
}));
app.use (cors ());
app.use("/uploads", express.static(path.join(__dirname, 'uploads')));



//Routes
app.use ('/api/category', require ('./controllers/Category'));
app.use ('/api/brand', require ('./controllers/Brand'));
app.use ('/api/request', require ('./controllers/Request'));
app.use ('/api/productType', require ('./controllers/ProductType'));
app.use ('/api/attribute', require ('./controllers/Attribute'));
app.use ('/api/variation', require ('./controllers/Variation'));
app.use ('/api/product', require ('./controllers/Product'));
app.use ('/api/user', require ('./controllers/User'));
app.use ('/api/userAddress', require ('./controllers/UserAddress'));

app.use ('/api/banner', require ('./controllers/Banner'));
app.use ('/api/couponDiscount', require ('./controllers/CouponDiscount'));
app.use ('/api/content', require ('./controllers/ContentManagement'));
app.use ('/api/sellerProducts', require ('./controllers/SellerProducts'));
app.use ('/api/search', require ('./controllers/Search'));
app.use ('/api/store', require ('./controllers/Stores'));
app.use ('/api/cart', require ('./controllers/Cart'));
app.use ('/api/wishlist', require ('./controllers/Wishlist'));
app.use ('/api/deliveryRule', require ('./controllers/DeliveryRule'));
app.use ('/api/order', require ('./controllers/Order'));
app.use ('/api/followedstore', require ('./controllers/FollowedStore'));
app.use ('/api/ratingReview', require ('./controllers/RatingsAndReview'));
app.use ('/api/faqs', require ('./controllers/Faqs'));
app.use ('/api/contactus', require ('./controllers/ContactUs'));
app.use ('/api/schedule-product', require ('./controllers/ScheduleProducts'));
app.use ('/api/popular-category', require ('./controllers/PopularCategory'));
app.use ('/api/bank', require ('./controllers/Bank'));
app.use ('/api/dashboard', require ('./controllers/Dashboard'));

//Not Found Route
app.use ((req, res, next) => {
  req.status = 404;
  const error = new Error ('404! Routes not found');
  next (error);
});

//Static Folder

//error handler
if (app.get ('env') === 'production') {
  app.use ((error, req, res, next) => {
    res.status (req.status || 500).send ({
      message: error.message,
    });
  });
}

app.use ((error, req, res, next) => {
  res.status (req.status || 500).send ({
    message: error.message,
    stack: error.stack,
  });
});

var port = process.env.PORT || 7779;

/*io.listen(app.listen (port , function () {
  console.log ('Server is runninggg on port: '+ port);
}));*/

https.createServer({
  key: fs.readFileSync(config.__key),
  cert: fs.readFileSync(config.__cert),
  ca: fs.readFileSync(config.__bundle)
}, app)
.listen(port);


/*app.io = io.on("connection", function(socket){
  console.log(socket.handshake.query.userID)
  const id = socket.handshake.query.userID
  socket.join(id)
  io.to(id).emit("welcome", "Hello and welcome to socket.io server" + socket.id)
  console.log("Socket connected: " + socket.id);

  socket.on('disconnect', () => {
   console.log(id+ "Disconnected")


  })
});*/

// CRON JOBS
cron.schedule("0 0 * * *", function(){  //  "0 0 * * *"
  console.log('Scheduler is running...');
  const executeFunc = shell.exec("node ./cron-job/myMartMargin.js");
  console.log("Shell Response ==================>", executeFunc.code);
  if(executeFunc.code !== 0){
    console.log("Something went wrong");
  } else {
    console.log("Everthing Good");
  }
});
