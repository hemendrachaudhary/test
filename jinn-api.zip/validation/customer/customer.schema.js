const joi = require('@hapi/joi');

const schema = {
    customer: joi.object({
        provider: joi.string().max(100),
        provider_id: joi.string().max(100),
        firstname: joi.string().max(100).required(),
        lastname: joi.string().max(100).required(),
        email: joi.string().email().required(),
        username: joi.string().max(50),
        password: joi.string().pattern(new RegExp("^[a-zA-Z0-9]{3,30}$")),
        mobileno: joi.number().integer().min(1000000000).message("Invalid mobile number").max(9999999999).message("Invalid mobile number").required(),
        address1: joi.string().required(),
        address2: joi.string().required(),
        pincode: joi.number().required(),
        state: joi.string().max(50).required(),
        city: joi.string().max(50).required(),
        birthdate: joi.string().required(),
        ssn_number: joi.string().max(7).required(),
        citizenship_type: joi.string().required(),
        investment_experience: joi.string().required(),
        employed_type: joi.string().max(50).required(),
        name_of_employer: joi.string().max(50),
        is_family_member_work: joi.string().max(50).required(),
        photo: joi.string().max(150),
        occupation: joi.string().max(50),
        devicetype: joi.string().max(250),
        deviceToken: joi.string().max(250),
        fcmtoken: joi.string().max(250),
        isactive: joi.number().integer()
    })
};

module.exports = schema;