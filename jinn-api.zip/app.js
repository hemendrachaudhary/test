const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const ServiceDetail = require('./models/service_details');
const Enquiry = require('./models/enquiry');
const BuisnessDetail = require('./models/buisness_detail');
const Rating = require('./models/ratings');
const UserRole = require('./models/user_role');
const Users = require('./models/users');
const BecomePartner = require('./models/become_partner');
const UserServiceDetail = require('./models/user_service_detail');
const WorkingHour = require('./models/working_hours');
const UserNotification = require('./models/user_notification');
const AditionalServices = require('./models/aditional_services'); 
const Message = require('./models/message');

const sequelize = require('./utils/databsse');
const authRoutes = require('./routes/auth');
const apiRoutes = require('./routes/api');
const adminRoutes = require('./routes/admin');

const app = express();
    
app.set('view engine', 'ejs')
app.set('views', 'views')


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname + '/public'));
app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    next();
});
app.use(express.static(path.join(__dirname, "public")));
app.use(express.static(path.join(__dirname, "/uploads")));

app.use(authRoutes);
app.use('/', apiRoutes);
app.use(adminRoutes);

// BuisnessDetail
BuisnessDetail.belongsTo(Users);
//Rating
Rating.belongsTo(Users,{as : 'review_by'});
Rating.belongsTo(Users,{as : 'review_to'});

//messages 
Message.belongsTo(Users,{as : 'message_by'});
Message.belongsTo(Users,{as : 'message_to'});
// Message.belongsTo(Users,{as : 'message_by'});
//Enquiry
Enquiry.belongsTo(Users,{as : 'enquiry_by'});
Enquiry.belongsTo(Users,{as : 'enquiry_to'});
Enquiry.belongsTo(ServiceDetail)
//Notification
UserNotification.belongsTo(Users,{as : 'notify_by'});
UserNotification.belongsTo(Users,{as : 'notify_to'});
//additional service
AditionalServices.belongsTo(Users);
AditionalServices.belongsTo(ServiceDetail);
// BuisnessInformation.belongsTo(ServiceDetail);

BecomePartner.belongsTo(Users);

UserRole.hasOne(Users, {onDelete: 'CASCADE'});
Users.belongsTo(UserRole);
ServiceDetail.belongsToMany(Users, { through: 'user_service_detail'});
WorkingHour.belongsTo(Users);
UserServiceDetail.belongsTo(Users); 




sequelize
  //  .sync({ force: true })
  .sync()
 .then(result => {
    app.listen(3003);
    console.log("connection establist sucesssfully !!!");
 })
 .catch(err => {
     console.log("err ----->", err);
 });

