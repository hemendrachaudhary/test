const Sequelize = require('sequelize');

// const sequelize = new Sequelize('Trading', 'root', 'secret', {
//     dialect: 'postgres', host: '143.110.254.46'
// });

// const sequelize = new Sequelize({
//     database: 'jinnNew',
//     username: 'root',
//     password: 'Admin@123',
//     host: 'localhost',
//     dialect: 'mysql'
// });


const sequelize = new Sequelize({
    database: 'jinnNew',
    username: 'developer1',
    password: 'ug"5^b{#Z9',
    host: '143.110.254.46',
    dialect: 'mysql'
});

module.exports = sequelize;