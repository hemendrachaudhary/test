const sendBadRequest = (res, msg = "Bad Request") => {
    return res.send({
        status : 400,
        msg : msg
    })
    res.end();
}

const sendSuccess = (res, msg = "Success",result) => {
    return res.send({
        status : 200,
        msg : msg,
        result : result
    })
    res.end();
}

const sendSuccessMsg = (res, msg = "Success") => {
    return res.send({
        status : 200,
        msg : msg
    })
    res.end();
}

const sendSystemError = (res,err, msg = "System error.") => {
    console.log(err);
    return res.send({
        status : 500,
        msg : msg,
        result : err
    })
    res.end();
}

const sendError = (res, msg = "Error!") => {
    return res.send({
        status : 400,
        msg : msg
    })
    res.end();
}


module.exports = {
    sendBadRequest,
    sendSuccess,
    sendSystemError,
    sendError,
    sendSuccessMsg
}