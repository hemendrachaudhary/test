const express = require('express');
const adminController = require('../controllers/admin');

const router = express.Router();

router.get('/login', adminController.loginPage);

router.post('/login-post', adminController.postlogin);

module.exports = router;