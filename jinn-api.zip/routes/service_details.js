const express = require('express');
const service_detailsController = require('../controllers/service_details');

const router = express.Router();

router.get('/service-details', service_detailsController.getServiceDetails);
router.post('/service-details', service_detailsController.postServiceDetails);


module.exports = router;