const express = require('express');
const usersController = require('../controllers/users');
const roleController = require('../controllers/user_roles');
const serviceDetailsController = require('../controllers/service_details');
const becomePatnerController = require('../controllers/become_partner');
const upload = require('../lib/FileUpload');
const response = require("../utils/response");
const BuisnessDetail = require('../models/buisness_detail');
const workingController = require('../controllers/working_hours');
const ratingController = require('../controllers/ratings');
const enquiryController = require('../controllers/enquiry');
const aditionalServicesController = require('../controllers/aditional_services');
const messageController = require('../controllers/message');

const isAuth = require('../middleware/is-auth');
const router = express.Router();

/* user */
 router.post('/createUser',usersController.createUser);
 router.post('/login',usersController.login);
 router.post('/checkMobileNo', usersController.checkMobileNo);
 router.put('/updateUser',usersController.updateUser);
 router.put('/changerole', usersController.changeRole);

/*messages*/
router.post('/sendmessage', messageController.postMessage);
router.get('/getmessage', messageController.getMessages);
router.get('/getconvo', messageController.getConvoList);

/* service details */
router.get('/getServices',serviceDetailsController.getServices);

/* become patner */
router.post('/become_partner',becomePatnerController.postBecomePartner);
router.delete('/removeImage/:id',becomePatnerController.removeImage);
router.get('/getinfo',becomePatnerController.getPartnerInfo);
router.get('/getbecomepartner',becomePatnerController.getBecomePartner);
router.get('/getimages', becomePatnerController.getImages);
router.put('/updatebecomepartner', becomePatnerController.updateBecomePartner);

/*working hours */
router.post('/postworking', workingController.postWorking);

/*Rating */
router.post('/rating',ratingController.rating);
router.get('/getRating',ratingController.getRating);

/*Enquiry */
router.post('/enquiry',enquiryController.enquiry);
router.get('/getEnquiry',enquiryController.getEnquiry);
router.post('/notify',enquiryController.notify);
router.get('/getnotification', enquiryController.getNotification);

/*aditionalservice */
router.post('/aditionalservice', aditionalServicesController.postAditionalServices);
router.get('/getaditionalservice', aditionalServicesController.getAditionalServices);
router.put('/updateadditionalservice', aditionalServicesController.updateAdditionalService);
router.post('/activatedeactivateaditionalservice', aditionalServicesController.activateDeactivateAditionalService);








/* file uploads */
let typeOfimageFolder ;
router.post("/uploadImage", upload.single('uploadImage'), async (req, res) => {
    typeOfimageFolder = req.body.type;
    if (req.file) {
        var uploadImage = {};
        uploadImage.originalURL = req.file.filename;
        uploadImage.thumbURL = "";
        uploadImage.fileType = req.file.mimetype;
        uploadImage.fileSize = req.file.size;

        return response.sendSuccess(res, "Image Uploaded.", uploadImage);
     } else {
        return response.sendError(res, "Image upload failed.");
     }
});



router.post("/addImage", upload.single('uploadImage'), async (req, res) => {
   if (req.file) {
       var uploadImage = {};
       uploadImage.originalURL = req.file.filename;
       uploadImage.thumbURL = "";
       uploadImage.fileType = req.file.mimetype;
       uploadImage.fileSize = req.file.size;

       BuisnessDetail.create({
         userId : req.body.userId,
         image  : uploadImage.originalURL,
         buisness_data : "image",
     }).then(uploadImagedata =>{
      return response.sendSuccess(res, "Uploaded successfull", uploadImagedata);
     })
     .catch(err => {
         console.log(err)
     })
    }else{
       return response.sendError(res, "Image upload failed.");
    }
});



router.get('/get-role', roleController.getRole);
module.exports = router;