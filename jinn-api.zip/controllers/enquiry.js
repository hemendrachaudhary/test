const Enquiry = require('../models/enquiry');
const Notification = require('../models/user_notification');
const RawQuery = require('../models/rawQuery');
const Users   = require('../models/users');
const serviceDetails = require('../models/service_details');
const UserNotification = require('../models/user_notification');
const response = require("../utils/response");
const FCM = require('fcm-node')
// var serverKey = require("../firebase-adminSDK.json"); //put the generated private key path here    
// var fcm = new FCM(serverKey)
var serverKey = 'AAAAE4Qeel8:APA91bEQkg_hW83jebh95ZnIK8zlXHq4oXPk8Mvho1TI2VmEtLwLVyvG0RLVeaw8JQ3Sty8KM5iP0HtdO92JzEGNuSV1u9MwdjP-EhYlwS7ju-ho_bsRJ-qETuYxEgutnv3817naE1cf'; //put your server key here
var fcm = new FCM(serverKey);


exports.notify = (req, res) => {
    var message = { //this may vary according to the message type (single recipient, multicast, topic, et cetera)
        to: 'cD0oGUYyS2SQq_dwajzFnE:APA91bE7GIIUUzZxYKJxSqWtpmF3RQduccsJXXnlq4RCt-PqRMJixIBWPL8IRKf1rXtvkuTGmLqHr8PvM-lC0GDl9SC4BaStYYVsEfKwEI4UDqCWOesI040zdGlBI25hc4G2Xh89yN6z', 
        collapse_key: 'green',
        
        notification: {
            title: 'Title of your push notification', 
            body: 'Body of your push notification' 
        },
        
        data: {  //you can send only notification or only data(or include both)
            my_key: 'my value',
            my_another_key: 'my another value'
        }
    }
    
    fcm.send(message, function(err, response){
        if (err) {
            console.log("Something has gone wrong!====>>>>"+err);
        } else {
            console.log("Successfully sent with response: ", response);
        }
    })
    }

    async function sendNotification(token,title,body) {
        var message = { //this may vary according to the message type (single recipient, multicast, topic, et cetera)
            to: 'cD0oGUYyS2SQq_dwajzFnE:APA91bE7GIIUUzZxYKJxSqWtpmF3RQduccsJXXnlq4RCt-PqRMJixIBWPL8IRKf1rXtvkuTGmLqHr8PvM-lC0GDl9SC4BaStYYVsEfKwEI4UDqCWOesI040zdGlBI25hc4G2Xh89yN6z', 
            collapse_key: 'green',
            
            notification: {
                title: 'Title of your push notification', 
                body: 'Body of your push notification' 
            },
            
            data: {  //you can send only notification or only data(or include both)
                my_key: 'my value',
                my_another_key: 'my another value'
            }
        }
        
        fcm.send(message, function(err, response){
            if (err) {
                console.log("Something has gone wrong!====>>>>"+err)
    
            } else {
                console.log("Successfully sent with response: ", response)
            }
        })
    };
    
exports.enquiry = async (req,res, next) => {
        try {
           const { enquiryById,serviceDetailId,customer_name,customer_email,customer_mobile,enquiry_description,enquiry_subject,latitude,longitude} = req.body;
           var serviceDetail = await serviceDetails.findOne({where:{ id:serviceDetailId }});
           var enquiryToId =  req.body.enquiryToId;
           
          
                  if(enquiryToId == null || enquiryToId == undefined || enquiryToId == "") {
                        // sendNotification(); 
                        var where = `user_service_details.serviceDetailId='${serviceDetailId}'`;
                        let nearRestVender =  await RawQuery.getNearVenderByLatLong(where,latitude,longitude);
                        nearRestVender.forEach(async element => {
                           
                             /* enquiry*/
                             var insData = {
                                enquiryById : enquiryById,
                                serviceDetailId   : serviceDetailId,
                                customer_name : customer_name,
                                customer_email :customer_email,
                                customer_mobile:customer_mobile,
                                enquiry_subject:enquiry_subject,
                                enquiry_description:enquiry_description,
                                enquiryToId:element.userId
                                };
                                if(enquiryToId != null || enquiryToId != undefined || enquiryToId != ""){
                                    insData.enquiryToId = enquiryToId;
                                }
                               Enquiry.create(insData)
                            /* enquiry*/

                            if(element.userId != enquiryById )  {
                                var userInfo = await Users.findOne({where:{id:element.userId}});
                                var userByInfo = await Users.findOne({where:{id:enquiryById}});
                                var enqTitle = userByInfo.firstname+' enquiry  for '+serviceDetail.service_name;
                                Notification.create({
                                    notifyById : enquiryById,
                                    notifyToId : element.userId,
                                    notification_title   : enqTitle,
                                    notification_text : enquiry_description,
                                    })
                                    .then(notificationData =>{
                                        var message = { //this may vary according to the message type (single recipient, multicast, topic, et cetera)
                                            to: userInfo.fcm_token, 
                                            collapse_key: 'green',
                                            
                                            notification: {
                                                title: enqTitle, 
                                                body: enquiry_description 
                                            }
                                        }
                                        fcm.send(message, function(err, response){
                                            if (err) {
                                                console.log("Something has gone wrong!====>>>>"+err)
                                    
                                            } else {
                                                console.log("Successfully sent with response: ", response)
                                            }
                                        })
                                    })
                                } 
                             });
                    } else {
                        var insData = {
                            enquiryById : enquiryById,
                            serviceDetailId   : serviceDetailId,
                            customer_name : customer_name,
                            customer_email :customer_email,
                            customer_mobile:customer_mobile,
                            enquiry_subject:enquiry_subject,
                            enquiry_description:enquiry_description
                            };
                            if(enquiryToId != null || enquiryToId != undefined || enquiryToId != ""){
                                insData.enquiryToId = enquiryToId;
                            }
                           Enquiry.create(insData);
                        var userInfo = await Users.findOne({where:{id:enquiryToId}});
                        var userByInfo = await Users.findOne({where:{id:enquiryById}});
                        var enqTitle = userByInfo.firstname+' enquiry  for '+serviceDetail.service_name;
                         Notification.create({
                            notifyById : enquiryById,
                            notifyToId : enquiryToId,
                            notification_title   : enqTitle,
                            notification_text : enquiry_description,
                            })
                            .then(notificationData =>{
                                var message = { //this may vary according to the message type (single recipient, multicast, topic, et cetera)
                                    to: userInfo.fcm_token, 
                                    collapse_key: 'green',
                                    
                                    notification: {
                                        title: enqTitle, 
                                        body: enquiry_description 
                                    }
                                }
                                fcm.send(message, function(err, response){
                                    if (err) {
                                        console.log("Something has gone wrong!====>>>>"+err)
                            
                                    } else {
                                        console.log("Successfully sent with response: ", response)
                                    }
                                })
                                // return response.sendSuccess(res, "Enquiry added222 successfull.", req.boby); 
                            })
                           
                    }
                   return response.sendSuccess(res, "Enquiry added successfull.", req.body); 
               
            } catch (error) {
          return response.sendSystemError(res, error);
        }
    }


exports.getEnquiry = async (req,res) => {
    try {
        var limit = req.query.limit;
        var page_number = req.query.page_number;
        var userId = req.query.userId;
        var offset;
            if (page_number == null || page_number == 1) {
                offset = 0;
            }
            else {
                offset = limit * (page_number - 1);
            }
            
        var userId = req.query.userId;
        var where = `enquiryToId='${userId}'`
        let enquiryInfo =  await RawQuery.getEnquiryList(where,limit,offset);
        return response.sendSuccess(res, "Enquiry list.", enquiryInfo);
            } 
    catch (error) {
        return response.sendSystemError(res, error);
    }
};
 
exports.getNotification = async (req, res, next) => {
    const userId = req.query.user_id;
    var limit = req.query.limit;
    var page_number = req.query.page_number;
    let offset;
    var total;
    var result = {}
    
    if (page_number == null || page_number == 1) {
         offset = 0;
     }
    else {
        offset = limit * (page_number - 1);
    }

    offset =  parseInt(offset);
    limit  =  parseInt(limit);

    await UserNotification.count({ where : { notifyToId : userId} })
        .then(count =>{
            total = count;
            result.total_notification = total;
            return UserNotification.findAll({ where : { notifyToId : userId}, order: [ ['id', 'DESC'] ],limit:limit,offset:offset
          })
        })
        .then( notifications => {
            const newNotify = UserNotification.count({ where: [{ 'is_read' : 0 }]})
                .then( async newNotify => {
                    result.new_notification = newNotify;
                    UserNotification.update({ is_read: 1 },{ where : { notifyToId : userId }});
                    const lastNotification = await UserNotification.findOne(  { order: [ ['id', 'DESC'] ]} ).then(nty => {
                        return nty;
                    })
                    result.last_notification = lastNotification;
                    result.notifications = notifications;
                    return res.status(200).json({ msg: "notification get successfully", status : 200, result});
                })
        })
        
};

