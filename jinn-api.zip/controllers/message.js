const Message = require('../models/message');
const RawQuery = require('../models/rawQuery');

exports.postMessage = async (req, res, next) => {
    const msg = req.body.message_text;
    const message_by = req.body.user_id;
    const message_to = req.body.messageToId;

    if (message_by !== message_to){
        Message.create({
            message_text : msg,
            messageById: message_by,
            messageToId: message_to
        })
        .then( result => {
           return res.status(200).json({msg : "message success!", status: 200, result});
        })
        .catch(err => {console.log(err) });    
    } else {
        return res.status(400).json({msg : "id can't be same!"});
    }
};

exports.getMessages = async (req, res, next) => {
    const userId = req.query.user_id;
    const messageById = req.query.messageById;
    var limit = req.query.limit;
    var page_number = req.query.page_number;
    let offset;
    var total;
    var result = {}
    
    if (page_number == null || page_number == 1) {
         offset = 0;
     }
    else {
        offset = limit * (page_number - 1);
    }

    offset =  parseInt(offset);
    limit  =  parseInt(limit);
    const { Op } = require("sequelize");
    await Message.count({ where : { messageToId : userId, messageById : messageById}})
        .then(count =>{
            total = count;
            result.total = total;
            // return Message.findAll({ where : { messageToId : userId, messageById : messageById}, order: [ ['id', 'DESC'] ], limit: limit, offset: offset})
            return Message.findAll({ where : 
                {[Op.or]: [{ messageToId : userId, messageById : messageById }, 
                    { messageToId : messageById, messageById : userId }] },
                     order: [ ['id', 'DESC'] ], limit: limit, offset: offset})
         })
        .then( messages => {
            const newMsg = Message.findAll({ where: [{ messageToId : userId, messageById : messageById, 'is_read' : 0 }]})
            .then( async newMsg => {
                result.newMsg = newMsg;
                Message.update({ is_read: 1 },{ where : { messageToId : userId }});
                // const lastMsg = await Message.findOne( {where : { messageToId : userId, messageById : messageById},order: [ ['id', 'DESC'] ]}).then(msg => {
                //     return msg;
                // });
                const lastMsg = await Message.findOne( { where : 
                    {[Op.or]: [{ messageToId : userId, messageById : messageById }, 
                        { messageToId : messageById, messageById : userId }] },
                         order: [ ['id', 'DESC'] ]}).then(msg => {
                    return msg;
                });
                result.lastMsg = [];
                result.lastMsg.push(lastMsg);
                // result.lastMsg = lastMsg;
                result.messages = messages;
                return res.status(200).json({ msg: "message get successfully",status : 200, result});
            })
            }
        )
        .catch( err => console.log(err));
};
exports.getConvoList = async (req, res, next) => {
    const userId = req.query.user_id;
    var limit = req.query.limit;
    var page_number = req.query.page_number;
    let offset;

    if (page_number == null || page_number == 1) {
        offset = 0; 
    }
    else {
       offset = limit * (page_number - 1);
   }

   var result = await RawQuery.getConvList(userId, limit, offset);
    return res.status(200).json({ msg: "Conversation List",status : 200, result});
};


