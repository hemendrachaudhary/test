
const AditionalServices = require('../models/aditional_services');
const serviceDetail = require('../models/service_details');
const response = require("../utils/response");

exports.postAditionalServices = (req, res, next) => {
    const _id = req.body.user_id;
    const service_id = req.body.service_id;
    const service_name = req.body.serviceName;
    const description = req.body.description;
    const price = req.body.price;

    AditionalServices
        .create({
            service_name: service_name,
            description: description,
            price: price,
            userId: _id,
            serviceDetailId: service_id
        })
        .then(result => {
            return response.sendSuccess(res, "Additional service added successfull.", result);
        })
        .catch(err => {
            return response.sendSystemError(res,err);
        })
};

exports.getAditionalServices = (req,res, next) => {
    const _id = req.query.user_id;

    try{
        AditionalServices
            .findAll({where : {userId : _id, status: 1} , include: {
                model: serviceDetail,
                attributes:['service_name']
                } 
            })
            .then(result => {
            res.status(200).json({msg: "success", status: 200, result});
            })
            .catch(err => console.log(err));
    }catch(err){
        console.log(err);
    }
};

exports.updateAdditionalService = (req, res, next) => {
    const serviceId = req.body.id;
    const name = req.body.servicename;
    const description = req.body.description;
    const price = req.body.price;

    AditionalServices.findOne({ where: {id : serviceId }}).then( service => {
        return service.update({
            service_name : name,
            description : description,
            price : price
        })
    }).then(result => {
        return res.status(200).json({ msg: "user update successfully!", status:200, result });
    }).catch(err => {
        console.log(err);
    });
};

exports.activateDeactivateAditionalService = (req, res, next) => {
    const serviceId = req.body.serviceId;
    const statusRole = req.body.status;

    AditionalServices.findOne({ where: {id : serviceId }}).then(service => {
        return service.update({
            status: statusRole
        })
    }).then(result => {
        return res.status(200).json({msg: "user delete successfully!", status:200, result});
    }).catch(err => {
        console.log(err);
    });
};




