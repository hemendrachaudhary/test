const BecomePartner = require('../models/become_partner');
const WorkingHour = require('../models/working_hours');
const response = require("../utils/response");

exports.postWorking = async (req, res, next) => {
    const data = req.body.data;
    var userId = req.body.userId;
    var workingData = [];
    
    try {
        //var WorkingHour = await WorkingHour.findAll({ where: { userId: req.body.userId} });
        WorkingHour.findOne({where: {userId : userId}}).then(async WorkingHourData => {
            if(WorkingHourData) {
                 await WorkingHour.destroy({
                    where: {
                        userId : userId
                    }
                })
                data.map( (result)=> {
                    return WorkingHour.create({
                          day: result.day,
                          opentime: result.opentime,
                          closetime: result.closetime,
                          userId :userId
                      })
                          .then(wData =>{
                           workingData.push(wData);
                       }).catch(err => console.log(err));
               })
             return response.sendSuccess(res, "Working hour updated successfull.", data); 
        }else{
            data.map( (result)=> {
                  return WorkingHour.create({
                        day: result.day,
                        opentime: result.opentime,
                        closetime: result.closetime,
                        userId :userId
                    })
                        .then(wData =>{
                         workingData.push(wData);
                     }).catch(err => console.log(err));
             })
             return response.sendSuccess(res, "Working hour added successfull.", data); 
        }
        
        
    } 
        )}catch(err){
            console.log(err);
        }
}
