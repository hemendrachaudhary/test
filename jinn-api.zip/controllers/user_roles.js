const user_role = require("../models/user_role");
const response = require("../utils/response");

async function getRole(req, res) {
    try {
        var roleData = await user_role.findAll();
        return response.sendSuccess(res, "Role List.", roleData);
        
    } catch (err) {
      return response.sendSystemError(res, err);
    }
  }


  module.exports = {
    getRole: getRole
 }
