const Ratings = require('../models/ratings');
const RawQuery = require('../models/rawQuery');
const Users   = require('../models/users'); 
const response = require("../utils/response");

exports.rating = async (req,res) => {
    try {
       const { reviewById, reviewToId, rating_no,review_comment} = req.body;
       var ratingsInfo = await Ratings.findOne({ where: { reviewById: reviewById,reviewToId:reviewToId} });
       if(ratingsInfo){
        return Ratings.update({
            rating_no : rating_no,
            review_comment : review_comment},
            { where: {reviewById: reviewById,reviewToId:reviewToId}
            }).then(async ratingData =>{
                //var ratingUpdateData = await Ratings.findOne({ where: { reviewById: reviewById,reviewToId:reviewToId} });
                var ratingUpdateData = await RawQuery.getRatingInfo(ratingsInfo.id);
                return response.sendSuccess(res, "Rating updated successfull.", ratingUpdateData[0]); 
            })
            .catch(err => {
                console.log(err)
            })
       }else{
        return Ratings.create({
            reviewById : reviewById,
            reviewToId : reviewToId,
            rating_no   : rating_no,
            review_comment : review_comment
            }).then(async ratingData =>{
                var ratingData = await RawQuery.getRatingInfo(ratingData.id);
                return response.sendSuccess(res, "Rating added successfull.", ratingData[0]); 
            })
            .catch(err => {
                console.log(err)
            });
       }
       
        } catch (error) {
      return response.sendSystemError(res, error);
    }
}

exports.getRating = async (req,res) => {
    try {
        var limit = req.query.limit;
        var page_number = req.query.page_number;
        var userId = req.query.userId;
        var offset;
        if (page_number == null || page_number == 1) {
             offset = 0;
         }
     else {
            offset = limit * (page_number - 1);
        }
        var userId = req.query.userId;
        var where = `reviewToId='${userId}'`
        let ratingsInfo =  await RawQuery.getReviewList(where,limit,offset);
        return response.sendSuccess(res, "Ratings list.", ratingsInfo);
        } catch (error) {
      return response.sendSystemError(res, error);
    }
}
