const service_details = require("../models/service_details")
const response = require("../utils/response");
const RawQuery = require('../models/rawQuery');

exports.getServices =  async (req, res, next) => {
    try {
     var result = await  RawQuery.getServices();
    
        return response.sendSuccess(res, "Services List.", result);
    
   }catch (error) {
    console.error(error);
  }
}

exports.postServiceDetails = (req, res, next) => {
        const {name, des, img} = req.body;

        return service_details.create({ 
            service_name : name,
            service_description : des,
            service_image : img
        })
        .then(result => {
            return res.status(200).json( {msg: "service detail created!", status: 200, result});
        })
        .catch(err => {
            console.log(err);
        })
}