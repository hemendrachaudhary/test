const BecomePartner = require('../models/become_partner');
const BuisnessDetail = require('../models/buisness_detail');
const User = require('../models/users');
const upload = require('../lib/FileUpload');
const userSeviceDetail = require('../models/user_service_detail');
const response = require("../utils/response");
const Ratings = require('../models/ratings');
const WorkingHour = require('../models/working_hours');
const AditionalServices = require('../models/aditional_services');
const RawQuery = require('../models/rawQuery');

exports.postBecomePartner = (req, res, ) => {
    const companyname = req.body.companyname;
    const email = req.body.email;
    const mobile_no = req.body.mobile_no;
    const phone_no = req.body.phone_no;
    const country =req.body.country;
    const state = req.body.state;
    const city = req.body.city;
    const zipcode = req.body.zipcode;
    const logo = req.body.logo;
    const adharcard_front	 = req.body.adharcard_front;
    const adharcard_back	 = req.body.adharcard_back;
    const gst_no	 = req.body.gst_no;
    const pancard = req.body.pancard;
    const description = req.body.description;

    BecomePartner.create({
        companyname : companyname,
        email : email,
        mobile_no :  mobile_no,
        country: country,
        state: state,
        city: city,
        phone_no : phone_no,
        building: req.body.building,
        street: req.body.street,
        landmark: req.body.landmark,
        area: req.body.area,
        latitude: req.body.latitude,
        longitude: req.body.longtitude,
        zipcode: zipcode,
        logo: logo,
        pancard: pancard,
        adharcard_front	: adharcard_front,
        adharcard_back :adharcard_back,
        description	: description,
        userId: req.body.user_id,
        gst_no : gst_no
    })
    .then(becomePartner => {
      req.body.id = becomePartner.id;
        User.update({ isVender:1, isCurrentVender:1},
            { where: {id:req.body.user_id }
        });
         return becomePartner;
    }).then(async becomePartner => {
        req.body.service_id.forEach(async (item, i) => {
            userSeviceDetail.create({
                userId : req.body.user_id,
                serviceDetailId : item
            }).then(userSeviceData =>{
                console.log("created");
            })
            .catch(err => {
                console.log(err);
            })
         });
         var venderInfo = await RawQuery.getvenderInfo(req.body.user_id);
         return response.sendSuccess(res, "Patner added successfull.", venderInfo[0]);
    })
    .catch(err => {
        return response.sendSystemError(res,err);
    })
};



exports.removeImage = (req,res) => {
    var id = req.params.id;
    BuisnessDetail.destroy({
        where: { id: id }
      })
        .then(num => {
          if (num == 1) {
            res.send({
              status:200,  
              msg: "Image was deleted successfully!"
            });
          } else {
            res.send({
              status:400, 
              msg: `Cannot delete Image with id=${id}. Maybe Image  was not found!`
            });
          }
        })
        .catch(err => {
          res.status(500).send({ status:500, msg: "Could not delete Image with id=" + id });
        });
};



exports.getBecomePartner = async (req, res) => {
  var latitude = req.query.latitude;
  var longitude = req.query.longitude;
  // var limit = req.query.limit;
  // var page_number = req.query.page_number;
  var userId = req.query.userId;
  // var offset;
  // if (page_number == null || page_number == 1) {
  //      offset = 0;
  //  }
  // else {
  //     offset = limit * (page_number - 1);
  // }

  var venderList = {};
  var serviceDetailId =  req.query.serviceDetailId;
  if(serviceDetailId != 0) {
    var where = `user_service_details.serviceDetailId='${serviceDetailId}'`
  } else
  {
    var where = 1
  }


  var venderData = await RawQuery.getVenderByLatLong(where,latitude,longitude);
  console.log(venderData)
  const promises = venderData.nearRestVender.map(async venderList => {
  var where1 = `userId='${venderList.userId}'`
  var services =  await RawQuery.getServicesListByUser(where1);
  var workingData = await RawQuery.getWorking(where1);
  venderList['workinghours'] = workingData;
  venderList['services'] = services;
  return  venderList;
  })
  // wait until all promises resolve
  const results = await Promise.all(promises);
  venderList.total = venderData.total;
  venderList.venderData= results;

  return response.sendSuccess(res, "Vender List.", venderList);
  }


exports.getPartnerInfo = async (req, res, next) => {
        const _id = req.query.user_id;
        var limit = req.query.limit;
        var page_number = req.query.page_number;
        var offset;
        if (page_number == null || page_number == 1) {
             offset = 0;
         }
     else {
            offset = limit * (page_number - 1);
        }
  const partnerInfo  = {};
    var venderInfo = await RawQuery.getvenderInfo(_id);
    var where1 = `userId='${_id}'`
    var workingData = await RawQuery.getWorking(where1);
    var where = `reviewToId='${_id}'`
    var limit = req.query.limit;
    var ratingsInfo =  await RawQuery.getReviewList(where,limit,offset);
    var services =  await RawQuery.getServicesListByUser(where1);
    var aditionalServices =  await AditionalServices.findAll({where : {userId : _id, status: 0}});
    var imageData =  await RawQuery.getBuisnessImages(_id);

    var serve = services.map((item) => ({...item, additionalService: aditionalServices}));
    partnerInfo["venderinfo"] = venderInfo[0];
    partnerInfo['workinghours'] = workingData;
    partnerInfo['ratingsInfo'] = ratingsInfo;
    partnerInfo['services'] = serve;
    partnerInfo['imageData'] = imageData;
    
    return response.sendSuccess(res, "Vendor Info.", partnerInfo);
};



exports.getImages = async (req, res, next) => {
  try {
  const userId = req.query.user_id;
  var result =await RawQuery.getBuisnessImages(userId)
   
  return res.status(200).json({msg: "success", status:200, result});
      
  }catch (error) {
        console.error(error);
      }
};


exports.updateBecomePartner = (req,res,next) => {
  const _id = req.body.partnerId;
  const companyName = req.body.companyname;
  const email = req.body.email;
  const mobileNo = req.body.mobile_no;
  const phoneNo = req.body.phone_no;
  const country = req.body.country;
  const state = req.body.state;
  const city = req.body.city;
  const zipcode = req.body.zipcode;
  const description = req.body.description;
  const logo = req.body.logo;
  const gstNo = req.body.gst_no;
  const building = req.body.building;
  const street = req.body.street;
  const landmark = req.body.landmark;
  const area = req.body.area;
  const latitude = req.body.latitude;
  const longitude = req.body.longitude;  

  BecomePartner.findOne({ where: {id : _id}})
  .then(user => {
    if (user && user.gst_no == ""){
      return user.update({
        companyname: companyName,
        email: email,
        mobile_no: mobileNo,
        phone_no: phoneNo,
        country: country,
        state: state,
        city: city,
        zipcode: zipcode,
        description: description,
        logo: logo,
        gst_no: gstNo,
        building: building,
        street: street,
        landmark: landmark,
        area: area,
        latitude: latitude,
        longitude: longitude
      });
    } else if ( user ){
      return user.update({
        companyname: companyName,
        email: email,
        mobile_no: mobileNo,
        phone_no: phoneNo,
        country: country,
        state: state,
        city: city,
        zipcode: zipcode,
        description: description,
        logo: logo,
        building: building,
        street: street,
        landmark: landmark,
        area: area,
        latitude: latitude,
        longitude: longitude
      });
    } else {
      return res.json({status: 404, message: "user not found!!"});
    }
  }).then( async patnerData => {
    var resultArr = await RawQuery.getvenderInfo(patnerData.userId);
    var result =  resultArr[0];
    
    return res.status(200).json({msg: "update become partner successfully!", status: 200, result});
  }).catch(err => console.log((err)));
};
