const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
//const Customer = require("../models/customer");

exports.authenticateUser = (req, res, next) => {
    const email =  req.body.email;
    const password =  req.body.password;
    let userData = {};
    Customer.findAll({
        where: {email: req.body.email}
      })
      .then(userDetail => {
          userData=userDetail
          return userData;
      })
      .then(result => {
             return bcrypt.compare(password, result[0].password)
        })
     .then(isEqual => {
        if(!isEqual){
            const error = new Error('wrong password');
            error.statusCode = 401;
            throw error
        }
        const token = jwt.sign(
            {
                email: req.body.username, 
                password: req.body.password
            }, 
            'somesupersecretsecret', 
            { expiresIn: '1h' }
        );
        res.status(200).json({ 
            message: "login success", 
            status: 1,
            result: {token: token, userData: userData[0]} 
        });
    })
    .catch(err => {
        res.status(400).json({ 
            message: "please enter correct username and password", 
            status: 0
        });
    })
}