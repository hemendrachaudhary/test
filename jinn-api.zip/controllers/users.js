const Users = require("../models/users");
const bcrypt = require('bcryptjs');
const response = require("../utils/response");
require('dotenv').config();
const jwt = require('jsonwebtoken');
const upload = require('../lib/FileUpload');
const RawQuery = require('../models/rawQuery');

async function  createUser (req, res)  {
    var  checkEmail = await Users.findOne({ where: { email: req.body.email} });
    if (checkEmail) {
        return response.sendError(res, "Email already exits.");
    }
    var checkMobileNo = await Users.findOne({ where: { mobile_no: req.body.mobile_no} });
    if (checkMobileNo) {
        return response.sendError(res, "Mobile no. already exits.");
    }
    bcrypt.hash(req.body.mobile_no, 12)
    .then(hashepw => {
        return Users.create({
            firstname: req.body.firstname,
            lastname: req.body.lastname,
            email: req.body.email,
            mobile_no: req.body.mobile_no,
            // address: req.body.address,
            // latitude: req.body.latitude,
            // longitude: req.body.longitude,
            device_token:req.body.device_token,
            fcm_token:req.body.fcm_token,
            verificationKey:hashepw
        })
        .then(result => {
           // sendResistrationMail();
           return response.sendSuccess(res, "User registration successfull.", result);
         })
        .catch(err => {
            return response.sendError(res, "User registration failed.");
        })
    })
    .catch(err => console.log(err))
 
}

async function checkMobileNo (req,res) { 

        if(req.body.mobile_no == "" || req.body.mobile_no == undefined ) {
            return response.sendError(res, "Mobile no. is required.");
        }

    var checkMobileNo = await Users.findOne({ where: { mobile_no : req.body.mobile_no }});

    if (checkMobileNo) {
        var token = jwt.sign({ verificationKey: checkMobileNo.verificationKey }, process.env.TOKEN_SECRET, {
            expiresIn: 86400 // expires in 24 hours
             });

        var data = {}
          data.userDetails = checkMobileNo;
          
         return response.sendSuccess(res, "Login successfull.",data);
    } else { 
        return response.sendError(res, "Mobile not exits.");
    }  
}

async function login (req,res) {
    if(req.body.mobile_no =="" || req.body.mobile_no == undefined ) {
        return response.sendError(res, "Mobile no. is required.");
    }
    var checkMobileNo = await Users.findOne({ where: { mobile_no: req.body.mobile_no} });
    if (checkMobileNo) {
        var token = jwt.sign({ verificationKey: checkMobileNo.verificationKey}, process.env.TOKEN_SECRET, {
            expiresIn: 86400 // expires in 24 hours
             });
            var data = {}
            console.log(checkMobileNo);
            data.userDetails = checkMobileNo;
              
            return response.sendSuccess(res, "Login successfull.",data);
    } else {
         return response.sendError(res, "Login failed.");
    }  
}


const updateUser = (req, res) => {
    const userId = req.body.userId;
    const updatedFirstname = req.body.firstname;
    const updatedLastname = req.body.lastname;
    const updatedAddress = req.body.address;
    const updatedImage = req.body.imageUrl;

    Users.findOne({where: {id : userId}}).then( user => {
         return user.update({ 
                firstname: updatedFirstname,
                lastname: updatedLastname,
                address: updatedAddress,
                image: updatedImage
                });
    }).then(async userData => {
        var userInfo = await RawQuery.getUserInfo(userData.id);
        var result = userInfo[0];
        return response.sendSuccess(res, "User information updated successfull.", result);
    }).catch(err => {
        return response.sendSystemError(res,err);
    });
};



const changeRole = (req, res, next ) => {
    const userId = req.body.user_id;
    const venderRole = req.body.isVender;

    Users.findOne({ where: { id : userId }}).then( user => {
        return user.update({
            isVender : venderRole
        });
    }).then(result => {
        return res.status(200).json({msg: "User role changed!!", status: 200, result});
    }).catch(err => console.log(err));
}



module.exports = {
    changeRole: changeRole,
    createUser: createUser,
    login : login,
    checkMobileNo : checkMobileNo,
    updateUser:updateUser
 }