const path = require('path');

exports.loginPage = (req, res, next) => {
    res.sendFile(path.join(__dirname, "../", "views", "login.html"))
}

exports.postlogin = (req, res, next) => {
    let data = []
    Customer.findAll().then(details => {
        res.render('adminView', {
            details: details,
            pageTitle: 'Admin Products', 
            path: 'adminView'
        });
    })
}