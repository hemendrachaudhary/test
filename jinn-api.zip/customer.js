const customer = require("../models/customer");
const bcrypt = require('bcryptjs');
var request = require('request');
const axios = require('axios');


exports.createCustomer = (req, res, next) => {
    bcrypt.hash(req.body.password, 12)
    .then(hashepw => {
        return customer.create({
            provider: req.body.provider,
            provider_id: req.body.provider_id,
            firstname: req.body.firstname,
            lastname: req.body.lastname,
            email: req.body.email,
            //username: req.body.username,
            password: hashepw,
            mobileno: req.body.mobileno,
            address1: req.body.address1,
            address2: req.body.address2,
            pincode: req.body.pincode,
            state: req.body.state,
            city: req.body.city,
            birthdate: req.body.birthdate,
            ssn_number: req.body.ssn_number,
            citizenship_type: req.body.citizenship_type,
            investment_experience: req.body.investment_experience,
            employed_type: req.body.employed_type,
            name_of_employer: req.body.name_of_employer,
            is_family_member_work: req.body.is_family_member_work,
            photo: req.body.photo,
            occupation: req.body.occupation,
            devicetype: req.body.devicetype,
            deviceToken: req.body.deviceToken,
            fcmtoken: req.body.fcmtoken,
            isactive: 1
        })
        .then(result => {
            res.status(201).json({
                message: 'customer registered successfully',
                status: 1,
                result: {}
            })
        })
        .catch(err => {
            res.status(400).json({
                message: 'registration faild',
                status: 0,
                result: {}
            })
        })
    })
    .catch(err => console.log(err))
    
}

exports.ssnValidation = (req, res, next) => {
    const ssnNumber = req.body.ssnNumber
    console.log("here");
    axios.post("https://apitest.microbilt.com/SSNValidation/GetReport", { "SSN": ssnNumber }, {
        headers: {
            'Authorization': 'Bearer fA4hlVgLmNQfEPkAqTrCtxVmZg8c',
            'Accept': 'application/json',
            'Content-Length': '26',
            'Content-Type': 'application/json',
            'Host': 'apitest.microbilt.com',
          },
    }).then(function(response) {
        console.log("response ---->", response.data)
        res.status(201).json({
            message: 'ssn varification',
            status: 1,
            result: response.data.MsgRsHdr.Status.StatusCode
        })
    }).catch(function(error) {
        console.log("error ---->", error);
        res.status(401).json({
            message: 'ssn varification faild',
            status: 0,
            result: {}
        })
    })


}