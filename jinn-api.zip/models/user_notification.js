const Sequelize = require('sequelize');

const sequelize = require('../utils/databsse');

const userNotification = sequelize.define('user_notification', {
    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
    },
    notification_title : {
        type: Sequelize.STRING,
    },
    notification_text : {
        type: Sequelize.STRING,
    },
    is_read: {
        type: Sequelize.INTEGER,
        allowNull: false,
        defaultValue: '0'
    }
});

module.exports = userNotification;



