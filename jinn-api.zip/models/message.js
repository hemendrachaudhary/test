const Sequelize = require('sequelize');
const sequelize = require('../utils/databsse');

const Message =  sequelize.define('message', {
    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
    },
    message_text : {
        type: Sequelize.STRING
    },
    is_read: {
        type: Sequelize.INTEGER,
        defaultValue: 0
    }
});


module.exports =  Message;