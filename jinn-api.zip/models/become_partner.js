
const Sequelize = require('sequelize');

const sequelize = require('../utils/databsse');

const BecomePartner = sequelize.define('become_partner', {
    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
    },
    companyname	: Sequelize.STRING(30),
    email	    : {
            type: Sequelize.STRING(50),
            unique: true
    },
    mobile_no: {
        type: Sequelize.STRING,
        unique: true
    },
    phone_no: {
        type: Sequelize.STRING,
        unique: true
    },
    country: {
        type: Sequelize.STRING,
        allowNull: false
    },
    state:{
        type: Sequelize.STRING,
        allowNull: false
    },
    city:{
        type: Sequelize.STRING,
        allowNull: false
    },
    zipcode:{
        type: Sequelize.INTEGER,
        allowNull: false
    },
    
    description: {
        type: Sequelize.STRING,
        allowNull: false
    },
    logo: {
        type: Sequelize.STRING,
    },
    adharcard_front: {
        type: Sequelize.STRING,
    },
    adharcard_back: {
        type: Sequelize.STRING,
    },
    pancard: {
        type: Sequelize.STRING,
    },
    gst_no: {
        type: Sequelize.STRING,
    },
    building: {
        type: Sequelize.STRING
    },
    street: {
        type: Sequelize.STRING
    },
    landmark: {
        type: Sequelize.STRING
    },
    area: {
        type: Sequelize.STRING
    },
    latitude: {
        type: Sequelize.STRING
    },
    longitude: {
        type: Sequelize.STRING
    }
    
});


module.exports = BecomePartner;