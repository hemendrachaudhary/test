const Sequelize = require('sequelize');

const sequelize = require('../utils/databsse');

const userSeviceDetail = sequelize.define('user_service_detail', {
    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
    }
})

module.exports = userSeviceDetail;