const Sequelize = require('sequelize');

const sequelize = require('../utils/databsse');

const userRoles = sequelize.define('userRoles', {
    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
    },
    role_name: Sequelize.STRING(100),
    role_status: Sequelize.ENUM('1','0'),
});
module.exports = userRoles;

