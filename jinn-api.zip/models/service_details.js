const Sequelize = require('sequelize');

const sequelize = require('../utils/databsse');

const serviceDetails = sequelize.define('serviceDetails', {
    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
    },
    service_name: Sequelize.STRING(25),
    service_description: Sequelize.STRING(255),
    service_image: Sequelize.STRING(50)
})

module.exports = serviceDetails;