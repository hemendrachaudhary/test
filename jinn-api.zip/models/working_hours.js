const Sequelize = require('sequelize');

const sequelize = require('../utils/databsse');

const WorkingHour = sequelize.define('working_hour', {
    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
    },
    day : {
        type: Sequelize.STRING,
        allowNull: false
    },
    opentime: {
        type: Sequelize.STRING,
        allowNull: false
    },
    closetime: {
        type: Sequelize.STRING,
        allowNull: false
    }
});

module.exports = WorkingHour;