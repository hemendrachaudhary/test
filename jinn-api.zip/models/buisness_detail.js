const { ENUM } = require('sequelize');
const Sequelize = require('sequelize');

const sequelize = require('../utils/databsse');

const BuisnessDetail = sequelize.define('buisness_detail', {
    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
    },
    image: {
        type: Sequelize.STRING,
        allowNull: false
    },
    video: {
        type: Sequelize.STRING,
        
    },
    buisness_data:{
        type: Sequelize.ENUM('image', 'video', 'mobile'),
        allowNull: false
    }
})

module.exports = BuisnessDetail;