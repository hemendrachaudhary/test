const Sequelize = require('sequelize');

const sequelize = require('../utils/databsse');

const Enquiry = sequelize.define('enquiry', {
    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
    },
    customer_name: {
        type: Sequelize.STRING,
        allowNull: false
    },
    customer_email: {
        type: Sequelize.STRING,
        allowNull: false
    },
    customer_mobile: {
        type: Sequelize.STRING,
        allowNull: false
    },
    enquiry_subject:{
        type: Sequelize.STRING,
        allowNull: true
    },
    enquiry_description:{
        type: Sequelize.STRING,
        allowNull: true
    },
    
});

module.exports = Enquiry;
