const Sequelize = require('sequelize');

const sequelize = require('../utils/databsse');

const Users = sequelize.define('user', {
    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
    },
    firstname	: Sequelize.STRING(30),
    lastname	: Sequelize.STRING(30),
    email	    : {
            type: Sequelize.STRING(50),
            unique: true
    },
    mobile_no: {
        type: Sequelize.STRING(50),
        unique: true
    },
    address: Sequelize.STRING(50),
    latitude: Sequelize.STRING(50),
    longitude: Sequelize.STRING(50),
    image: Sequelize.STRING(50),
    device_token: Sequelize.STRING(250),
    fcm_token: Sequelize.STRING(250),
    verificationKey:Sequelize.STRING(250),
    status: Sequelize.ENUM('1', '0'),
    notification_status: Sequelize.ENUM('1', '0'),
    isVender : {
        type: Sequelize.INTEGER,
        defaultValue: 0
    },
    isCurrentVender : {
        type: Sequelize.INTEGER,
        defaultValue: 0
    }
    
});

module.exports = Users;