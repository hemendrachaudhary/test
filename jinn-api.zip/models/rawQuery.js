const Sequelize = require('sequelize');

const sequelize = require('../utils/databsse');

/* getReviewList */
async function getReviewList(where,limit,offset) {
    // var total_review = Promise.resolve(await sequelize.query(`SELECT count(id) as total_review FROM ratings  WHERE ${where} `, { type: Sequelize.QueryTypes.SELECT }));
    // var review = Promise.resolve(await sequelize.query(`SELECT ratings.*,users.firstname FROM ratings LEFT JOIN users ON users.id = ratings.reviewById WHERE ${where} LIMIT ${limit} OFFSET ${offset} `, { type: Sequelize.QueryTypes.SELECT }));
    var total_review = await sequelize.query(`SELECT count(id) as total_review,ROUND(avg(rating_no),2) as avg_rating FROM ratings  WHERE ${where} `, { type: Sequelize.QueryTypes.SELECT });
    var review = await sequelize.query(`SELECT ratings.*,users.firstname,users.lastname,concat('profiles/', users.image) AS profileImage    FROM ratings LEFT JOIN users ON users.id = ratings.reviewById WHERE ${where} LIMIT ${limit} OFFSET ${offset} `, { type: Sequelize.QueryTypes.SELECT });
    var data = { total: 0,avg_rating: 0, review: [] }
    //console.log(total_review[0].total_review);
    if (total_review.length != 0) {
        data.total = total_review[0].total_review;
        data.avg_rating = total_review[0].avg_rating;
    }
    if (review.length != 0) {
        data.review = review;
    }
    return data;
 }

 /* getEnquiryList */
async function getEnquiryList(where,limit,offset) {
    var total_enquiries = await sequelize.query(`SELECT count(id) as total_review FROM enquiries  WHERE ${where} `, { type: Sequelize.QueryTypes.SELECT });
    var enquiries = await sequelize.query(`SELECT enquiries.*,users.firstname,users.lastname,concat('profiles/', users.image) AS profileImage FROM enquiries LEFT JOIN users ON users.id = enquiries.enquiryById WHERE ${where} LIMIT ${limit} OFFSET ${offset} `, { type: Sequelize.QueryTypes.SELECT });
    var data = { total: 0, enquirie: [] }
    //console.log(total_review[0].total_review);
    if (total_enquiries.length != 0) {
        data.total = total_enquiries[0].total_enquiries;
    }
    if (enquiries.length != 0) {
        data.enquirie = enquiries;
    }
    return data;
 }

 /* getNearVenderByLatLong */
 async function getNearVenderByLatLong(where,latitude,longitude) {
    var nearRestVender = await sequelize.query(`SELECT
    become_partners.*,ROUND(COALESCE(rv.averagerating, 0),1) averagerating, (
        3959 * acos (
          cos ( radians(${latitude}) )
          * cos( radians( latitude ) )
          * cos( radians( longitude ) - radians(${longitude}) )
          + sin ( radians(${latitude}) )
          * sin( radians( latitude ) )
        )
      ) AS distance
    FROM become_partners  LEFT JOIN user_service_details ON  become_partners.userId = user_service_details.userId 
    LEFT JOIN (SELECT rv.reviewToId, AVG(rv.rating_no) averagerating FROM ratings rv GROUP BY rv.reviewToId) rv ON become_partners.userId=rv.reviewToId
    WHERE ${where} HAVING distance < 10000
    ORDER BY distance LIMIT 20 OFFSET 0`, { type: Sequelize.QueryTypes.SELECT });
      // var data = {nearRestVender: [] }
      // //console.log(total_review[0].total_review);
      // if (nearRestVender.length != 0) {
      //     data.nearRestVender = nearRestVender;
      // }
      console.log(nearRestVender)
      return nearRestVender;
   }

 /* getWorking */
async function getWorking(where) {
   var workingHours = await sequelize.query(`SELECT * FROM working_hours WHERE ${where} ORDER BY id ASC`, { type: Sequelize.QueryTypes.SELECT });
    return workingHours;
    
 }
 
 async function getServicesListByUser(where) {
    var services = await sequelize.query(`SELECT usd.*,sd.service_name FROM user_service_details  usd LEFT JOIN serviceDetails sd ON usd.serviceDetailId = sd.id  WHERE ${where}`, { type: Sequelize.QueryTypes.SELECT });
    return services;
 }

 async function getVenderByLatLong(where,latitude,longitude) {
  var total_vender = await sequelize.query(`SELECT count(become_partners.id) as total_vender FROM become_partners JOIN user_service_details ON become_partners.userId = user_service_details.userId  WHERE ${where} `, { type: Sequelize.QueryTypes.SELECT });
  var nearRestVender = await sequelize.query(`SELECT
  become_partners.*,concat('pancard/', become_partners.pancard) AS pancard,concat('aadharcard/', become_partners.adharcard_front) AS adharcard_front,concat('aadharcard/', become_partners.adharcard_back) AS adharcard_back,concat('logo/', become_partners.logo) AS logo,ROUND(COALESCE(rv.averagerating, 0),1) averagerating, (
      3959 * acos (
        cos ( radians(${latitude}) )
        * cos( radians( latitude ) )
        * cos( radians( longitude ) - radians(${longitude}))
        + sin ( radians(${latitude}) )
        * sin( radians( latitude ) )
      )
    ) AS distance
  FROM become_partners  LEFT JOIN user_service_details ON  become_partners.userId = user_service_details.userId 
  LEFT JOIN (SELECT rv.reviewToId, AVG(rv.rating_no) averagerating FROM ratings rv GROUP BY rv.reviewToId) rv ON become_partners.userId=rv.reviewToId
  WHERE ${where} HAVING distance < 10000
  ORDER BY distance `, { type: Sequelize.QueryTypes.SELECT });
    

    var data = { total: 0, nearRestVender: [] }
    
    if (total_vender.length != 0) {
        data.total = total_vender[0].total_vender;
    }
    if (nearRestVender.length != 0) {
        data.nearRestVender = nearRestVender;
    }
  
    return data;
 }

   async function getConvList(userId,limit,offset) {
    var conversationCount = await sequelize.query(`SELECT  COUNT(messages.id) AS conversationCount
    FROM messages
    LEFT JOIN users AS sender ON messages.messageById = sender.id
    LEFT JOIN users AS receiver ON messages.messageToId = receiver.id
    WHERE messages.id IN ( 
      SELECT MAX(id) 
      FROM messages 
      WHERE messageById = ${userId} OR messageToId = ${userId} 
      GROUP BY LEAST(messageById, messageToId), GREATEST(messageById, messageToId)
    )
    ORDER BY messages.id DESC`, { type: Sequelize.QueryTypes.SELECT });
    
      var conversationList = await sequelize.query(`SELECT  messages.*, sender.firstname AS byFirstname, sender.lastname AS byLastname,concat('profiles/',  sender.image) AS byProfile, receiver.firstname AS toFirstname, receiver.lastname AS toLastname, concat('profiles/',  receiver.image) AS toProfile, (SELECT COUNT(*) unread FROM messages messageCount join users u
on messages.messageToId=u.Id
 WHERE messageCount.is_read=0 AND (messageCount.messageById = messages.messageById AND messageCount.messageToId = messages.messageToId) GROUP BY u.id) as unread
    FROM messages
    
    LEFT JOIN users AS sender ON messages.messageById = sender.id
    LEFT JOIN users AS receiver ON messages.messageToId = receiver.id
    
    WHERE messages.id IN (
      SELECT MAX(id)

 
      FROM messages 
      WHERE messageById = ${userId} OR messageToId = ${userId} 
        
      GROUP BY LEAST(messageById, messageToId), GREATEST(messageById, messageToId)
    )
    ORDER BY messages.id DESC LIMIT ${limit} OFFSET ${offset};`, { type: Sequelize.QueryTypes.SELECT });
      

      var data = { total: 0, conversationList: [] }
      
      if (conversationCount.length != 0) {
          data.total = conversationCount[0].conversationCount;    
      }
      if (conversationList.length != 0) {
          data.conversationList = conversationList;
      }
      return data;
   }

   async function getvenderInfo(venderId) {
    var venderInfo = await sequelize.query(`SELECT *,concat('pancard/', become_partners.pancard) AS pancard,concat('aadharcard/', become_partners.adharcard_front) AS adharcard_front,concat('aadharcard/', become_partners.adharcard_back) AS adharcard_back,concat('logo/', become_partners.logo) AS logo FROM become_partners  WHERE userId = ${venderId}`, { type: Sequelize.QueryTypes.SELECT });
     return venderInfo
  }
  
  async function getBuisnessImages(venderId) {
    var buisnessDetails = await sequelize.query(`SELECT *,concat('buisnessimages/', buisness_details.image) AS image FROM buisness_details  WHERE userId = ${venderId}`, { type: Sequelize.QueryTypes.SELECT });
     return buisnessDetails;
  }
  
  async function getBuisnessImages(venderId) {
    var buisnessDetails = await sequelize.query(`SELECT *,concat('buisnessimages/', buisness_details.image) AS image FROM buisness_details  WHERE userId = ${venderId}`, { type: Sequelize.QueryTypes.SELECT });
     return buisnessDetails;
  }

  async function getUserInfo(userId) {
    var userDetails = await sequelize.query(`SELECT *,concat('profiles/', users.image) AS image FROM users  WHERE id = ${userId}`, { type: Sequelize.QueryTypes.SELECT });
     return userDetails;
  }

  async function getServices() {
    var userDetails = await sequelize.query(`SELECT *,concat('services/', serviceDetails.service_image) AS service_image FROM serviceDetails`, { type: Sequelize.QueryTypes.SELECT });
     return userDetails;
  }

  async function getRatingInfo(ratingId) {
    var reviewDetails = await sequelize.query(`SELECT ratings.*,users.firstname,users.lastname,concat('profiles/', users.image) AS profileImage    FROM ratings LEFT JOIN users ON users.id = ratings.reviewById WHERE ratings.id = ${ratingId}`, { type: Sequelize.QueryTypes.SELECT });
    return reviewDetails;
  }

module.exports = {
    getConvList: getConvList,
    getvenderInfo: getvenderInfo,
    getReviewList : getReviewList,
    getNearVenderByLatLong:getNearVenderByLatLong,
    getEnquiryList:getEnquiryList,
    getWorking:getWorking,
    getServicesListByUser:getServicesListByUser,
    getVenderByLatLong: getVenderByLatLong,
    getBuisnessImages:getBuisnessImages,
    getUserInfo:getUserInfo,
    getServices:getServices,
    getRatingInfo: getRatingInfo
}