const express = require('express');
const customerController = require('../controllers/customer');

const isAuth = require('../middleware/is-auth');
const router = express.Router();
const { body } = require('express-validator/check');

const { addCustomerValidation } = require("../validation/customer/customer.validation")

router.post('/register', addCustomerValidation, customerController.createCustomer);

module.exports = router;