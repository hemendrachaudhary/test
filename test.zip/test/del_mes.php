<?php 
$hostName="localhost";
    $dbName="test1";
    $userName="root";
    $passWord="";
    // $con=mysql_connect($hostName,$userName,$passWord);
    // $seldb=mysql_select_db($dbName);
    $con=mysqli_connect($hostName,$userName,$passWord);
     mysqli_select_db($con,$dbName); 
     $sql = "delete from `message` where `id`= '".$_GET['id']."'";
     mysqli_query($con,$sql);
header('location:userlist.php');
?>