<?php 
session_start();
$hostName="localhost";
    $dbName="test1";
    $userName="root";
    $passWord="";
    // $con=mysql_connect($hostName,$userName,$passWord);
    // $seldb=mysql_select_db($dbName);
    $con=mysqli_connect($hostName,$userName,$passWord);
     mysqli_select_db($con,$dbName); 
   
$selProfile=mysqli_query($con,"SELECT * FROM `user_info` where `id`!='".$_SESSION['userloginid']."'");
    while($rowProfile=mysqli_fetch_array($selProfile)){
    $user_id=$rowProfile['id'];
    $email=$rowProfile['email'];?>
<a href="chat.php?rid=<?php echo $user_id;?>"><?php echo $email;?></a>
<?php } ?>

