<?php 
 // include('function.php');
 // dbConnect();

session_start();
function dbRowInsert($table_name, $form_data)
{  
	$hostName="localhost";
    $dbName="test1";
    $userName="root";
    $passWord="";
    // $con=mysql_connect($hostName,$userName,$passWord);
    // $seldb=mysql_select_db($dbName);
    $con=mysqli_connect($hostName,$userName,$passWord);
     mysqli_select_db($con,$dbName); 
   
    $fields = array_keys($form_data);
    // build the query
    $sql = "INSERT INTO ".$table_name."
    (`".implode('`,`', $fields)."`)
    VALUES('".implode("','", $form_data)."')";
    
    
    return mysqli_query($con,$sql);
}

if(isset($_POST['seForm'])){
$flg=0;
if($_SESSION['userloginid']==""){
echo "<span class='error'>* Please Login</span>";
$flg=1;
}
if($flg==0){
$dateTime = date("Y-m-d H:i:s"); 
$data =  array(
'message_text' => $_POST['seMessagetwo'],
'message_sid'=> $_SESSION['userloginid'],
'message_rid'=>$_POST['message_rid'],
'message_time' => $dateTime
);	
dbRowInsert('message',$data);
echo "<span class='success'>message successfully Send!  </span>";
}
}



?>