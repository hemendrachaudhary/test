<?php 
session_start();
$hostName="localhost";
    $dbName="test1";
    $userName="root";
    $passWord="";
    // $con=mysql_connect($hostName,$userName,$passWord);
    // $seldb=mysql_select_db($dbName);
    $con=mysqli_connect($hostName,$userName,$passWord);
     mysqli_select_db($con,$dbName);
if(isset($_POST['loginAcount'])){
$useremail=$_POST['email'];
		$password=$_POST['password'];
		 $sql="SELECT * FROM `user_info` WHERE `email`= '".$useremail."'   and `password`= '".$password."' " ;
		 $result=mysqli_query($con,$sql);
    $numResult=mysqli_num_rows($result);
    if($numResult!=0){
        $rowCustomer=mysqli_fetch_array($result);
        $_SESSION['userloginid']=$rowCustomer['id'];
        $_SESSION['username']=$rowCustomer['email'];
       header('location:userlist.php');
        
    }
	    }
?>
<div class="col-md-12">
                <form id="user-login-form" method="post" style="display: block;">
                  <h3>Sign In your User Account
                  </h3>
                  <input type="hidden" name="loginAcount" value="loginAcount">
                  <span id="message2">
                  </span>
                  <div class="col-md-12 text-center">
                    <input type="text" class="form-control " name="email" placeholder="Enter Email">
                  </div>
                  <div class="col-md-12 text-center">
                    <input type="password" class="form-control " name="password" placeholder="Enter Password">
                  </div>
                  <div class="col-md-12 text-center">
                    <button class="btn f_btn" value="login" type="submit">LOG IN
                    </button>
                  </div>
                </form>
                <script src="js/jquery.min.js"></script>
               