<div class="col-md-6" id="se-enq-col">
                                                  <div id="send-enq-div">
                                                  <p>Send Message</p>
                                                  <form name="seFormtwo" id="seForm" class="">
                                                  <span id="message2"> </span>
                                                  <input type="hidden" name="seForm" value="seForm">
                                                  <input type="hidden" name="message_rid" value="<?php echo $_GET['rid'];?>">
                                                 
                                                     <textarea id="seMessagetwo" placeholder="Write your message .." class="form-control"  name="seMessagetwo" required="" ng-minlength="100"></textarea>
                                                    <div  id="seFormTwoNgMsg" style="position:absolute" class="ng-inactive">
                                                      <!---->
                                                      <!---->
                                                    </div>
                                                    
                                                    <button class="btn btn-lg btn-primary" type="submit">Send Message</button>
                                                   </form>
                                                </div>
                                                </div>

<script src="js/jquery.min.js"></script>
                                     <script>
                                              $(document).ready(function(){
                                                $('#seForm').submit(function(){
                                                  //disable the default form submission
                                                  event.preventDefault();
                                                  $.ajax({
                                                    url: 'process.php',
                                                    type: "POST",
                                                    data : new FormData($('#seForm')[0]),
                                                    processData: false,
                                                    contentType: false
                                                  }).done(function(data){
                                                    //if(data==1){
                                                      window.location.rolode("chat.php?rid=<?php echo $_GET['rid'];?>");
                                                   // }
                                                    $('#message2').html(data);
                                                  }).fail(function() {
                                                    alert( "Posting failed." );
                                                  });
                                                  // to prevent refreshing the whole page page
                                                  return false;
                                                } );
                                              });
                                          </script>
                                          <?php 
                                          session_start();
$hostName="localhost";
    $dbName="test1";
    $userName="root";
    $passWord="";
    $con=mysqli_connect($hostName,$userName,$passWord);
     mysqli_select_db($con,$dbName); 
  $message_text="";
 
$selProfile=mysqli_query($con,"SELECT * FROM `message` where `message_sid`='".$_SESSION['userloginid']."' || `message_rid`='".$_SESSION['userloginid']."'");
    while($rowProfile=mysqli_fetch_array($selProfile)){?>
  <?php  echo  $message_text=$rowProfile['message_text'].'<br>';?>
    <a href="del_mes.php?id=<?php echo $rowProfile['id'] ?>">delete</a>
<?php } ?>