<?php 
function dbConnect(){
 $hostName="localhost";
    $dbName="test1";
    $userName="root";
    $passWord="";
    $con=@mysql_connect($hostName,$userName,$passWord);
    $seldb=mysql_select_db($dbName);
}

function dbRowInsert($table_name, $form_data)
{
    // retrieve the keys of the array (column titles)
    $fields = array_keys($form_data);
    // build the query
    $sql = "INSERT INTO ".$table_name."
    (`".implode('`,`', $fields)."`)
    VALUES('".implode("','", $form_data)."')";
    // run and return the query result resource
    return mysql_query($sql) or die(mysql_error());
}




?>