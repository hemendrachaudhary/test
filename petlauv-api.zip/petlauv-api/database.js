const mysql = require('mysql');

const mc = mysql.createConnection({
    host     : 'localhost',
    user     : 'phpmyadmin',
    password : '123456',
    database : 'petlauv'
});
 
// connect to database
mc.connect();

module.exports = mc; 