const express = require('express');
const router = express.Router();
var todoList = require('../controller/appController');
var pet = require('../controller/petController');
var post = require('../controller/postController');
var deal = require('../controller/dealController');
var chat = require('../controller/chatController');
var contest = require('../controller/contestController');

router.route('/signup')
.post(todoList.create_a_user);

router.route('/allSiteUser')
.post(todoList.get_all_site_user);

router.route('/signupv2')
.post(todoList.create_user_new);

router.route('/login')
.post(todoList.user_login);

router.route('/changePassword')
.post(todoList.change_password);

router.route('/checkEmail')
.post(todoList.check_email);

router.route('/mySavePost')
.post(todoList.save_post);

router.route('/checkUsername')
.post(todoList.check_username);

router.route('/socialSignup')
.post(todoList.social_signup);

router.route('/setRating')
.post(contest.setRating);

router.route('/writeTestimonial')
.post(todoList.write_testimonial);

// router.route('/forgotPassword')
// .post(todoList.forgotPassword);

router.route('/changeNotifysetting')
.post(todoList.change_notify_setting);

router.route('/updateUser')
.post(todoList.update_a_user);

// router.route('/changeNotifysetting1')
// .get(todoList.change_notify);

 router.route('/petType')
.get(pet.get_pet_type);

 router.route('/petAdd')
.post(pet.create_a_pet);

 router.route('/followPet')
.post(pet.follow_pet);

router.route('/petInfo')
.post(pet.get_pet_info);

router.route('/getAllPet')
.post(pet.get_all_pet);

router.route('/deletePet')
.post(pet.delete_pet);

router.route('/getPetByUser')
.post(pet.get_pet_by_user);

router.route('/getNearbyPet')
.post(pet.get_near_by_pet);

 router.route('/createPost')
.post(post.create_a_post);

router.route('/getPostCat')
.get(post.get_post_type);

router.route('/getPetBreed')
.get(pet.get_pet_breed);


router.route('/getUserInfo')
.post(todoList.user_profile);

router.route('/getActiveDeal')
.post(deal.get_activeDeals);

router.route('/getpastDeals')
.post(deal.get_pastDeals);

router.route('/getFollowingPet')
.post(todoList.get_pet_following);

router.route('/otherPetFollowing')
.post(todoList.other_pet_following);

router.route('/getFollowerUser')
.post(todoList.get_user_follower);

router.route('/otherUserFollowing')
.post(todoList.other_user_following);

router.route('/otherUserFollower')
.post(todoList.other_user_follower);

router.route('/get_uninvited_follower_by_group_id')
.post(todoList.get_uninvited_follower_by_group_id);


router.route('/getFollowingUser')
.post(todoList.get_user_following);

router.route('/postSaved')
.post(post.post_saved);

router.route('/followUser')
.post(todoList.follow_user);

router.route('/pinPost')
.post(post.post_pin);

router.route('/stories')
.post(post.get_stories);

 router.route('/postLike')
.post(post.post_like);

 router.route('/searchByName')
.post(post.searchByName);
 
 router.route('/postComment')
.post(post.post_comment);

router.route('/postCommentLike')
.post(post.post_comment_like);

 router.route('/getCommentByPost')
.post(post.get_post_comment);

// chat module

router.route('/getChatHistory')
.post(chat.getChatHistory);

router.route('/send_msg')
.post(chat.send_msg);

router.route('/getMyChat')
.post(chat.getMyChat);

router.route('/deleteChat')
.post(chat.delete_chat);


// contest module
router.route('/getContest')
.post(contest.getContest);

router.route('/getContestInfo')
.post(contest.getContestInfo);

router.route('/addContestPost')
.post(contest.addContestPost);



router.route('/declaredContest')
.post(contest.declredContest);

router.route('/declaredContestInfo')
.post(contest.declredContestInfo);

// group
router.route('/createGroup')
.post(post.create_a_group);

router.route('/approwDisaprowgrouppost')
.post(post.approwDisaprowgrouppost);

router.route('/getGroup')
.post(post.get_all_group);

 router.route('/inviteToGroup')
.post(post.inviteToGroup);
	
router.route('/getMyGroup')
.post(post.get_my_group);

router.route('/getMyJoinedGroup')
.post(post.get_my_joined_group);

 router.route('/joinGroup')
.post(post.join_group);

 router.route('/createGroupPost')
.post(post.create_a_group_post);

router.route('/contestPostComment')
.post(post.contest_post_comment);

router.route('/contestPostShare')
.post(post.contest_post_share);

router.route('/postShare')
.post(post.post_share);

router.route('/contestPostRating')
.post(post.contest_post_rating);

router.route('/getNotification')
.post(post.getNotification);

 router.route('/petView')
.post(pet.view_pet);
 
  router.route('/petUpdate')
.post(pet.update_a_pet);

 router.route('/getGroupPost')
.post(post.get_group_stories);

router.route('/getGroupInfo')
.post(post.get_group_info);

router.route('/singlePost')
.post(post.singlePost);

router.route('/forgotPass')
.post(todoList.forgotPass);

router.route('/forgotPass')
.post(todoList.forgotPass);

router.route('/testNotification')
.post(todoList.testNotification);

module.exports = router;