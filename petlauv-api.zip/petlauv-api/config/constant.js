module.exports = Object.freeze({
    BASE_URL: 'http://182.70.254.235/petlauv-admin/assets/',
    BASE_PATH: '/var/www/html/petlauv-admin/assets/',
    API_URL: 'http://182.70.254.235/petlauv-admin/',
    });