var sql = require('./db.js');
var shortid = require('shortid');
var md5 = require('md5');
var Constant = require('../config/constant.js');

var Deals = function(deals){
    this.title  = deals.title;
    this.deals_desc  = deals.deals_desc;
    this.pet_type      = deals.pet_type;
    this.image   = deals.image
    this.location  = deals.location;
    this.deal_from  = deals.deal_from;
    this.deal_to     = deals.deal_to;
    this.status   = deals.status;
    this.updated_at = Date.now() ;
    this.created_at = Date.now();
};

Deals.getActiveDeals = function activeDeals(result){
 sql.connect(function(err){
   var que = "SELECT deals.*,pet_type.pet_type,CONCAT( '"+Constant.BASE_URL+"deals/', deals.image) AS image FROM deals JOIN pet_type ON pet_type.id = deals.pet_type  where deal_from <= "+Date.now()+" AND deal_to >= "+Date.now()+"  AND deals.status='1'";
   console.log(que);
   sql.query(que,result);
   })
 }

 Deals.getExpiredDeals = function expiredDeals(result){
 sql.connect(function(err){
   var que = "SELECT deals.*,pet_type.pet_type,CONCAT( '"+Constant.BASE_URL+"deals/', deals.image) AS image FROM deals JOIN pet_type ON pet_type.id = deals.pet_type  WHERE  deals.deal_to< '"+Date.now()+"' AND deals.status='1'";
   sql.query(que,result);
   })
 }

module.exports= Deals;
