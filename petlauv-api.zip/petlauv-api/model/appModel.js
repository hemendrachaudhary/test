var pool = require('./pool.js');
var sql = require('./db.js');
var shortid = require('shortid');
var md5 = require('md5');
var Constant = require('../config/constant.js');
//Task object constructor
var User = function(user){
    this.full_name  = user.full_name;
    this.user_name  = user.user_name;
    this.email      = user.email;
    this.password   = md5(user.password);
    this.country_code  = user.country_code;
    this.mobile_no  = user.mobile_no;
    this.gender     = user.gender;
    this.zip_code   = user.zip_code;
    this.about_think   = user.about_think;
    this.refer_by   = user.refer_by;
    this.refer_code = shortid.generate();
    this.device_token  = user.device_token;
    this.device_id  = user.device_id;
    this.device_type  = user.device_type;
    this.signup_by  = user.signup_by;
    this.lat  = user.lat;
    this.social_id  = user.social_id;
    this.longt  = user.longt;
    this.updated_at = Date.now() ;
    this.created_at = Date.now();
};
User.createUser = function createUser(newUser, result) {    
        sql.query("INSERT INTO users set ?", newUser, function (err, res) {
                
                if(err) {
                    console.log("error: ", err);
                    result(err, null);
                }
                else{
                    res.json({
                    "error":false,
                    "status": 200,
                    "message": 'User registration successfull.'
                 });
                }
            });           
};


User.checkUser = function CheckUser(email,user_name,result){
 sql.connect(function(err){
   var que = "SELECT users.*,CONCAT( '"+Constant.BASE_URL+"user/', users.user_image) AS user_image FROM users WHERE email = '"+email+"'  OR user_name = '"+user_name+"'";
   sql.query(que,result);
   })
 }

 User.checkUserBySocial = function CheckUser(social_id,result){
 sql.connect(function(err){
   var que = "SELECT users.*,CONCAT( '"+Constant.BASE_URL+"user/', users.user_image) AS user_image FROM users WHERE social_id = '"+social_id+"'";
   sql.query(que,result);
   })
 }

 User.checkEmail = function checkEmail(email,result) {
    sql.connect(function(err) {
        var que = "SELECT * FROM users WHERE email = '" + email + "'";
        sql.query(que, result);
    })
}

User.checkUserName = function checkUserName(user_name,result) {
    sql.connect(function(err) {
        var que = "SELECT * FROM users WHERE user_name = '"+user_name+"'";
        sql.query(que, result);
    })
}

 User.userLogin = function userLogin(email,password,result){
 sql.connect(function(err){
   var que = "SELECT users.*,CONCAT( '"+Constant.BASE_URL+"user/', users.user_image) AS user_image FROM users WHERE email = '"+email+"' AND password = '"+password+"'";
  sql.query(que,result);
   })
 }

 User.userInfo = async function(user_id,result){

   var que = "SELECT users.*,CONCAT( '"+Constant.BASE_URL+"user/', users.user_image) AS user_image FROM users WHERE id = '"+user_id+"'";
  //sql.query(que,result);
   const result1 = await pool.query(que); 
   return result1[0];
    }

 User.getCount = async function(table,where)
{
   var que = "SELECT COUNT(id) AS countData FROM "+table+"  WHERE "+where;
   const result = await pool.query(que); 
   return result[0];
}


User.getPostInfo = async function(user_id)
{
   //var que = "select * from post where user_id ='"+user_id+"'";
   var que = "select post.*,post_data.post_type,users.full_name,pet_info.pet_name,CONCAT( '" + Constant.BASE_URL + "pet/', pet_info.pet_image) AS pet_image,IFNULL((SELECT reaction_code FROM post_like WHERE post_like.user_id = '"+user_id+"' AND post_like.post_id = post.id),0) AS reaction_code,CONCAT( '" + Constant.BASE_URL + "post/', post_data.post_data_url) AS post_data_url from post_data JOIN post ON post.id = post_data.post_id JOIN `users` ON users.id = post.user_id  JOIN `pet_info` ON pet_info.id = post.pet_id  where post.user_id ='" + user_id + "' AND post.status='1' AND post.group_id='0' GROUP BY post_data.post_id ORDER BY post.id DESC";
   
   const result = await pool.query(que); 
   return result[0];
}
User.getPostData = async function(post_id,cb)
{
   var que = "select post_data.*, CONCAT( '"+Constant.BASE_URL+"post/', post_data.post_data_url) AS post_data_url from post_data where post_id ='"+post_id+"'";
   // const result = await pool.query(que); 
      sql.query(que,cb); 
  // return result[0];
}

User.getPetList = async function(user_id)
{
   var que = "SELECT pet_info.*,CONCAT( '"+Constant.BASE_URL+"pet/', pet_info.pet_image) AS pet_image FROM `pet_info` JOIN `users` ON users.id = pet_info.user_id  WHERE pet_info.user_id='"+user_id+"'";
   const result = await pool.query(que); 
   return result[0];
}


User.getPetFollowing = async function(user_id)
{
   var que = "SELECT pet_info.*,users.full_name,IFNULL((SELECT COUNT(*) FROM pet_followers WHERE pet_followers.pet_id=pet_info.id),0) AS pet_follower_count,IFNULL((SELECT COUNT(*) FROM view_pet WHERE view_pet.pet_id=pet_info.id),0) AS pet_view_count,IFNULL((SELECT COUNT(*) FROM post WHERE post.pet_id=pet_info.id),0) AS pet_post_count,CONCAT( '"+Constant.BASE_URL+"pet/', pet_info.pet_image) AS pet_image FROM `pet_info` JOIN `users` ON users.id = pet_info.user_id JOIN `pet_followers` ON pet_followers.pet_id = pet_info.id   WHERE pet_followers.user_id='"+user_id+"'";
   console.log(que);
   const result = await pool.query(que); 
   return result[0];
}

User.getuserFollowing = async function(user_id)
{
 var que = "SELECT user_followers.*,users.full_name,CONCAT( '"+Constant.BASE_URL+"user/', users.user_image) AS user_image FROM `user_followers` JOIN `users` ON users.id = user_followers.follow WHERE user_followers.followed_by = '"+user_id+"' ";
  //sql.query(que,result);
  const result1 = await pool.query(que); 
   return result1[0];
}
User.getuserFollower = async function(user_id)
{
 var que = "SELECT user_followers.*,users.full_name,CONCAT( '"+Constant.BASE_URL+"user/', users.user_image) AS user_image FROM `user_followers` JOIN `users` ON users.id = user_followers.followed_by WHERE user_followers.follow = '"+user_id+"' ";
   const result1 = await pool.query(que); 
   return result1[0];
}
User.getuseruninvitedFollower = async function(user_id,group_id,group_admin_id)
{
 var que = "SELECT user_followers.*,users.full_name,CONCAT( '"+Constant.BASE_URL+"user/', users.user_image) AS user_image FROM `user_followers` JOIN `users` ON users.id = user_followers.follow WHERE user_followers.followed_by = '"+user_id+"' and follow !='"+group_admin_id+"' and follow not in (select user_id from group_members where group_id = '"+group_id+"') ";
   const result1 = await pool.query(que); 
   return result1[0];
}

User.getGroupAdminByID = async function(group_id)
{
  var que= "select group_admin_user_id from groups where id="+group_id+"";
  const result1 = await pool.query(que); 
 
  return result1[0][0].group_admin_user_id;
}
User.getSavedPostList = async function(user_id,cb)
{
  var que = "SELECT post.*,post_data.post_type,post.pet_id,users.full_name,pet_info.pet_name,CONCAT( '" + Constant.BASE_URL + "pet/', pet_info.pet_image) AS pet_image,CONCAT( '" + Constant.BASE_URL + "post/', post_data.post_data_url) AS post_data_url,CONCAT( '"+Constant.BASE_URL+"post/', post_data.post_data_url) AS post_data_url ,(SELECT COUNT(*) FROM post_like WHERE post_like.post_id = post_saved.post_id) AS like_count,(SELECT COUNT(*) FROM post_like WHERE post_like.user_id = '"+user_id+"' AND post_like.post_id = post_saved.post_id) AS is_like,(SELECT reaction_code FROM post_like WHERE post_like.user_id = '"+user_id+"' AND post_like.post_id = post_saved.post_id) AS reaction_code,(SELECT COUNT(*) FROM post_saved WHERE post_saved.user_id = "+user_id+" AND post.id = post_saved.post_id) AS is_saved,(SELECT COUNT(*) FROM post_comment WHERE post_comment.post_id = post_saved.post_id) AS comment_count,(SELECT COUNT(*) FROM post_share WHERE `post_id` = post_saved.post_id) AS share_count FROM `post_saved` JOIN `post_data` ON post_data.post_id = post_saved.post_id JOIN `post` ON post.id = post_saved.post_id JOIN `users` ON users.id = post_saved.user_id  JOIN `pet_info` ON pet_info.id = post.pet_id WHERE post_saved.user_id="+user_id+" AND post.group_id='0' AND post.contest_id='0' AND post.status='1'  GROUP BY post_saved.post_id ";
  sql.query(que,cb); 
  //const result1 = await pool.query(que); 
  //return result1[0];
}

User.deleteUserFollow=function(user_id,follower_user_id,cb)
{
    var que = "delete from user_followers where follow='"+user_id+"' AND followed_by='"+follower_user_id+"'";
    sql.query(que, cb);
}

 User.userInfo1 =  function(user_id,cb){

   var que = "SELECT users.*,CONCAT( '"+Constant.BASE_URL+"user/', users.user_image) AS user_image FROM users WHERE id = '"+user_id+"'";
   sql.query(que, cb);
  }
  User.get_all_site_user =  function(user_id,cb){

   var que = "SELECT users.*,IFNULL((SELECT COUNT(*) FROM user_followers WHERE user_followers.follow=users.id),0) AS follower_count,IFNULL((SELECT COUNT(*) FROM user_followers WHERE user_followers.followed_by=users.id),0) AS following_count,IFNULL((SELECT COUNT(*) FROM post WHERE post.user_id=users.id),0) AS post_count,IFNULL((SELECT COUNT(*) FROM pet_info WHERE pet_info.user_id=users.id),0) AS pet_count,CONCAT( '"+Constant.BASE_URL+"user/', users.user_image) AS user_image FROM users WHERE id != '"+user_id+"'";
   console.log(que);
   sql.query(que, cb);
  }



module.exports= User;
