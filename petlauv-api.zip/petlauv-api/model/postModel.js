var sql = require('./db.js');
var Constant = require('../config/constant.js');
var pool = require('./pool.js');
const { forEach } = require('p-iteration');

//Task object constructor
var Post = function(postnew){
    this.user_id  = postnew.user_id;
    this.pet_id   = postnew.pet_id;
    this.post_cat_id   = postnew.post_cat_id;
    this.location = postnew.location;
    this.post_desc  = postnew.post_desc;
    this.updated_at = Date.now();
    this.created_at = Date.now();
    this.group_admin_aproove = postnew.group_admin_aproove;
};

Post.getPostType = function(cb)
{
   var que = "SELECT post_category.*,CONCAT( '"+Constant.BASE_URL+"postcat/', post_category.image_url) AS image_url FROM `post_category` WHERE status='1' AND is_deleted='1'";
   sql.query(que,cb); 
}

Post.deleteSavedPost=function(user_id,post_id,cb)
{
    var que = "delete from post_saved where user_id='"+user_id+"' AND post_id='"+post_id+"'";
    sql.query(que, cb);
}

Post.getAllpost = function(searchData,cb)
{
   var search = "";
   var shortBy= "";
   if(searchData.post_cat!="")
   {
    search += "AND post.post_cat_id IN("+searchData.post_cat+")";
   }

   if(searchData.pet_id!="")
   {
    search += " AND pet_info.pet_type IN("+searchData.pet_id+")";
   }
   if(searchData.search_data!="")
   {
    search += " AND (users.full_name LIKE '%"+searchData.search_data+"%' OR pet_info.pet_name LIKE '%"+searchData.search_data+"%') ";
   }
   if(searchData.short_by!="")
   {
    if(searchData.short_by=='1')
    {
     shortBy+= " ORDER BY like_count DESC";
    }
    if(searchData.short_by=='3')
    {
     shortBy+= " ORDER BY RAND()";
    }
    if(searchData.short_by=='2')
    {
     shortBy+= " ORDER BY created_at DESC";
    }
   }
   
   if(searchData.follow_post!="" && searchData.follow_post)
   {
    var que = "SELECT post.*,post_data.post_type,users.full_name,pet_info.pet_name,CONCAT( '" + Constant.BASE_URL + "pet/', pet_info.pet_image) AS pet_image,(SELECT COUNT(*)  FROM post_like WHERE post_like.post_id = post.id) AS like_count,IFNULL((SELECT reaction_code FROM post_like WHERE post_like.user_id = '"+searchData.user_id+"' AND post_like.post_id = post.id),0) AS reaction_code,CONCAT('"+Constant.BASE_URL+"post/', post_data.post_data_url) AS post_data_url FROM `post` JOIN `post_data` ON post_data.post_id = post.id JOIN `users` ON users.id = post.user_id JOIN `pet_info` ON pet_info.id = post.pet_id JOIN pet_followers ON post.pet_id = pet_followers.pet_id  WHERE  post.status='1' AND post.group_id='0' AND pet_followers.user_id = "+searchData.follow_post+" AND post.user_id != '"+searchData.user_id+"' "+search+"   GROUP BY post_data.post_id "+shortBy+" ORDER BY post.id DESC";
   }
   else
   {
    var que = "SELECT post.*,post_data.post_type,users.full_name,pet_info.pet_name,CONCAT( '" + Constant.BASE_URL + "pet/', pet_info.pet_image) AS pet_image,(SELECT COUNT(*)  FROM post_like WHERE post_like.post_id = post.id) AS like_count,IFNULL((SELECT reaction_code FROM post_like WHERE post_like.user_id = '"+searchData.user_id+"' AND post_like.post_id = post.id),0) AS reaction_code,CONCAT('"+Constant.BASE_URL+"post/', post_data.post_data_url) AS post_data_url FROM `post` JOIN `post_data` ON post_data.post_id = post.id JOIN `users` ON users.id = post.user_id JOIN `pet_info` ON pet_info.id = post.pet_id  WHERE  post.status='1' AND post.group_id='0' AND post.user_id != '"+searchData.user_id+"' "+search+"   GROUP BY post_data.post_id "+shortBy+" ORDER BY post.id DESC";
   }
   
   sql.query(que, cb);
    }

    Post.deleteLike=function(user_id,post_id,cb)
    {
    var que = "delete from post_like where user_id='"+user_id+"' AND post_id='"+post_id+"'";
    sql.query(que, cb);
    }
   
    Post.deleteCommentLike=function(user_id,post_comment_favourite,cb)
    {
    var que = "delete from post_comment_favourite where user_id='"+user_id+"' AND post_comment_id='"+post_comment_favourite+"'";
    sql.query(que, cb);
    }

    Post.getParentPost = async function(post_id) {
    var que = "select post_comment.*,(SELECT COUNT(*)  FROM post_comment_favourite WHERE post_comment_favourite.post_comment_id = post_comment.id) AS like_count,users.user_name,CONCAT( '" + Constant.BASE_URL + "user/', users.user_image) AS user_image From post_comment JOIN `users` ON post_comment.user_id = users.id   WHERE `parent_id`='0' AND post_id='" + post_id + "'";
    const result = await pool.query(que);
    return result[0];
    }

    Post.getSubComment = async function(post_id, cb) {
    var que = "select post_comment.*,(SELECT COUNT(*)  FROM post_comment_favourite WHERE post_comment_favourite.post_comment_id = post_comment.id) AS like_count,users.user_name,CONCAT( '" + Constant.BASE_URL + "user/', users.user_image) AS user_image From post_comment JOIN `users` ON post_comment.user_id = users.id WHERE `parent_id`='" + post_id + "'";
    sql.query(que, cb);
    }


    Post.getSubCommentLike = async function(post_comment_id,user_id) {
    var que = "SELECT * FROM post_comment_favourite WHERE  `user_id`='"+user_id+"' AND `post_comment_id` ='"+post_comment_id+"' ";
    const result = await pool.query(que);
    return result[0];
    }



Post.getUserLike = async function(user_id,name) {
    var que = "select users.id,users.full_name,CONCAT( '" + Constant.BASE_URL + "user/', users.user_image) AS user_image FROM `users` WHERE id != '"+user_id+"' AND full_name LIKE '%"+name+"%'";
    const result = await pool.query(que);
    return result[0];
}
Post.getPetLike = async function(name) {
    var que = "select pet_info.id,pet_info.pet_name,breed.breed,pet_type.pet_type,CONCAT( '" + Constant.BASE_URL + "pet/', pet_info.pet_image) AS pet_image FROM `pet_info` JOIN breed ON breed.id = pet_info.pet_breed JOIN pet_type ON pet_type.id = pet_info.pet_type WHERE pet_name LIKE '%"+name+"%'";
    const result = await pool.query(que);
    return result[0];
}
Post.getKeywordLike = async function(tag ) {
     var que = "select post_desc FROM `post` where post_desc LIKE '%"+tag+"%'";
    const result = await pool.query(que);
    return result[0];
}

Post.getPostLike = async function(name) {
    var que = "select post.id,post.post_desc,(SELECT COUNT(*) WHERE post_desc LIKE '%"+name+"%') AS post_count FROM `post`  WHERE post_desc LIKE '%"+name+"%'";
     const result = await pool.query(que);
    return result[0];
}
Post.getreletedkeyword = async function(data,tag) {
    var rdata=[];
    var final_result=[];
   await forEach(data, async (sdata) => {
    var str =sdata.post_desc;
    var ab = str.split(" "); 
     ab.forEach(myFunction);

function myFunction(nitem, index) {
  item = nitem.replace(/[^a-zA-Z ]/g, "");
  if(item.search(tag)!='-1'){
  rdata.push(item);
  }
}   

   

  });

     array_elements = rdata
     array_elements.sort();
     var current = null;
     var cnt = 0;
     for (var i = 0; i < array_elements.length; i++) {
        if (array_elements[i] != current) {
            if (cnt > 0) {
               
                final_result.push({tag:current,count:cnt}); 
            }
            current = array_elements[i];
            cnt = 1;
        } else {
            cnt++;
        }
    }
    if (cnt > 0) {
        final_result.push({tag:current,count:cnt}); 
    }
  

   return final_result;
}

    Post.getPostGroup = async function(user_id) 
   {
  // var search = "";
  // if(group_name!="")
  // {
  //   search  += "WHERE groups.group_name LIKE '%"+group_name+"%'"
  // }
  var que = "SELECT groups.*,CONCAT( '" + Constant.BASE_URL + "post_group/', groups.group_img) AS group_img,(SELECT COUNT(*) FROM group_members WHERE group_members.group_id =groups.id) AS member_count,(SELECT COUNT(*) FROM group_members WHERE group_members.group_id =groups.id AND group_members.user_id = '"+user_id+"') AS is_join FROM  `groups` WHERE groups.group_admin_user_id !='"+user_id+"' AND groups.privacy='0' and  groups.status='1' AND groups.is_deleted='1' having is_join=0 ";
  const result = await pool.query(que);
  return result[0];   
 }

Post.getMyJionGroup = async function(user_id) 
{
  // var search = "";
  // if(group_name!="")
  // {
  //   search  += "AND groups.group_name LIKE '%"+group_name+"%'"
  // }
  var que = "SELECT groups.*,CONCAT( '" + Constant.BASE_URL + "post_group/', groups.group_img) AS group_img,(SELECT COUNT(*) FROM group_members WHERE group_members.group_id =groups.id) AS member_count FROM `groups` JOIN group_members ON group_members.group_id = groups.id WHERE group_members.user_id ='"+user_id+"' AND groups.status='1' AND groups.is_deleted='1'";
  const result = await pool.query(que);
  return result[0];   
}

Post.getMyGroup = async function(user_id) 
{
  // var search = "";
  // if(group_name!="")
  // {
  //   search  += "AND groups.group_name LIKE '%"+group_name+"%'"
  // }
  var que = "SELECT groups.*,CONCAT( '" + Constant.BASE_URL + "post_group/', groups.group_img) AS group_img,(SELECT COUNT(*) FROM group_members WHERE group_members.group_id =groups.id) AS member_count FROM  `groups` WHERE groups.group_admin_user_id='"+user_id+"' AND groups.status='1' AND groups.is_deleted='1'";
  console.log(que);
  const result = await pool.query(que);
  return result[0];   
}


Post.checkPostGroup = async function(group_name,cb) 
{
  var que = "SELECT * FROM `groups` WHERE `group_name` = '"+group_name+"'";
  sql.query(que, cb);
}

Post.deleteMember = function(user_id, group_id, cb) {
    var que = "delete from group_members where user_id='" + user_id + "' AND group_id='" + group_id + "'";
    sql.query(que, cb);
}


Post.getGroupApprovedPost = function(searchData, cb) {
    var search = "";
    var shortBy = "";
    if (searchData.post_cat != "") {
        search += "AND post.post_cat_id IN(" + searchData.post_cat + ")";
    }
    
    if (searchData.group_id != "") {
        search += "AND post.group_id =" + searchData.group_id + "";
    } 
         search += " AND post.group_admin_aproove =1 ";
    if (searchData.pet_id != "") {
        search += " AND pet_info.pet_type IN(" + searchData.pet_id + ")";
    }
    if (searchData.search_data != "") {
        search += " AND (users.full_name LIKE '%" + searchData.search_data + "%' OR pet_info.pet_name LIKE '%" + searchData.search_data + "%') ";
    }
    if (searchData.short_by != "") {
        if (searchData.short_by == '1') {
            shortBy += "ORDER BY like_count DESC";
        }
        if (searchData.short_by == '3') {
            shortBy += "ORDER BY RAND()";
        }
        if (searchData.short_by == '2') {
            shortBy += "ORDER BY created_at DESC";
        }
    }

    var que = "SELECT post.*,post_data.post_type,users.full_name,pet_info.pet_name,CONCAT( '" + Constant.BASE_URL + "pet/', pet_info.pet_image) AS pet_image,(SELECT COUNT(*)  FROM post_like WHERE post_like.post_id = post.id) AS like_count,IFNULL((SELECT reaction_code FROM post_like WHERE post_like.user_id = '"+searchData.user_id+"' AND post_like.post_id = post.id),0) AS reaction_code,CONCAT('" + Constant.BASE_URL + "post/', post_data.post_data_url) AS post_data_url FROM `post` JOIN `post_data` ON post_data.post_id = post.id JOIN `users` ON users.id = post.user_id JOIN `pet_info` ON pet_info.id = post.pet_id  WHERE post.status='1' AND post.group_id !='0'   " + search + "   GROUP BY post_data.post_id " + shortBy + " ORDER BY post.id DESC";
   
    sql.query(que, cb);
}


Post.getGroupPost = function(searchData, cb) {
    var search = "";
    var shortBy = "";
    if (searchData.post_cat != "") {
        search += "AND post.post_cat_id IN(" + searchData.post_cat + ")";
    }
    
    if (searchData.group_id != "") {
        search += "AND post.group_id =" + searchData.group_id + " ";
    } 
   
    if(searchData.type!='Admin')
    {
      search += " AND (post.group_admin_aproove =1 or  post.user_id = '"+searchData.user_id+"' ) "; 
    }

    if (searchData.pet_id != "") {
        search += " AND pet_info.pet_type IN(" + searchData.pet_id + ")";
    }
    if (searchData.search_data != "") {
        search += " AND (users.full_name LIKE '%" + searchData.search_data + "%' OR pet_info.pet_name LIKE '%" + searchData.search_data + "%') ";
    }
    if (searchData.short_by != "") {
        if (searchData.short_by == '1') {
            shortBy += "ORDER BY like_count DESC";
        }
        if (searchData.short_by == '3') {
            shortBy += "ORDER BY RAND()";
        }
        if (searchData.short_by == '2') {
            shortBy += "ORDER BY created_at DESC";
        }
    }

    var que = "SELECT post.*,post_data.post_type,users.full_name,pet_info.pet_name,CONCAT( '" + Constant.BASE_URL + "pet/', pet_info.pet_image) AS pet_image,(SELECT COUNT(*)  FROM post_like WHERE post_like.post_id = post.id) AS like_count,IFNULL((SELECT reaction_code FROM post_like WHERE post_like.user_id = '"+searchData.user_id+"' AND post_like.post_id = post.id),0) AS reaction_code,CONCAT('" + Constant.BASE_URL + "post/', post_data.post_data_url) AS post_data_url FROM `post` JOIN `post_data` ON post_data.post_id = post.id JOIN `users` ON users.id = post.user_id JOIN `pet_info` ON pet_info.id = post.pet_id  WHERE post.status='1' AND post.group_id !='0'   " + search + "   GROUP BY post_data.post_id " + shortBy + " ORDER BY post.id DESC";
    sql.query(que, cb);
}

Post.getContestPost = function(searchData, cb) {
    var search = "";
    var shortBy = "";
    
    if (searchData.contest_id != "") {
        search += " AND post.contest_id =" + searchData.contest_id + "";
    } 
    if(searchData.post_id!=undefined )
    {
     search += " AND post.id =" + searchData.post_id + ""; 
    }
    var que = "SELECT post.*,post_data.post_type,users.full_name,pet_info.pet_name,CONCAT( '" + Constant.BASE_URL + "pet/', pet_info.pet_image) AS pet_image,(SELECT COUNT(*)  FROM contest_rating WHERE contest_rating.contest_post_id = post.id) AS like_count,CONCAT('" + Constant.BASE_URL + "post/', post_data.post_data_url) AS post_data_url FROM `post` JOIN `post_data` ON post_data.post_id = post.id JOIN `users` ON users.id = post.user_id JOIN `pet_info` ON pet_info.id = post.pet_id  WHERE post.status='1' AND post.contest_id !='0'   " + search  + " ORDER BY post.user_id="+searchData.user_id+" DESC";
   
    sql.query(que, cb);
}

Post.Winnerpost = async function(contest_id) {
   
    var que = "SELECT id,(SELECT avg(rating)  FROM contest_rating WHERE contest_rating.contest_post_id = post.id) AS total_rating from post where contest_id='"+contest_id+"' order by total_rating desc limit 1";
  
    const result = await pool.query(que);
  return result[0][0].id;   
}

Post.postInfoById = async function(post_id,user_id)
{
  var que = "SELECT post.*,post_data.post_type,users.full_name,pet_info.pet_name,CONCAT( '" + Constant.BASE_URL + "pet/', pet_info.pet_image) AS pet_image,IFNULL((SELECT reaction_code FROM post_like WHERE post_like.user_id = '"+user_id+"' AND post_like.post_id = '"+post_id+"'),0) AS reaction_code,(SELECT COUNT(*)  FROM post_like WHERE post_like.post_id = post.id) AS like_count,(SELECT COUNT(*)  FROM post_comment WHERE post_comment.post_id = post.id) AS comment_count,(SELECT COUNT(*)  FROM post_share WHERE post_share.post_id = post.id) AS share_count,(SELECT reaction_code FROM post_like WHERE post_like.user_id = '"+user_id+"' AND post_like.post_id = post.id) AS reaction_code,CONCAT('"+Constant.BASE_URL+"post/', post_data.post_data_url) AS post_data_url FROM `post` JOIN `post_data` ON post_data.post_id = post.id JOIN `users` ON users.id = post.user_id JOIN `pet_info` ON pet_info.id = post.pet_id  WHERE  post.status='1' AND post.id="+post_id+" GROUP BY post_data.post_id";
  const result = await pool.query(que);
  return result[0];   
}



 module.exports =Post;