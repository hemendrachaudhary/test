var pool = require('./pool.js');
var sql = require('./db.js');
var Constant = require('../config/constant.js');
var contest = function(contest){
    this.user_id  = contest.user_id;
    this.contest_id  = contest.contest_id;
    this.post_desc  = contest.post_desc;
    this.updated_at = Date.now();
    this.created_at = Date.now();
};


contest.getcontest = async function(user_id)
{
 //  var que = "SELECT contest.*,pet_type.pet_type,CONCAT('" + Constant.BASE_URL + "contest/', contest.image) AS image,(SELECT COUNT(*) FROM post WHERE post.contest_id=contest.id) AS entries_count,(SELECT COUNT(*) FROM post WHERE post.contest_id=contest.id AND post.user_id = '"+user_id+"' ) AS is_part FROM `contest` JOIN pet_type ON pet_type.id = contest.pet_type  where contest_from >= "+Date.now();
   var que = "SELECT contest.*,pet_type.pet_type,CONCAT('" + Constant.BASE_URL + "contest/', contest.image) AS image,(SELECT COUNT(*) FROM post WHERE post.contest_id=contest.id) AS entries_count,(SELECT COUNT(*) FROM post WHERE post.contest_id=contest.id AND post.user_id = '"+user_id+"' ) AS is_part FROM `contest` JOIN pet_type ON pet_type.id = contest.pet_type  where contest_from <= "+Date.now() +" AND contest_to >= "+Date.now() ;
    console.log(que);
   const result = await pool.query(que); 
   return result[0];
}
contest.getcontestInfo = async function(contest_id,user_id)
{
   var que = "SELECT contest.*,pet_type.pet_type,(SELECT COUNT(*) FROM post WHERE post.contest_id="+contest_id+") AS entries_count,(SELECT COUNT(*) FROM post WHERE post.contest_id=contest.id AND post.user_id = '"+user_id+"' ) AS is_part,CONCAT('" + Constant.BASE_URL + "contest/', contest.image) AS image FROM `contest` JOIN pet_type ON pet_type.id = contest.pet_type  where contest.id = "+contest_id;
   console.log(que);
   const result = await pool.query(que); 
   return result[0];
}
contest.getdeccontest = async function(user_id)
{
 //  var que = "SELECT contest.*,pet_type.pet_type,CONCAT('" + Constant.BASE_URL + "contest/', contest.image) AS image,(SELECT COUNT(*) FROM post WHERE post.contest_id=contest.id) AS entries_count,(SELECT COUNT(*) FROM post WHERE post.contest_id=contest.id AND post.user_id = '"+user_id+"' ) AS is_part FROM `contest` JOIN pet_type ON pet_type.id = contest.pet_type  where contest_from >= "+Date.now();
   var que = "SELECT contest.*,pet_type.pet_type,CONCAT('" + Constant.BASE_URL + "contest/', contest.image) AS image,(SELECT COUNT(*) FROM post WHERE post.contest_id=contest.id) AS entries_count,(SELECT COUNT(*) FROM post WHERE post.contest_id=contest.id AND post.user_id = '"+user_id+"' ) AS is_part FROM `contest` JOIN pet_type ON pet_type.id = contest.pet_type  where (SELECT COUNT(*) FROM post WHERE post.contest_id=contest.id) AND  contest_to < "+Date.now() ;
    console.log(que);
   const result = await pool.query(que); 
   return result[0];
}

contest.getdeccontestInfo = async function(contest_id,user_id)
{
   var que = "SELECT contest.*,pet_type.pet_type,(SELECT COUNT(*) FROM post WHERE post.contest_id="+contest_id+") AS entries_count,(SELECT COUNT(*) FROM post WHERE post.contest_id=contest.id AND post.user_id = '"+user_id+"' ) AS is_part,CONCAT('" + Constant.BASE_URL + "contest/', contest.image) AS image FROM `contest` JOIN pet_type ON pet_type.id = contest.pet_type  where  contest.id = "+contest_id;
   console.log(que);
   const result = await pool.query(que); 
   return result[0];
}



module.exports = contest;
