var pool = require('./pool.js');
var sql = require('./db.js');
var Constant = require('../config/constant.js');
//var sql = require('./mysql.js');
//Task object constructor
var Pet = function(pet){
    this.pet_name  = pet.pet_name;
    this.user_id   = pet.user_id;
    this.pet_dob   = pet.pet_dob;
    this.pet_about = pet.pet_about;
    this.pet_type  = pet.pet_type;
    this.other_pet_type = pet.other_pet_type;
    this.pet_breed = pet.pet_breed;
    this.gender    = pet.gender;
    this.is_neutered  = pet.is_neutered;
    this.updated_at = Date.now();
    this.created_at = Date.now();
};
Pet.deletePetFollower=function(user_id,pet_id,cb)
{
    var que = "delete from pet_followers where user_id='"+user_id+"' AND pet_id='"+pet_id+"'";
    sql.query(que, cb);
}


Pet.getPetInfo = async function(pet_id)
{
   var que = "SELECT pet_info.*,users.full_name,breed.breed,pet_type.pet_type,CONCAT( '"+Constant.BASE_URL+"user/', users.user_image) AS user_image,CONCAT( '"+Constant.BASE_URL+"pet/', pet_info.pet_image) AS pet_image FROM `pet_info` JOIN `users` ON users.id = pet_info.user_id left JOIN `breed` ON pet_info.pet_breed = breed.id left JOIN `pet_type` ON pet_info.pet_type = pet_type.id  WHERE pet_info.id='"+pet_id+"'";
  
   const result = await pool.query(que); 
   return result[0];
}
Pet.getCount = async function(table,where)
{
   var que = "SELECT COUNT(id) AS countData FROM "+table+"  WHERE "+where;
   const result = await pool.query(que); 
   return result[0];
}

Pet.getPostInfo = async function(pet_id,user_id)
{
   //var que = "select * from post where pet_id ='"+pet_id+"'";
    var que = "select post.*,post_data.post_type,users.full_name,pet_info.pet_name,CONCAT( '" + Constant.BASE_URL + "pet/', pet_info.pet_image) AS pet_image,IFNULL((SELECT reaction_code FROM post_like WHERE post_like.user_id = '"+user_id+"' AND post_like.post_id = post.id),0) AS reaction_code,CONCAT( '" + Constant.BASE_URL + "post/', post_data.post_data_url) AS post_data_url from post_data JOIN post ON post.id = post_data.post_id JOIN `users` ON users.id = post.user_id  JOIN `pet_info` ON pet_info.id = post.pet_id  where post.pet_id ='" + pet_id + "' AND post.status='1' AND post.group_id='0' GROUP BY post_data.post_id ORDER BY post.id DESC";
   console.log(que);
   const result = await pool.query(que); 
  return result[0];
}
Pet.getPostData = async function(post_id,cb)
{
   var que = "select post_data.*, CONCAT( '"+Constant.BASE_URL+"post/', post_data.post_data_url) AS post_data_url from post_data where post_id ='"+post_id+"'";
 
    // const result = await pool.query(que); 
      sql.query(que,cb); 
  // return result[0];
}
Pet.getPetByUser = function(user_id,cb)
{
   var que = "SELECT pet_info.*,users.full_name,breed.breed,pet_type.pet_type,CONCAT( '"+Constant.BASE_URL+"user/', users.user_image) AS user_image,IFNULL((SELECT COUNT(*) FROM pet_followers WHERE pet_followers.pet_id=pet_info.id),0) AS pet_follower_count,IFNULL((SELECT COUNT(*) FROM view_pet WHERE view_pet.pet_id=pet_info.id),0) AS pet_view_count,IFNULL((SELECT COUNT(*) FROM post WHERE post.pet_id=pet_info.id),0) AS pet_post_count,CONCAT( '"+Constant.BASE_URL+"pet/', pet_info.pet_image) AS pet_image FROM `pet_info` JOIN `users` ON users.id = pet_info.user_id left  JOIN `breed` ON pet_info.pet_breed = breed.id left JOIN `pet_type` ON pet_info.pet_type = pet_type.id  WHERE pet_info.user_id='"+user_id+"' ";
   console.log(que);
   sql.query(que,cb); 
}


Pet.getPetType = function(cb)
{
   var que = "SELECT pet_type.*,CONCAT( '"+Constant.BASE_URL+"pettype/', pet_type.image_url) AS image_url FROM `pet_type` WHERE status='1' AND is_deleted='1'";
   sql.query(que,cb); 
}


Pet.getPostImage = function(post_id,cb)
{
   var que = "SELECT post_data .*,CONCAT( '"+Constant.BASE_URL+"post/', post_data.post_data_url) AS post_data_url FROM `post_data` WHERE post_id='"+post_id+"'";
   sql.query(que,cb); 
}


Pet.getViewCount = function(pet_id,cb)
{
   var que = "SELECT count(*) AS viewCount FROM `view_pet`  WHERE pet_id='"+pet_id+"'";
   sql.query(que,cb); 
}
Pet.getFollowCount = function(pet_id,cb)
{
   var que = "SELECT count(*) AS followCount FROM `pet_followers`  WHERE pet_id='"+pet_id+"'";
   sql.query(que,cb); 
}
Pet.getPostCount = function(pet_id,cb)
{
   var que = "SELECT count(*) AS postCount FROM `post`  WHERE pet_id='"+pet_id+"'";
   sql.query(que,cb); 
}


// Pet.getPostInfo = function(pet_id,cb)
// {
//    var que = "SELECT post.*,pet_info.pet_name, FROM `post` JOIN pet_info on pet_info.id = post.pet_id WHERE post.pet_id='"+pet_id+"' ";
//    console.log(que);
//    sql.query(que,cb); 
// }

Pet.nearByPet = function(user_id,lat,lng,cb) {
   var que = "SELECT pet_info.*,users.full_name,users.lat,users.longt,breed.breed,pet_type.pet_type,(SELECT count(*) FROM pet_followers WHERE pet_followers.user_id='"+user_id+"' AND pet_followers.pet_id=pet_info.id) AS is_follow_pet,(SELECT count(*) FROM user_followers WHERE user_followers.followed_by='"+user_id+"' AND user_followers.follow=pet_info.user_id) AS is_follow_user,( 3959 * acos( cos( radians('"+lat+"') ) * cos( radians( lat ) ) * cos( radians( longt ) - radians('"+lng+"') ) + sin( radians('"+lat+"') ) * sin( radians( lat ) ) ) ) AS distance,CONCAT( '" + Constant.BASE_URL + "pet/', pet_info.pet_image) AS pet_image FROM `pet_info` JOIN `users` ON users.id = pet_info.user_id left  JOIN `breed` ON pet_info.pet_breed = breed.id left JOIN `pet_type` ON pet_info.pet_type = pet_type.id WHERE pet_info.user_id!='" + user_id + "'";
    //var que = "SELECT pet_info.*,pet_info.id as distance,users.full_name,users.lat,users.longt,breed.breed,pet_type.pet_type,(SELECT count(*) FROM pet_followers WHERE pet_followers.user_id='"+user_id+"' AND pet_followers.pet_id=pet_info.id) AS is_follow_pet,(SELECT count(*) FROM user_followers WHERE user_followers.followed_by='"+user_id+"' AND user_followers.follow=pet_info.user_id) AS is_follow_user,CONCAT( '" + Constant.BASE_URL + "pet/', pet_info.pet_image) AS pet_image FROM `pet_info` JOIN `users` ON users.id = pet_info.user_id left  JOIN `breed` ON pet_info.pet_breed = breed.id left JOIN `pet_type` ON pet_info.pet_type = pet_type.id WHERE pet_info.user_id!='" + user_id + "'";
    sql.query(que,cb);
    // const result = await pool.query(que);
    // return result[0];
}

Pet.deletePetData = async function(pet_id,cb)
{
   var que = "DELETE FROM `pet_info` WHERE id="+pet_id;
   //const result = await pool.query(que); 
   sql.query(que,cb); 
  // return result[0];
}
Pet.deletePostData = async function(pet_id,cb)
{
   var que = "DELETE FROM `post` WHERE pet_id="+pet_id;
   //const result = await pool.query(que); 
   sql.query(que,cb); 
  // return result[0];
}
Pet.deletePostData = async function(pet_id,cb)
{
   var que = "DELETE FROM `post` WHERE pet_id="+pet_id;
   //const result = await pool.query(que); 
   sql.query(que,cb); 
  // return result[0];
}
Pet.deleteViewData = async function(pet_id,cb)
{
   var que = "DELETE FROM `view_pet` WHERE pet_id="+pet_id;
   //const result = await pool.query(que); 
   sql.query(que,cb); 
  // return result[0];
}
Pet.deletePetFollowerData = async function(pet_id,cb)
{
   var que = "DELETE FROM `pet_followers` WHERE pet_id="+pet_id;
   //const result = await pool.query(que); 
   sql.query(que,cb); 
  // return result[0];
}
Pet.deletePetFollowerData = async function(pet_id,cb)
{
   var que = "DELETE FROM `pet_followers` WHERE pet_id="+pet_id;
   //const result = await pool.query(que); 
   sql.query(que,cb); 
  // return result[0];
}

Pet.get_all_pet = function(user_id,cb)
{
   var que = "SELECT pet_info.*,users.full_name,breed.breed,pet_type.pet_type,CONCAT( '"+Constant.BASE_URL+"user/', users.user_image) AS user_image,IFNULL((SELECT COUNT(*) FROM pet_followers WHERE pet_followers.pet_id=pet_info.id),0) AS pet_follower_count,IFNULL((SELECT COUNT(*) FROM view_pet WHERE view_pet.pet_id=pet_info.id),0) AS pet_view_count,IFNULL((SELECT COUNT(*) FROM post WHERE post.pet_id=pet_info.id),0) AS pet_post_count,CONCAT( '"+Constant.BASE_URL+"pet/', pet_info.pet_image) AS pet_image FROM `pet_info` JOIN `users` ON users.id = pet_info.user_id left  JOIN `breed` ON pet_info.pet_breed = breed.id left JOIN `pet_type` ON pet_info.pet_type = pet_type.id WHERE pet_info.user_id!='"+user_id+"'";
   sql.query(que,cb); 
}



 
  


module.exports = Pet 