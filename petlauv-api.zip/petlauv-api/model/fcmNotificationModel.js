 var FCM = require('fcm-node');
    var serverKey = 'AAAAzKdeikg:APA91bE_2UTvib6qeW7UFteGvEpK9h70I_ElvXF5gw8F9bXstRUksg69GZ2hNxlG5YT-27oWCmQyLuPpdMJDqeCQuoIl9Alq9rWZRT5UK-OgnXyWYjNVMYP97tFMR-Srwkpo_LQqB1G2'; //put your server key here
    var fcm = new FCM(serverKey);


    module.exports.pushnotification=function(user_name,msg,receiver_token,type)
{
   
 var message = { //this may vary according to the message type (single recipient, multicast, topic, et cetera)
        to: receiver_token, 
        
        notification: {
            title : user_name,
                 type : type,
                 body : decodeURIComponent(msg)  
        },
        
        data: {
                 title : user_name,
                 type : type,
                 body : decodeURIComponent(msg) 
                 }
    };
    
    fcm.send(message, function(err, response){
        if (err) {
            console.log("Something has gone wrong!");
        } else {
            console.log("Successfully sent with response: ", response);
        }
    });
};
