var pool = require('./pool.js');
var sql = require('./db.js');
var Constant = require('../config/constant.js');
var chat = function(){
    
    this.updated_at = Date.now();
    this.created_at = Date.now();
};

chat.getgroupbyid = async function(group_id,user_id)
{

  var que = "SELECT *,CONCAT( '"+Constant.BASE_URL+"post_group/',group_img) AS group_img_with_path,(SELECT COUNT(*) FROM group_members WHERE group_members.group_id =groups.id AND group_members.user_id = '"+user_id+"') AS is_join FROM `groups` WHERE `id` = '"+group_id+"' and `status` = 1 limit 1";
   const result = await pool.query(que); 
   return result[0]; 
}

chat.getNotification = async function(user_id)
{
    var que ="SELECT notify_id,notify_by,post_id,u1.full_name as notify_by_name,CONCAT( '"+Constant.BASE_URL+ "user/', u1.user_image) AS notify_by_img,notify_to,CONCAT( '"+Constant.BASE_URL+ "user/', u2.user_image) AS notify_to_img,u2.full_name as notify_to_name,group_id,g.group_name,title,noti_desc,n1.type,n1.status,n1.created_at FROM `notifications` n1     LEFT join groups g ON n1.group_id=g.id join users u1 join users u2  on u1.id =n1.notify_by and u2.id=n1.notify_to and n1.notify_to='"+user_id+"' order by notify_id desc"
       const result = await pool.query(que); 

   return result[0]; 
}
chat.checkGroupMemberType = async function(group_id,user_id)
{
var que ="select * from groups WHERE id= '"+group_id+"' and group_admin_user_id='"+user_id+"'";

  const result = await pool.query(que); 

  if(result[0].length>0)
  {
    return 'Admin';
  }
  else
  {
    return 'User';
  }
  
  
}

chat.getgroupmember = async function(group_id)
{
     
  var que = "SELECT group_members.* ,users.full_name,CONCAT('" + Constant.BASE_URL + "user/', users.user_image) AS user_image FROM `group_members` JOIN `users` ON users.id =group_members.user_id WHERE `group_id` = '"+group_id+"'";
   const result = await pool.query(que); 

   return result[0]; 
}

chat.getChatHistory = async function(user_id)
{
   var que = "SELECT *,CONCAT( '"+Constant.BASE_URL+"chat/', chat.media) AS media FROM `chat` WHERE `sender_user_id` = '"+user_id+"' or `receiver_user_id` = '"+user_id+"' order by id desc";
   const result = await pool.query(que); 
   return result[0];
}


chat.sendmsg = async function(sender_user_id,receiver_user_id,message,media,chat_type,gif)
{
   var que = "insert into chat (sender_user_id,receiver_user_id,media,message,chat_type,gif,chat_state,date) values ('"+sender_user_id+"','"+receiver_user_id+"','"+media+"','"+message+"','"+chat_type+"','"+gif+"',0,'"+Date.now()+"')";
   const result = await pool.query(que); 
   return result[0];
}
chat.saveNotification = async function(notify_by,notify_to,post_id='0',group_id='0',title,noti_desc,type)
{
  var que = "insert into notifications (notify_by,notify_to,post_id,group_id,title,noti_desc,type,updated_at,created_at) values ("+notify_by+","+notify_to+",'"+post_id+"','"+group_id+"','"+title+"','"+noti_desc+"',"+type+",'"+Date.now()+"','"+Date.now()+"')";
  const result = await pool.query(que); 
  return result[0];
}
chat.getUserDateails = async function(user_id)
{
   var que = "SELECT * FROM `users` WHERE `id` = '"+user_id+"'";
   const result = await pool.query(que); 
   return result[0];
}

chat.getPostDateails = async function(post_id)
{
   var que = "SELECT * FROM `post` WHERE `id` = '"+post_id+"'";
   const result = await pool.query(que); 
   return result[0];
}
chat.getOneToOneCaht = async function(sender_user_id,receiver_user_id)
{
   var que = "SELECT *,CONCAT( '"+Constant.BASE_URL+"chat/', chat.media) AS media FROM `chat` WHERE (`sender_user_id` = '"+sender_user_id+"' AND `receiver_user_id` = '"+receiver_user_id+"') or( `sender_user_id` = '"+receiver_user_id+"' and `receiver_user_id` = '"+sender_user_id+"' )";
   const result = await pool.query(que); 
   return result[0];
}

chat.deleteChatData = async function(chat_id,cb)
{
   var que = "DELETE FROM `chat` WHERE id="+chat_id;
   sql.query(que,cb); 
}



module.exports = chat;
