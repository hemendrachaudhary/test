var sql = require('./db.js');
var nodemailer = require('nodemailer');
//Get single row
module.exports.getSinglerow=function(table,where, cb)
{
    
   
        
        var que = "SELECT * FROM "+table+" WHERE "+where+" limit 1 "; 
        sql.query(que, cb);
        
    
}

// Get All data where

var smtpTransport = nodemailer.createTransport("SMTP",{
    service: "Gmail",
    auth: {
        user: "techvialinuxindore@gmail.com",
        pass: "techvialinux@123"
    }
});


// setup e-mail data with unicode symbols


// send mail with defined transport object


module.exports.sendmail = function(user_email,subject, msg){

  smtpTransport.sendMail({
        from: 'techvialinuxindore@gmail.com', // sender address
        to: user_email, // list of receivers
        subject: subject, // Subject line
html: '<body style="font-family: "Lato", sans-serif;font-weight: normal;word-break: break-word;margin:0px;padding:0px;"><div class="main_background" style="float: left;width: 100%;"><div class="temp_container" style="width:86%;margin-left: auto;margin-right: auto;"><div class="logo_area" style="float: left;width: 100%;text-align: center;padding: 2% 14% 2%;box-sizing: border-box;background-color: #eaeaea;"><img src="http://182.70.254.235/petlauv-admin/assets/images/logo.svg" alt="logo" style="width: 190px;"></div><div class="temp_container_in" style="float: left;width: 100%;box-sizing: border-box;margin: 0px 0px 20px;"><div class="temp_text" style="float: left;width: 100%;padding:0% 14% 2.5%;box-sizing: border-box;background-color: #eaeaea;border-radius: 2px;"><div class="temp_text_in" style="background-color: white;padding: 2% 4% 1%;box-sizing: border-box;float: left;width: 100%;border-radius: 3px;"><h1 style="color: #505050;font-size: 24px;margin: 0;padding: 0;font-weight: normal;">Hello  '+user_email+'</h1><br><p style="color: #505050;font-size: 16px;margin: 0;padding: 0;">'+subject+'</p><br><p style="color: #505050;font-size: 16px;margin: 0;padding: 0;"><b> '+msg+' </b></p><div class="btn_area" style="padding: 30px 25% 20px;"></div></div></div></div><div class="temp_footer" style="float: left;width: 100%;padding: 0px 0px 10px;box-sizing: border-box;text-align: center;border-bottom: 25px solid #EDEDED;">               <h6 style="margin: 0px; padding: 10px 0px 15px;font-weight: 300;font-size: 11px;color: #848484;">© 2019 PetLAUV. All Rights Reserved.</h6></div></div></div></body>' // html body
    }, function(err, info) {
        if (err)
            console.log(err)
    });

};


module.exports.getallDataWhere2=function(table,obj)
{

    sql.connect(function(err){
    var que = "SELECT * FROM  "+table+" WHERE ";
        var counter=1;
        for(var k in obj){
            if(counter==1)
            {
                que += k+"= '"+obj[k]+"'";
            }
            else
            {
                que += " AND "+k+"= '"+obj[k]+"' ";

            }
            counter++;
        }
   
  
  return  sql.query(que);
    })
}

module.exports.getallDataWhere=function(table,obj,cb)
{

    sql.connect(function(err){
    var que = "SELECT * FROM  "+table+" WHERE ";
        var counter=1;
        for(var k in obj){
            if(counter==1)
            {
                que += k+"= '"+obj[k]+"'";
            }
            else
            {
                que += " AND "+k+"= '"+obj[k]+"' ";

            }
            counter++;
        }
   
    sql.query(que, cb);
    })
}


module.exports.getallData=function(table,cb)
{
    var que = "SELECT * FROM "+table;
    con.query(que, cb);
}



// Insert data

module.exports.insert=function(table, obj, cb)
{
    sql.connect(function(err){
        var que = "INSERT INTO "+table+" (";
        var counter = 1;
        for(var k in obj){
            if (counter==1) {
                que += " `"+k+"`"
            }
            else{
                que += ", `"+k+"`"
            }
            counter++;
        }   
        que += ") VALUES ( ";
        var counter = 1;
            for (var l in obj) {
                if (counter==1) {
                    que += "'"+obj[l]+"'"
                }else{
                    que += ", "+"'"+obj[l]+"'"
                }       
                counter++;
            }
        que += ")";
        sql.query(que, cb);
    });
}


module.exports.update=function(table, where, obj, cb)
{
    var que = "UPDATE "+table+" SET ";
    var counter=1;
    for(var k in obj){
    if(counter==1){
         que += k+" = '"+obj[k]+"'"
    }
    else{
    que += ", "+k+" = '"+obj[k]+"'"
    }
     counter++;
    }
    var key = Object.keys(where);
    que += " WHERE "+key[0]+" = '"+where[key[0]]+"'";
    sql.query(que, cb);
}


module.exports.getCount = function(table,where, cb)
{
   var que = "SELECT COUNT(id) AS countData FROM "+table+"  WHERE "+where;
   sql.query(que,cb); 
}

module.exports.getRatingCount = function(table,where, cb)
{
   //var que = "SELECT AVG(rating) AS countData FROM "+table+"  WHERE "+where;
   var que = "SELECT COUNT(rating) AS countData FROM "+table+"  WHERE "+where;
   console.log(que);
   sql.query(que,cb); 
}
module.exports.getAvg = function(table,where, cb)
{
   var que = "SELECT AVG(rating) AS avgData FROM "+table+"  WHERE "+where;
   sql.query(que,cb); 
}


module.exports.getPetByUser = function(user_id,cb)
{
   var que = "SELECT pet_info.*,CONCAT( '"+Constant.BASE_URL+"pet/', pet_info.pet_image) AS pet_image FROM `pet_info` WHERE user_id='"+user_id+"'";
   
   sql.query(que,cb); 
}

module.exports.getAllpostByUser = function(user_id,cb)
{
   var que = "SELECT post.*,pet_info.pet_name, FROM `post` JOIN pet_info on pet_info.id = post.pet_id WHERE post.pet_id='"+user_id+"' ";
  
   sql.query(que,cb); 
}




module.exports.checkUser = function(user_id,cb)
{
   var que = "SELECT * FROM users  WHERE status='1' AND id='"+user_id+"'";
   sql.query(que,cb); 
}

module.exports.checkUserEmail = function(email,cb)
{
   var que = "SELECT * FROM users  WHERE status='1' AND email='"+email+"'";
   sql.query(que,cb); 
}


