
var Common = require('../model/commonModel.js');
var formidable = require('formidable');
var User = require('../model/appModel.js');
var chat = require('../model/chatModel.js');
var _ = require('lodash/array');
var constant = require('../config/constant.js');
var fs = require('fs');
var path = require('path');
var fcmNotifi = require('../model/fcmNotificationModel.js');

exports.send_msg = async function(req, res) {
 var form = new formidable.IncomingForm();
 form.parse(req, function (err, fields, files) {
  if(fields.sender_user_id=="" || fields.sender_user_id==undefined ||  fields.receiver_user_id=="" || fields.receiver_user_id==undefined || fields.chat_type=="" || fields.chat_type==undefined)
  {
   res.send({
          "error":true,
          "status": 400,
          "message": 'Please provide all field.'
      });
  }
else{
    Common.checkUser(fields.sender_user_id, async function(err, userData) {
      if (userData.length > 0){
     var media ="";
     var message = "";  
     var gif_name = "";  
     var currentTime =  Date.now();
     if(fields.chat_type=="image" || fields.chat_type=="audio")
     {
    var oldpath = files.filetoupload.path;
    var newpath = constant.BASE_PATH+'chat/'+currentTime+path.extname(files.filetoupload.name);
    fs.rename(oldpath, newpath, function (err) {
        if (err) throw err;
        
      });
     media = currentTime+path.extname(files.filetoupload.name);
    }
    if(fields.message!="" || fields.message!=undefined)
    {
      message =  fields.message; 
    }
    if(fields.gif_name!="" || fields.gif_name!=undefined)
    {
      gif_name =  fields.gif_name; 
    }
    
     var data = await chat.sendmsg(fields.sender_user_id,fields.receiver_user_id,message,media,fields.chat_type,gif_name);
      res.send({
           "error":false,
            "status": 200,
            "message": 'Message Send Succssfully !'
        });
                            var receiveruser = await chat.getUserDateails(fields.receiver_user_id);
                             var sender = await chat.getUserDateails(fields.sender_user_id);
                            fcmNotifi.pushnotification('PetLUAV',sender[0].full_name+' sent you message', receiveruser[0].device_token, '1004');
                            chat.saveNotification(fields.sender_user_id,fields.receiver_user_id,0,0,'Message',' sent you message','1004');
    }
    else
    {
      res.send({
      "error":false,
      "status": 2,
      "message": 'User not active please contact to admin.'
      });
    } 
   });
 }
 });

};

exports.send_msg1 = async function(req,res){
  if(req.body.sender_user_id=="" || req.body.sender_user_id==undefined ||  req.body.receiver_user_id=="" || req.body.receiver_user_id==undefined || req.body.message=="" || req.body.message==undefined)
  {
   res.send({
          "error":true,
          "status": 400,
          "message": 'Please provide all field.'
      });
  }
  
 
 var data = await chat.sendmsg(req.body.sender_user_id,req.body.receiver_user_id,req.body.message);
      res.send({
           "error":false,
            "status": 200,
            "message": 'Message Send Succssfully !'
        });

  
};

exports.getMyChat = async function(req,res){
if(req.body.sender_user_id=="" ||  req.body.sender_user_id==undefined || req.body.receiver_user_id=="" ||  req.body.receiver_user_id==undefined)
  {
   res.send({
          "error":true,
          "status": 400,
          "message": 'Please provide all field.'
      });
  }
 var cdata = await chat.getOneToOneCaht(req.body.sender_user_id,req.body.receiver_user_id);

var x=[];
 cdata.reduce(function(promiesRes,chatdata,index){
           return promiesRes 
           .then(function(data){
        return new Promise(async function(resolve, reject) {
        
        
       var  sender =   await chat.getUserDateails(chatdata.sender_user_id); 
       var  reciver = await chat.getUserDateails(chatdata.receiver_user_id); 
       chatdata.sender_name=sender[0].full_name;
       chatdata.sender_img=constant.BASE_URL+'user/'+sender[0].user_image;
       chatdata.reciver_img=constant.BASE_URL+'user/'+reciver[0].user_image;
      chatdata.reciver_name=reciver[0].full_name;
        x.push(chatdata);
        resolve(x);
         });
        
        }).catch(function(error) {
          
          res.send({
              "status": 400,
              "error" : true,
              "message": 'some error'
          });
          
      })
      },Promise.resolve(null)).then(arrayOfResults => { // Do something with all results
          
         res.send({
            "status": 200,
            "message": 'User data',
            'data' : arrayOfResults
        });

           
        });


}


exports.getChatHistory = async function(req,res){
  if(req.body.user_id=="" ||  req.body.user_id==undefined)
  {
   res.send({
          "error":true,
          "status": 400,
          "message": 'Please provide all field.'
      });
  }
  
 
 var ChatHistory = await chat.getChatHistory(req.body.user_id);


var x=[];
 ChatHistory.reduce(function(promiesRes,chatdata,index){
           return promiesRes 
           .then(function(data){
        return new Promise(async function(resolve, reject) {
        
          if(chatdata.sender_user_id==req.body.user_id){  chatdata.user_pub_id=chatdata.receiver_user_id;  }       
       else { chatdata.user_pub_id=chatdata.sender_user_id; }
       var  sender =   await chat.getUserDateails(chatdata.sender_user_id); 
       var  reciver = await chat.getUserDateails(chatdata.receiver_user_id); 
       chatdata.sender_name=sender[0].full_name;
       chatdata.sender_img=constant.BASE_URL+'user/'+sender[0].user_image;
       chatdata.reciver_img=constant.BASE_URL+'user/'+reciver[0].user_image;
      chatdata.reciver_name=reciver[0].full_name;
        x.push(chatdata);
        resolve(x);
         });
        
        }).catch(function(error) {
          
          res.send({
              "status": 400,
              "error" : true,
              "message": 'some error'
          });
          
      })
      },Promise.resolve(null)).then(arrayOfResults => { // Do something with all results
           var final_result = [];
           final_result = _.uniqBy(arrayOfResults, 'user_pub_id');
           if(final_result.length>0){
         res.send({
            "status": 200,
            "message": 'User data.',
            'data' : final_result
        });
       }
       else
       {
        res.send({
            "status": 400,
            "message": 'No data found.'
        });
       }

           
        });

};


exports.delete_chat = async function(req,res){
  if(req.body.chat_id=="" || req.body.user_id=="" )
  {
   res.send({
          "error":true,
          "status": 400,
          "message": 'Please check all fields.'
      });
  }
  else
  {
    Common.checkUser(req.body.user_id, async function(err, userData) {
    if (userData.length > 0)
    {
    var  chatinfo          = await   chat.deleteChatData(req.body.chat_id);
    res.send({
              "error": true,
              "status": 200,
              "message": 'Chat deleted successfull.'
          });
    }
    else
    {
          res.send({
              "error": true,
              "status": 2,
              "message": 'User not active please contact to admin.'
          });
      }

  });
    
  }
 } 








