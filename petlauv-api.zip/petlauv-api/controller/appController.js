var User = require('../model/appModel.js');
var Common = require('../model/commonModel.js');
var formidable = require('formidable');
var md5 = require('md5');
var fs = require('fs');
var path = require('path');
var constant = require('../config/constant.js');
var shortid = require('shortid');
var fcmNotifi = require('../model/fcmNotificationModel.js');
var chat = require('../model/chatModel.js');


exports.create_a_user = function(req, res) {
 var form = new formidable.IncomingForm();
 form.parse(req, function (err, fields, files) {
  var oldpath = files.filetoupload.path;
    var new_user = new User(fields);
   if(!new_user.email || !new_user.password){
   res.send({
            "error":true,
            "status": 400,
            "message": 'Please provide user email and password.'
        });
        }
else{
  User.checkUser(new_user.email,new_user.user_name,function(err,result){
  if(result.length==0){
    var currentTime = Date.now();
    var newpath = constant.BASE_PATH+'user/'+currentTime+path.extname(files.filetoupload.name);
    fs.rename(oldpath, newpath, function (err) {
        if (err) throw err;
          // console.log(err);
          // res.status(200).send({ error:true, message: 'Done' });
     
      });
     new_user.user_image = currentTime+path.extname(files.filetoupload.name);
   Common.insert('users',new_user, function(err, user) {
    if(err)
      res.send(err);
     res.send({
            "error":false,
            "status": 200,
            "message": 'User registration successfull.'
        });
    });
   }
   else if(result[0].mobile_no==new_user.mobile_no)
   {
     res.send({
            "error":true,
            "status": 400,
            "message": 'Mobile no. already exits.'
        });
   }
   else if(result[0].email==new_user.email)
   {
     res.send({
            "error":true,
            "status": 400,
            "message": 'Email already exits.'
        });
   }
   else
   {
    res.send({
            "error":true,
            "status": 400,
            "message": 'User name already exits.'
        });
   }
  });
 }
 });   
};
exports.create_user_new = function(req, res) {
  var new_user = new User(req.body);
  if(!req.body.full_name || req.body.full_name==undefined || !req.body.user_name ||req.body.user_name==undefined || !req.body.password || req.body.password==undefined || !req.body.email || req.body.email==undefined ){
   res.send({
            "error":true,
            "status": 400,
            "message": 'Please provide full name,user name ,email and password.'
        });
        }
        else
        {
        User.checkUser(req.body.email,req.body.user_name,function(err,result){
          if(result.length==0){
            req.body.created_at=Date.now();
            req.body.updated_at=Date.now();
            req.body.password=md5(req.body.password);
            req.body.refer_code = shortid.generate();
        Common.insert('users',req.body, function(err, user) {
     if(err)
      res.send(err);
     Common.sendmail(req.body.email,'PETLAUV Account Verification','Hi ,You`re almost done! Make sure you verify your email address and we`ll finish setting up  for you. And thank you for choosing PetLAUV! <a href='+constant.API_URL+'/web/User/verifyEmail/'+user.insertId+'>Click here</a>');
     res.send({
            "error":false,
            "status": 200,
            "message": 'Thanks! your account has been successfully created.'
        });
    });
   }
  
   else if(result[0].email==new_user.email)
   {
     res.send({
            "error":true,
            "status": 400,
            "message": 'Email already exists.'
        });
   }
   else
   {
    res.send({
            "error":true,
            "status": 400,
            "message": 'User name already exists.'
        });
   }
        });

        }
  }


  exports.social_signup = function(req, res) {
  var new_user = new User(req.body);
  if(!req.body.full_name || req.body.full_name==undefined || !req.body.user_name ||req.body.user_name==undefined || !req.body.password || req.body.password==undefined){
   res.send({
            "error":true,
            "status": 400,
            "message": 'Please provide full name,user name ,email and password.'
        });
        }
        else
        {
        if(req.body.email!="" || req.body.email!=undefined)
        {
        User.checkUser(req.body.email,req.body.user_name,function(err,result){
          if(result.length==0){
            var password = req.body.password;
            req.body.created_at=Date.now();
            req.body.updated_at=Date.now();
            req.body.password=md5(req.body.password);
            req.body.refer_code = shortid.generate();
        Common.insert('users',req.body, function(err, user) {
     if(err)
      res.send(err);
     Common.sendmail(req.body.email,'PETLAUV Login Credential','Hi ,You have successfully created an acount.Please find your password for future reference </br> '+password+' thank you for choosing PetLAUV!');
      User.userInfo1(user.insertId, function(err, userData) {
     res.send({
            "error":false,
            "status": 200,
            "message": 'Thanks! your account has been successfully created.',
            "data": userData[0]
        });
    });
   });   
   }
  
   else if(result[0].email==new_user.email)
   {
     res.send({
            "error":true,
            "status": 200,
            "message": 'Login successfull.',
            "data": result[0]
        });
   }
   else
   {
    res.send({
            "error":true,
            "status": 200,
            "message": 'Login successfull.',
            "data": result[0]
        });
      }
    });
  }
  else
  {
      User.checkUserBySocial(req.body.social_id, function(err, result1) {
          if(result1.length==0){
            var password = req.body.password;
            req.body.created_at=Date.now();
            req.body.updated_at=Date.now();
            req.body.password=md5(req.body.password);
            req.body.refer_code = shortid.generate();
        Common.insert('users',req.body, function(err, user) {
     if(err)
      res.send(err);
     User.checkUserBySocial(req.body.social_id, function(err, userData) {
     res.send({
            "error":false,
            "status": 200,
            "message": 'Thanks! your account has been successfully created.',
            "data": userData[0]
        });
    });
   });   
   }
   else
   {
    res.send({
            "error":true,
            "status": 200,
            "message": 'Login successfull.',
            "data": result1[0]
        });
      }
    });
  }

  }


  }






exports.user_login = function(req, res) {
  var new_user = new User(req.body);
  //handles null error 
   if(!new_user.email || !new_user.password){
   res.send({
            "error":true,
            "status": 400,
            "message": 'Please provide user email and password.'
        });
        }
else{
 
  Common.checkUserEmail(new_user.email, function(err, userData) {
                if (userData.length > 0) {
                   
                    Common.update('users', {
                        'email': new_user.email
                    }, {
                        device_token: new_user.device_token
                    }, function(err, user) {
                        if (err) {
                            res.send({
                                "error": false,
                                "status": 400,
                                "message": 'Please try agian.'
                            });
                        } else {
                                     User.userLogin(new_user.email,new_user.password, function(err, result) {
   
                                    if(err)
                                      res.send(err);
                                      if(result.length)
                                      {
                                        if(result[0].status=='0')
                                        {
                                          res.send({
                                              "error":  true,
                                              "status": 2,
                                              "message": 'User not active please contact to admin.'
                                          });
                                        }
                                        else
                                        {
                                          // fcmNotifi.pushnotification(result[0].full_name, 'Login successfull', result[0].device_token, '70001');
                                           res.send({
                                            "error":false,
                                            "status": 200,
                                            "message": 'User data.',
                                            "data" : result[0]
                                        });
                                       }
                                      }
                                      else{
                                         res.send({
                                            "error":  true,
                                            "status": 400,
                                            "message": 'Email or password is incorrect.'
                                        });
                                      }
                                     });
                        }
                    });
                } else {
                    res.send({
                        "error": true,
                        "status": 400,
                        "message": 'You are not a registered user.'
                    });
                }
            });

   }
 };

exports.user_profile = async function(req, res) {
    if (req.body.user_id == "" && req.body.info_user_id) {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please provide user.'
        });
    } else {
        var info_user_id = req.body.info_user_id;
        var userinfo = await User.userInfo(info_user_id);
        var postCount = await User.getCount('post', 'user_id=' + info_user_id);
        //var  userFollowerCount = await   User.getCount('user_followers','user_id=' + req.body.user_id);
        var userFollowingCount = await User.getCount('user_followers', "followed_by='" + info_user_id + "'");
        var userFollowerCount = await User.getCount('user_followers', "follow='" + info_user_id + "'");
        var userFollow = await User.getCount('user_followers', "follow='" + info_user_id + "' AND followed_by='" + req.body.user_id + "'");
        var petFollowingCount = await User.getCount('pet_followers', 'user_id=' + info_user_id);
        var getPetList = await User.getPetList(info_user_id);
        var savedPostList = await User.getSavedPostList(info_user_id);
        var postinfo = await User.getPostInfo(info_user_id);
        var tempData = [];


        postinfo.reduce(function(promiesRes, postelement, index) {
            return promiesRes
                .then(function(data) {
                    return new Promise(function(resolve, reject) {
                        User.getPostData(postelement.id, function(err, postdata) {
                            postelement.img = postdata;
                            postinfo.post = postelement;
                            resolve(postinfo);
                        });
                    })
                })
                .then(function(data) {
                    return new Promise(function(resolve, reject) {
                        Common.getCount('post_comment', 'post_id=' + postelement.id, function(err, postCommentdata) {
                            postinfo.post.comment_count = postCommentdata[0].countData;
                            resolve(postinfo);
                        });
                    })
                }).then(function(data) {
                    return new Promise(function(resolve, reject) {
                        Common.getCount('post_like', 'post_id=' + postelement.id, function(err, postLikedata) {
                            postinfo.post.like_count = postLikedata[0].countData;


                            resolve(postinfo);
                        });
                    })
                }).then(function(data) {
                    return new Promise(function(resolve, reject) {
                        Common.getCount('post_share', 'post_id=' + postelement.id, function(err, postsharedata) {
                            postinfo.post.share_count = postsharedata[0].countData;


                            resolve(postinfo);
                        });
                    })
                }).then(function(data) {
                    return new Promise(function(resolve, reject) {
                        Common.getCount('post_saved', "post_id='" + postelement.id + "' AND user_id='" + req.body.user_id + "'", function(err, postsavedata) {
                            if (postsavedata[0].countData > 0) {
                                postinfo.post.is_saved = 1;
                            } else {
                                postinfo.post.is_saved = 0;
                            }

                            resolve(postinfo);
                        });
                    })
                }).then(function(data) {
                    return new Promise(function(resolve, reject) {
                        Common.getCount('post', "id='" + postelement.id + "' AND user_id='" + info_user_id + "'", function(err, postpindata) {
                            if (postpindata[0].countData > 0) {
                                postinfo.post.is_pin = 1;
                            } else {
                                postinfo.post.is_pin = 0;
                            }

                            resolve(postinfo);
                        });
                    })
                }).then(function(data) {
                    return new Promise(function(resolve, reject) {
                        Common.getCount('post_like', "post_id='" + postelement.id + "' AND user_id='" + req.body.user_id + "'", function(err, postpindata) {
                            if (postpindata[0].countData > 0) {
                                postinfo.post.is_like = 1;
                            } else {
                                postinfo.post.is_like = 0;
                            }

                            resolve(postinfo);
                        });
                    })
                })
                .catch(function(error) {
                   
                    res.send({
                        "error": true,
                        "status": 400,
                        "message": 'some error'
                    });
                    return error.message;
                })
        }, Promise.resolve(null)).then(arrayOfResults => { // Do something with all results
            if (arrayOfResults != null) {
                userinfo[0].post = arrayOfResults;
            } else {
                userinfo[0].post = [];
            }
            if (userFollow[0].countData > 0) {
                userinfo[0].is_follow = 1;
            } else {
                userinfo[0].is_follow = 0;
            }
            userinfo[0].post_count = postCount[0].countData;
            userinfo[0].user_follower_count = userFollowerCount[0].countData;
            userinfo[0].user_following_count = userFollowingCount[0].countData;
            userinfo[0].pet_following_count = petFollowingCount[0].countData;
            userinfo[0].petList = getPetList;
            userinfo[0].savedPostList = savedPostList;
            res.send({
                "error": false,
                "status": 200,
                "message": 'User data',
                'data': userinfo[0]
            });

        });
    }
};



exports.get_pet_following = async function(req, res) {
    if (req.body.user_id == "") {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please provide user.'
        });
    } else {
        var petData = await User.getPetFollowing(req.body.user_id);
        if (petData.length > 0) {

            petData.reduce(function(promiesRes, followingement, index) {
                return promiesRes
                    .then(function(data) {
                        return new Promise(function(resolve, reject) {
                            Common.getSinglerow('pet_followers', "pet_id='" + followingement.id + "' AND user_id='" + req.body.user_id + "'", function(err, following) {

                                if (following.length > 0) {
                                    followingement.is_follow = 1;
                                } else {
                                    followingement.is_follow = 0;
                                }
                                resolve(petData);
                            });
                        });
                    });

            }, Promise.resolve(null)).then(arrayOfResults => { // Do something with all results
                res.send({
                    "error": false,
                    "status": 200,
                    "message": 'Following pet data.',
                    'data': arrayOfResults
                });
            })

        } else {
            res.send({
                "error": true,
                "status": 400,
                "message": 'No Data found.'
            });
        }

    }
};

exports.other_pet_following = async function(req, res) {
    if (req.body.user_id == "") {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please provide user.'
        });
    } else {
        var petData = await User.getPetFollowing(req.body.info_user_id);
        if (petData.length > 0) {

            petData.reduce(function(promiesRes, followingement, index) {
                return promiesRes
                    .then(function(data) {
                        return new Promise(function(resolve, reject) {
                            Common.getSinglerow('pet_followers', "pet_id='" + followingement.id + "' AND user_id='" + req.body.user_id + "'", function(err, following) {

                                if (following.length > 0) {
                                    followingement.is_follow = 1;
                                } else {
                                    followingement.is_follow = 0;
                                }
                                resolve(petData);
                            });
                        });
                    });

            }, Promise.resolve(null)).then(arrayOfResults => { // Do something with all results
                res.send({
                    "error": false,
                    "status": 200,
                    "message": 'Following pet data.',
                    'data': arrayOfResults
                });
            })

        } else {
            res.send({
                "error": true,
                "status": 400,
                "message": 'No Data found.'
            });
        }

    }
};

exports.get_user_following = async function(req, res) {
    if (req.body.user_id == "") {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please provide user.'
        });
    } else {
        var followingData = await User.getuserFollowing(req.body.user_id);
        if (followingData.length > 0) {

            res.send({
                "error": true,
                "status": 200,
                "message": 'Following user data.',
                "data": followingData
            });
        } else {
            res.send({
                "error": true,
                "status": 400,
                "message": 'No Data found.'
            });
        }

    }
};
exports.get_uninvited_follower_by_group_id = async function(req,res)
{

  if (req.body.user_id == "" || req.body.groupd_id=="") {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please provide user.'
        });
    } else {
        var group_admin_id = await  User.getGroupAdminByID(req.body.group_id);
        var followerData = await User.getuseruninvitedFollower(req.body.user_id,req.body.group_id,group_admin_id);
         res.send({
                    "error": false,
                    "status": 200,
                    "message": 'Follower data',
                    'data': followerData
                });
 
    }
}
exports.get_user_follower = async function(req, res) {
    if (req.body.user_id == "") {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please provide user.'
        });
    } else {
       var followerData = await User.getuserFollower(req.body.user_id);
       
        if (followerData.length > 0) {

            followerData.reduce(function(promiesRes, followerement, index) {
                return promiesRes
                    .then(function(data) {
                        return new Promise(function(resolve, reject) {
                            Common.getSinglerow('user_followers', "follow='" + followerement.followed_by + "' AND followed_by='" + req.body.user_id + "'", function(err, follower) {

                                if (follower.length > 0) {
                                    followerement.is_follow = 1;
                                } else {
                                    followerement.is_follow = 0;
                                }
                                resolve(followerData);
                            });
                        });
                    });

            }, Promise.resolve(null)).then(arrayOfResults => { // Do something with all results
                
                res.send({
                    "error": false,
                    "status": 200,
                    "message": 'Follower data',
                    'data': arrayOfResults
                });

            });

            // res.send({
            // "error":true,
            // "status":200,
            // "message": 'Follower user data.',
            // "data" : followerData
            // });
        } else {
            res.send({
                "error": true,
                "status": 400,
                "message": 'No Data found.'
            });
        }

    }
};

exports.other_user_follower = async function(req, res) {
    if (req.body.user_id == "") {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please provide user.'
        });
    } else {
       var followerData = await User.getuserFollower(req.body.info_user_id);
       
        if (followerData.length > 0) {

            followerData.reduce(function(promiesRes, followerement, index) {
                return promiesRes
                    .then(function(data) {
                        return new Promise(function(resolve, reject) {
                            Common.getSinglerow('user_followers', "follow='" + followerement.followed_by + "' AND followed_by='" + req.body.user_id + "'", function(err, follower) {

                                if (follower.length > 0) {
                                    followerement.is_follow = 1;
                                } else {
                                    followerement.is_follow = 0;
                                }
                                resolve(followerData);
                            });
                        });
                    });

            }, Promise.resolve(null)).then(arrayOfResults => { // Do something with all results
                
                res.send({
                    "error": false,
                    "status": 200,
                    "message": 'Follower data',
                    'data': arrayOfResults
                });

            });

            // res.send({
            // "error":true,
            // "status":200,
            // "message": 'Follower user data.',
            // "data" : followerData
            // });
        } else {
            res.send({
                "error": true,
                "status": 400,
                "message": 'No Data found.'
            });
        }

    }
};
exports.other_user_following = async function(req, res) {
    if (req.body.user_id == "") {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please provide user.'
        });
    } else {
       var followerData = await User.getuserFollowing(req.body.info_user_id);
       
        if (followerData.length > 0) {

            followerData.reduce(function(promiesRes, followerement, index) {
                return promiesRes
                    .then(function(data) {
                        return new Promise(function(resolve, reject) {
                            Common.getSinglerow('user_followers', "follow='" + followerement.following + "' AND followed_by='" + req.body.user_id + "'", function(err, follower) {

                                if (follower.length > 0) {
                                    followerement.is_follow = 1;
                                } else {
                                    followerement.is_follow = 0;
                                }
                                resolve(followerData);
                            });
                        });
                    });

            }, Promise.resolve(null)).then(arrayOfResults => { // Do something with all results
                
                res.send({
                    "error": false,
                    "status": 200,
                    "message": 'Following data',
                    'data': arrayOfResults
                });

            });

            // res.send({
            // "error":true,
            // "status":200,
            // "message": 'Follower user data.',
            // "data" : followerData
            // });
        } else {
            res.send({
                "error": true,
                "status": 400,
                "message": 'No Data found.'
            });
        }

    }
};

exports.save_post = function(req,res){
  if(!req.body.user_id)
 {
          res.send({
          "error":true,
          "status": 400,
          "message": 'Please provide post and user.'
      });
  }
  else
  {

   User.getSavedPostList(req.body.user_id,function(err,postinfo){
    if(err)
      res.send(err);
    if(postinfo.length>0){
       console.log(postinfo);
      postinfo.reduce(function(promiesRes,postelement,index){
       return promiesRes 
        .then(function(data){
        return new Promise(function(resolve, reject) {
         User.getPostData(postelement.id,function(err,postdata){
         postelement.img =postdata;
         postinfo.post=postelement;
         postinfo.is_save=1;
         resolve(postinfo);
         });
         })
         }).catch(function(error) {
         res.send({
              "error":true,
              "status": 400,
              "message": 'some error'
          });
          return error.message;
      })
      },Promise.resolve(null)).then(arrayOfResults => { // Do something with all results
        res.send({
           "error":false,
            "status": 200,
            "message": 'Post data',
            'data' : arrayOfResults
        });

    });
     }
     else
     {
      res.send({
          "error":false,
          "status": 400,
          "message": 'No data found.',
      });
     } 
    });
  }
  
  
};



exports.follow_user = function(req, res) {
    if (!req.body.follow || !req.body.followed_by) {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please provide user.'
        });
    } else {
        req.body.updated_at = Date.now();
        req.body.created_at = Date.now();
        Common.checkUser(req.body.followed_by, function(err, userData) {

            if (userData.length > 0) {

                Common.getallDataWhere('user_followers', {
                    'follow': req.body.follow,
                    'followed_by': req.body.followed_by
                }, function(err, result) {
                    if (result.length == 0) {
                        Common.insert('user_followers', req.body,async function(err, userFollow) {
                            {
                                if (err)
                                    res.send(err);
                                res.send({
                                    "error": false,
                                    "status": 200,
                                    "message": 'User followed.',
                                    'is_follow': 1
                                });
                              var followuser = await chat.getUserDateails(req.body.follow);

                            fcmNotifi.pushnotification('PetLUAV',' started follwoing  you', followuser[0].device_token, '1003');
                            chat.saveNotification(req.body.followed_by,req.body.follow,0,0,'Following','started follwoing you','1003');

                            }
                        });
                    } else {
                        User.deleteUserFollow(req.body.follow, req.body.followed_by, function(err, userfollowRemove) {
                            if (err)
                                res.send(err);
                            res.send({
                                "error": false,
                                "status": 200,
                                "message": 'User unfollow successfull.',
                                'is_follow': 0
                            });
                        });
                    }
                });

            } else {
                res.send({
                    "error": true,
                    "status": 400,
                    "message": 'User not active please contact to admin.'
                });
            }

        });
    }
};





exports.change_password = function(req, res) {
    if (!req.body.old_password || !req.body.user_id || !req.body.new_password) {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please check all the fields.'
        });
        return;
    } else {
        Common.checkUser(req.body.user_id, function(err, userData) {
            if (userData.length > 0) {
                var old_password = md5(req.body.old_password);
                var new_password = md5(req.body.new_password);

                Common.getallDataWhere('users', {
                    id: req.body.user_id
                }, function(err, result) {
                    if (err) {
                        res.send({
                            "error": true,
                            "status": 400,
                            "message": 'Please try again.'
                        });
                    } else {
                        if (result.length > 0) {
                            if (result[0].password != old_password) {
                                res.send({
                                    "error": true,
                                    "status": 400,
                                    "message": 'Old password not match.'
                                });
                            } else {
                                Common.update('users', {
                                    id: req.body.user_id
                                }, {
                                    password: new_password,
                                    updated_at: Date.now()
                                }, function(err, result) {
                                    if (err) {
                                        res.send({
                                            "error": true,
                                            "status": 400,
                                            "message": 'Please try again.'
                                        });
                                    } else {
                                        res.send({
                                            "error": false,
                                            "status": 200,
                                            "message": 'Password updated successfully.'
                                        });
                                    }
                                });
                            }
                        } else {
                            res.send({
                                "error": true,
                                "status": 400,
                                "message": 'User not available.'
                            });
                        }
                    }
                });
            } else {
                res.send({
                    "error": true,
                    "status": 2,
                    "message": 'User not active please contact to admin.'
                });
            }

        });

    }

};


exports.change_notify_setting = function(req, res) {
    if (!req.body.user_id || !req.body.status) {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please check all the fields.'
        });
        return;
    } else {
        Common.checkUser(req.body.user_id, function(err, userData) {
            if (userData.length > 0) {
                var is_notify = req.body.status;
                Common.getallDataWhere('users', {
                    id: req.body.user_id
                }, function(err, result) {
                    if (err) {
                        res.send({
                            "error": true,
                            "status": 400,
                            "message": 'Please try again.'
                        });
                    } else {
                        if (result.length > 0) {
                            Common.update('users', {
                                id: req.body.user_id
                            }, {
                                is_notify: is_notify,
                                updated_at: Date.now()
                            }, function(err, result) {
                                if (err) {
                                    res.send({
                                        "error": true,
                                        "status": 400,
                                        "message": 'Please try again.'
                                    });
                                } else {
                                    res.send({
                                        "error": false,
                                        "status": 200,
                                        "message": 'Notification setting changed.'
                                    });
                                }
                            });

                        } else {
                            res.send({
                                "error": true,
                                "status": 400,
                                "message": 'User not available.'
                            });
                        }
                    }
                });
            } else {
                res.send({
                    "error": true,
                    "status": 2,
                    "message": 'User not active please contact to admin.'
                });
            }
        });

    }

};

exports.write_testimonial = function(req, res) {
    if (!req.body.user_id || !req.body.title) {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please check all fields.'
        });
    } else {
        Common.checkUser(req.body.user_id, function(err, userData) {
            if (userData.length > 0) {
                req.body.updated_at = Date.now();
                req.body.created_at = Date.now();
                Common.insert('write_testimonial', req.body, function(err, testimonial) {
                    {
                        if (err)
                            res.send({
                                "error": false,
                                "status": 400,
                                "message": 'Please try after some time.'
                            });
                        res.send({
                            "error": false,
                            "status": 200,
                            "message": 'testimonial successfully added.'
                        });
                    }
                });
            } else {
                res.send({
                    "error": true,
                    "status": 2,
                    "message": 'User not active please contact to admin.'
                });
            }
        });

    }
};


exports.check_email = function(req, res) {
    if (!req.body.user_id || !req.body.email) {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please check all the fields.'
        });
        return;
    } else {
        Common.checkUser(req.body.user_id, function(err, userData) {
            if (userData.length > 0) {
                User.checkEmail(req.body.email, function(err, userEmail) {
                    if (userEmail.length > 0) {
                        res.send({
                            "error": false,
                            "status": 400,
                            "message": 'Email not available.'
                        });
                    } else {
                        res.send({
                            "error": true,
                            "status": 200,
                            "message": 'Email available.'
                        });
                    }
                });
            } else {
                res.send({
                    "error": true,
                    "status": 2,
                    "message": 'User not active please contact to admin.'
                });
            }
        });

    }

};


exports.check_username = function(req, res) {
    if (!req.body.user_id || !req.body.user_name) {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please check all the fields.'
        });
        return;
    } else {
        Common.checkUser(req.body.user_id, function(err, userData) {
            if (userData.length > 0) {
                User.checkUserName(req.body.user_name, function(err, userName) {
                    if (userName.length > 0) {
                        res.send({
                            "error": false,
                            "status": 400,
                            "message": 'User name not available.'
                        });
                    } else {
                        res.send({
                            "error": true,
                            "status": 200,
                            "message": 'User name available.'
                        });
                    }
                });
            } else {
                res.send({
                    "error": true,
                    "status": 2,
                    "message": 'User not active please contact to admin.'
                });
            }
        });

    }

};

exports.update_a_user = function(req, res) {
    var form = new formidable.IncomingForm();
    form.parse(req, function(err, fields, files) {
        //var new_user = new User(fields);
        
        if (!fields.email) {
            res.send({
                "error": true,
                "status": 400,
                "message": 'Please provide user email.'
            });
        } else {
            Common.checkUser(fields.user_id, function(err, userData) {
                if (userData.length > 0) {
                  var user_image = userData[0].user_image
                    var currentTime = Date.now();
                    if (JSON.stringify(files) != '{}') {
                        var oldpath = files.filetoupload.path;
                        var newpath = constant.BASE_PATH + 'user/' + currentTime + path.extname(files.filetoupload.name);
                        fs.rename(oldpath, newpath, function(err) {
                            if (err) throw err;
                            // console.log(err);
                            // res.status(200).send({ error:true, message: 'Done' });

                        });
                        user_image = currentTime + path.extname(files.filetoupload.name);
                    }
                    Common.update('users', {
                        'id': fields.user_id
                    }, {
                        full_name: fields.full_name,
                        user_name: fields.user_name,
                        email: fields.email,
                        gender: fields.gender,
                        country_code: '',
                        mobile_no: fields.mobile_no,
                        user_image: user_image,
                        about_think:fields.about_think,
                        lat:fields.lat,
                        longt :fields.longt,
                        }, function(err, user) {
                        if (err) {
                            res.send({
                                "error": false,
                                "status": 400,
                                "message": 'Please try agian.'
                            });
                        } else {
                            User.userInfo1(fields.user_id, function(err, userInfo) {
                                if(err)
                                {
                                res.send({
                                "error": false,
                                "status": 400,
                                "message": 'Please Try after some time.',
                             });
                                }
                            else{
                            res.send({
                                "error": false,
                                "status": 200,
                                "message": 'User information updated.',
                                "data":userInfo[0]
                            });
                            }
                         });
                        }
                    });
                } else {
                    res.send({
                        "error": true,
                        "status": 2,
                        "message": 'User not active please contact to admin.'
                    });
                }
            });
        }
    });
};

exports.testNotification = function(req,res){
fcmNotifi.pushnotification('testusername', 'test notification', req.body.token, '70001');
 res.send({
                        "error": false,
                        "status": 2,
                        "message": 'notification sent.'
                    });
}
exports.forgotPass = function(req,res){
    if (!req.body.email) {
      res.send({"error":true,"status":400,"message":'Please check all the fields.'});  
       return;
    } else {

        Common.checkUserEmail(req.body.email, function(err, userData) {
                if (userData.length > 0) {
                      var password = shortid.generate();
                        var rand_paasword = md5(password);
                    var currentTime = Date.now();

                     Common.sendmail(req.body.email,'Forgot Password','Your new password is '+password);
                    Common.update('users', {
                        'email': req.body.email
                    }, {
                        password: rand_paasword
                    }, function(err, user) {
                        if (err) {
                            res.send({
                                "error": false,
                                "status": 400,
                                "message": 'Please try agian.'
                            });
                        } else {
                            res.send({
                                "error": false,
                                "status": 200,
                                "message": 'Password send successfully. Please check your email'
                            });
                        }
                    });
                } else {
                    res.send({
                        "error": true,
                        "status": 2,
                        "message": 'User not active please contact to admin.'
                    });
                }
            });
    }

};

exports.get_all_site_user = function(req,res){
  Common.checkUser(req.body.user_id, function(err, userData) {
  if (userData.length > 0) {
  User.get_all_site_user(req.body.user_id,function(err,userData){
      if(err)
      res.send(err)
    if(userData.length>0){
      res.send({
          "error":false,
          "status": 200,
          "message": 'Users data.',
          "data" : userData
      });
     }
     else
     {
      res.send({
          "error":true,
          "status": 400,
          "message": 'No data found.',
      });
     } 
    });
   } else {
          res.send({
              "error": true,
              "status": 400,
              "message": 'User not active please contact to admin.'
          });
      }
  
});
};




