var contest = require('../model/contestModel.js');
var formidable = require('formidable');
var User = require('../model/appModel.js');
var Common = require('../model/commonModel.js');
var formidable = require('formidable');
var fs = require('fs');
var path = require('path');
var constant = require('../config/constant.js');
var Postdata = require('../model/postModel.js');
var _ = require('lodash/array');


exports.getContest = async function(req,res){
 var contestdata = await contest.getcontest(req.body.user_id);
 if(contestdata.length>0)
{
  res.send({
            "status": 200,
            "message": 'User data',
            'data' : contestdata
        });
}
else{
  res.send({
            "status": 400,
            "message": 'No contest found',
            'data' : contestdata
        });
}


};

exports.declredContest = async function(req,res){
 var contestdata = await contest.getdeccontest(req.body.user_id);
 if(contestdata.length>0)
{
  res.send({
            "status": 200,
            "message": 'Declred Contest data',
            'data' : contestdata
        });
}
else{
  res.send({
            "status": 400,
            "message": 'No Declred found',
            'data' : contestdata
        });
}
 
};




exports.setRating = async function(req,res){
 
 if(req.body.contest_id ==undefined || req.body.contest_id==''
  || req.body.contest_post_id ==undefined || req.body.contest_post_id==''
  || req.body.user_id ==undefined || req.body.user_id==''
  || req.body.rating ==undefined || req.body.rating==''  )
 {
          res.send({
          "error":true,
          "status": 400,
          "message": 'Please provide contest id,contest post id, user id and rating.'
      });
  }else {
  		req.body.updated_at = Date.now();
        req.body.created_at = Date.now();
        console.log(req.body)
  	 Common.insert('contest_rating',req.body, function(err, pet) {
  res.send({

            "status": 200,
            "message": 'Thanks for rating us'
            
        });
 });

 }
};

exports.declredContestInfo = async function(req,res){
 if(!req.body.contest_id)
 {
          res.send({
          "error":true,
          "status": 400,
          "message": 'Please provide contest_id.'
      });
  }
  else
  {
     var contestData = await contest.getdeccontestInfo(req.body.contest_id,req.body.user_id);
     var post_id = await Postdata.Winnerpost(req.body.contest_id);
     if(contestData.length==0) {
        
      res.send({
            "error": true,
            "status": 400,
            "message": 'No Group Found.'
        });
     }
     else { 
      
      Postdata.getContestPost({"user_id":req.body.user_id,"post_id":post_id,"pet_id":"","contest_id":req.body.contest_id,"search_data":"","short_by":""},function(err,postinfo){
      if(err)
      res.send(err)
    if(postinfo.length>0){
      postinfo.reduce(function(promiesRes,postelement,index){
       return promiesRes 
        .then(function(data){
        return new Promise(function(resolve, reject) {
         User.getPostData(postelement.id,function(err,postdata){
         postelement.img =postdata;
         postinfo.post=postelement;
         resolve(postinfo);
        });
         })
         })
          .then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post_comment','post_id=' + postelement.id ,function(err,postCommentdata){
          postinfo.post.comment_count= postCommentdata[0].countData;
         resolve(postinfo);
        });
         })
        })
        
         .then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post_share','post_id=' + postelement.id ,function(err,postsharedata){
          postinfo.post.share_count= postsharedata[0].countData;
         
         
         resolve(postinfo);
        });
         })
         }).then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post_saved',"post_id='" + postelement.id + "' AND user_id='"+req.body.user_id+"'" ,function(err,postsavedata){
          if(postsavedata[0].countData >0)
          {
          postinfo.post.is_saved= 1;
          }
          else
          {
           postinfo.post.is_saved= 0;
          }
         
         resolve(postinfo);
        });
         })
         }).then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getRatingCount('contest_rating',"contest_post_id='" + postelement.id + "'" ,function(err,likedata){
          console.log(likedata)
          if(likedata.length >0)
          {
          postinfo.post.is_like= 1;
           postinfo.post.like_count= likedata[0].countData;
          }
          else
          {
           postinfo.post.is_like= 0;
           postinfo.post.like_count= 0;
          }
         
         resolve(postinfo);
        });
         })
         }).then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post',"id='" + postelement.id + "' AND user_id='"+req.body.user_id+"' AND pin_status='1'" ,function(err,postpindata){
          if(postpindata[0].countData >0)
          {
          postinfo.post.is_pin= 1;
          }
          else
          {
           postinfo.post.is_pin= 0;
          }
         
         resolve(postinfo);
        });
         })
         })
        .catch(function(error) {
          console.log(' -- error: ', error);
          res.send({
              "error":true,
              "status": 400,
              "message": 'some error'
          });
          return error.message;
      })
      },Promise.resolve(null)).then(arrayOfResults => { // Do something with all results
        
        
    
        contestData[0].total_post=0;
        contestData[0].post=[];
        contestData[0].total_post=arrayOfResults.length;
        contestData[0].post=arrayOfResults;

        res.send({
            "error": false,
            "status": 200,
            "message": 'Contest Info',
            "data":contestData[0]
        });

    });
     }
     else
     {
      
        contestData[0].total_post=0;
        contestData[0].post=[];
        
       

        res.send({
            "error": false,
            "status": 200,
            "message": 'Contest Info',
            "data":contestData[0]
        });
     } 
    });


        
     }
    
     
  }
};



exports.addContestPost = async function(req,res){
var form = new formidable.IncomingForm();
 form.parse(req, function (err, fields, files) {
  var oldpath = files.filetoupload.path;
    var new_contest_post = new contest(fields);
   if(!new_contest_post.post_desc){
   res.send({
            "error":false,
            "status": 400,
            "message": 'Please provide post description.'
        });
        }
else{
    Common.getallDataWhere('contest_post',{'contest_id':new_contest_post.contest_id,'user_id':new_contest_post.user_id},function(err,result){
    if(result.length==0){  
    var newpath = constant.BASE_PATH+'contest_post/'+Date.now()+path.extname(files.filetoupload.name);
    fs.rename(oldpath, newpath, function (err) {
        if (err) throw err;
          // console.log(err);
          // res.status(200).send({ error:true, message: 'Done' });
     
      });
     new_contest_post.post_img   = Date.now()+path.extname(files.filetoupload.name);
     Common.insert('contest_post',new_contest_post, function(err, pet) {
    if(err)
      res.send(err);
     res.send({
            "error":false,
            "status": 200,
            "message": 'Contest Post added successfull.'
        });
    });
    }
    else
    {
      res.send({"error":true,"status":400,"message":'You are already part of this contest.'});
    }
  });
   }

 });   
};


exports.getContestInfo = async function(req,res){
  if(!req.body.contest_id)
 {
          res.send({
          "error":true,
          "status": 400,
          "message": 'Please provide contest_id.'
      });
  }
  else
  {
     var contestData = await contest.getcontestInfo(req.body.contest_id,req.body.user_id);
     if(contestData.length==0) {
        
      res.send({
            "error": true,
            "status": 400,
            "message": 'No Group Found.'
        });
     }
     else { 
      
      Postdata.getContestPost({"user_id":req.body.user_id,"post_cat":"","pet_id":"","contest_id":req.body.contest_id,"search_data":"","short_by":""},function(err,postinfo){
      if(err)
      res.send(err)
    if(postinfo.length>0){
      postinfo.reduce(function(promiesRes,postelement,index){
       return promiesRes 
        .then(function(data){
        return new Promise(function(resolve, reject) {
         User.getPostData(postelement.id,function(err,postdata){
         postelement.img =postdata;
         postinfo.post=postelement;
         resolve(postinfo);
        });
         })
         })
          .then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post_comment','post_id=' + postelement.id ,function(err,postCommentdata){
          postinfo.post.comment_count= postCommentdata[0].countData;
         resolve(postinfo);
        });
         })
        })
        
         .then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post_share','post_id=' + postelement.id ,function(err,postsharedata){
          postinfo.post.share_count= postsharedata[0].countData;
         
         
         resolve(postinfo);
        });
         })
         }).then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post_saved',"post_id='" + postelement.id + "' AND user_id='"+req.body.user_id+"'" ,function(err,postsavedata){
          if(postsavedata[0].countData >0)
          {
          postinfo.post.is_saved= 1;
          }
          else
          {
           postinfo.post.is_saved= 0;
          }
         
         resolve(postinfo);
        });
         })
         }).then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getRatingCount('contest_rating'," contest_post_id="+postelement.id+" AND user_id="+req.body.user_id+" " ,function(err,likedata){
          console.log(likedata.length)
          if(likedata[0].countData !='0')
          {
          postinfo.post.is_like= 1;
          //postinfo.post.like_count= likedata[0].countData;
          }
          else
          {
           postinfo.post.is_like= 0;
           //postinfo.post.like_count= 0;
          }
         
         resolve(postinfo);
        });
         })
         }).then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post',"id='" + postelement.id + "' AND user_id='"+req.body.user_id+"' AND pin_status='1'" ,function(err,postpindata){
          if(postpindata[0].countData >0)
          {
          postinfo.post.is_pin= 1;
          }
          else
          {
           postinfo.post.is_pin= 0;
          }
         
         resolve(postinfo);
        });
         })
         })
        .catch(function(error) {
          console.log(' -- error: ', error);
          res.send({
              "error":true,
              "status": 400,
              "message": 'some error'
          });
          return error.message;
      })
      },Promise.resolve(null)).then(arrayOfResults => { // Do something with all results
        
        
    
        contestData[0].total_post=0;
        contestData[0].post=[];
        contestData[0].total_post=arrayOfResults.length;
        contestData[0].post=arrayOfResults;

        res.send({
            "error": false,
            "status": 200,
            "message": 'Contest Info',
            "data":contestData[0]
        });

    });
     }
     else
     {
      
        contestData[0].total_post=0;
        contestData[0].post=[];
        
       

        res.send({
            "error": false,
            "status": 200,
            "message": 'Contest Info',
            "data":contestData[0]
        });
     } 
    });


        
     }
    
     
  }
};



exports.addContestPost = async function(req,res){
var form = new formidable.IncomingForm();
 form.parse(req, function (err, fields, files) {
  var oldpath = files.filetoupload.path;
    var new_contest_post = new contest(fields);
   if(!new_contest_post.post_desc){
   res.send({
            "error":false,
            "status": 400,
            "message": 'Please provide post description.'
        });
        }
else{
    Common.getallDataWhere('contest_post',{'contest_id':new_contest_post.contest_id,'user_id':new_contest_post.user_id},function(err,result){
    if(result.length==0){  
    var newpath = constant.BASE_PATH+'contest_post/'+Date.now()+path.extname(files.filetoupload.name);
    fs.rename(oldpath, newpath, function (err) {
        if (err) throw err;
          // console.log(err);
          // res.status(200).send({ error:true, message: 'Done' });
     
      });
     new_contest_post.post_img	 = Date.now()+path.extname(files.filetoupload.name);
     Common.insert('contest_post',new_contest_post, function(err, pet) {
    if(err)
      res.send(err);
     res.send({
            "error":false,
            "status": 200,
            "message": 'Contest Post added successfull.'
        });
    });
    }
    else
    {
      res.send({"error":true,"status":400,"message":'You are already part of this contest.'});
    }
  });
   }

 });   

};






