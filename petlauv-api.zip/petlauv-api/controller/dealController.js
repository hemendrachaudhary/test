var Deals = require('../model/dealModel.js');
var Common = require('../model/commonModel.js');
var formidable = require('formidable');
var md5 = require('md5');
var fs = require('fs');
var path = require('path');
var constant = require('../config/constant.js');


 exports.get_activeDeals = function(req, res) {
 	
if(!req.body.user_id)
{
   res.send({
    "error":true,
    "status": 400,
    "message": 'Please provide user id.'
   });
}
else
{
 Common.checkUser(req.body.user_id,function(err,userData){
if(userData.length>0)
{
 Deals.getActiveDeals(function(err,dealData){
 if(dealData.length>0){
 	 
 res.send({
    "error":false,
    "status": 200,
    "message": 'Deal data.',
    "data": dealData
   });
  }
  else
  {
   res.send({
    "error":true,
    "status": 400,
    "message": 'No deal found.'
   });
  }
 });
}
else
{
  res.send({
    "error":true,
    "status": 400,
    "message": 'User Not Active please contact to admin.'
   });
}
 });	
}
};


exports.get_pastDeals = function(req, res) {
 	
if(!req.body.user_id)
{
   res.send({
    "error":true,
    "status": 400,
    "message": 'Please provide user id.'
   });
}
else
{
 Common.checkUser(req.body.user_id,function(err,userData){
if(userData.length>0)
{
 Deals.getExpiredDeals(function(err,dealData){
 if(dealData.length>0){
 	 
 res.send({
    "error":false,
    "status": 200,
    "message": 'Deal data.',
    "data": dealData
   });
  }
  else
  {
   res.send({
    "error":true,
    "status": 400,
    "message": 'No deal found.'
   });
  }
 });
}
else
{
  res.send({
    "error":true,
    "status": 400,
    "message": 'User Not Active please contact to admin.'
   });
}
 });	
}
};

