var Postdata = require('../model/postModel.js');
var Common = require('../model/commonModel.js');
var formidable = require('formidable');
var User = require('../model/appModel.js');
var chat = require('../model/chatModel.js');
var _ = require('lodash');

var fcmNotifi = require('../model/fcmNotificationModel.js');

var fs = require('fs');
var path = require('path');
var constant = require('../config/constant.js');


exports.create_a_post = function(req, res) {
  var form = new formidable.IncomingForm(),
    files = [],
    insId='';
    fields = [];
    postType = '';
   var promise1 = new Promise(function(resolve, reject) {
    form.parse(req, (err, fields, files) =>
  {
      var new_post = new Postdata(fields);
      postType = fields.post_type;
      if(fields.group_id!=""){
      new_post.group_id = fields.group_id;
      }
      if(new_post.group_admin_aproove==undefined)
      {
        new_post.group_admin_aproove=0;
      }
       if(new_post.group_id==undefined)
      {
        new_post.group_id=0;
      }
       if(fields.contest_id!=""){
      new_post.contest_id = fields.contest_id;
      }
      else
      {
       new_post.contest_id = 0; 
      }
      console.log(fields);
      Common.insert('post',new_post, function(err, user) {
       if(err)
       {
       
        res.send({
            "error":false,
            "status": 400,
            "message": 'Some thing went wrong please try after some time.'
        });
       }else
       {
        insId = user.insertId;
        resolve(form);
       }
      
     });
  });
    });

    form.on('field', function(field, value) {
        fields.push([field, value]);
    })
    promise1.then(function(form) {
      for(var k=0;k<form.openedFiles.length;k++)
      {      
          var oldpath = form.openedFiles[k].path;
         var  newfname =k+Date.now()+path.extname(form.openedFiles[k].name);
     var newpath = constant.BASE_PATH+'post/'+newfname;
    fs.rename(oldpath, newpath, function (err) {
        if (err) throw err;
        
     
      });  


    
    var sdata = {'post_id':insId,'post_type':postType,'post_data_url':newfname,'updated_at':Date.now(),'created_at': Date.now()}
     Common.insert('post_data',sdata, function(err, user) {
    
     });
    }
  
   
    });
    promise1.then(function(form) {
       res.send({
            "error":false,
            "status": 200,
            "message": 'done'
        });
    }).
     catch(function () { 
        res.send({
            "error":true,
            "status": 400,
            "message": 'Please try again'
        });
    }); 
   
};


exports.get_post_type = function(req,res){
  Postdata.getPostType(function(err,postcategory){
      if(err)
      res.send(err)
    if(postcategory.length>0){
      res.send({
          "error":false,
          "status": 200,
          "message": 'Post category data.',
          "data" : postcategory
      });
     }
     else
     {
      res.send({
          "error":false,
          "status": 400,
          "message": 'No data found.',
      });
     } 
    });
  
};


exports.post_saved = function(req, res) {
 if(!req.body.user_id || !req.body.post_id)
 {
          res.send({
          "error":true,
          "status": 400,
          "message": 'Please provide post and user.'
      });
  }
   else
   {

    req.body.updated_at = Date.now();
    req.body.created_at = Date.now();
    Common.checkUser(req.body.user_id,function(err,userData){
    if(userData.length>0){ 
    Common.getallDataWhere('post_saved',{'user_id':req.body.user_id,'post_id':req.body.post_id},function(err,result){
    if(result.length==0){  
    Common.insert('post_saved',req.body,function(err,postSaved){
    {
      if(err)
      res.send(err);
      res.send({"error":false,"status":200,"message":'Post saved successfull.','is_saved':1});  
    }
   });
  }
    else
    {
      Postdata.deleteSavedPost(req.body.user_id,req.body.post_id,function(err,postSavedRemove){
       if(err)
      res.send(err);
      res.send({"error":false,"status":200,"message":'Post unsaved successfull.','is_saved':0});  
      });
    }
  });
 }
 else
 {
  res.send({"error":true,"status":2,"message":'User not active please contact to admin.'});
 }
 });   
   
 }
};

exports.post_pin = function(req, res) {
 if(!req.body.user_id || !req.body.post_id)
 {
          res.send({
          "error":true,
          "status": 400,
          "message": 'Please provide post and user.'
      });
  }
   else
   {

    req.body.updated_at = Date.now();
    req.body.created_at = Date.now();
    Common.checkUser(req.body.user_id,function(err,userData){
    if(userData.length>0){ 
    Common.getallDataWhere('post',{'user_id':req.body.user_id,'id':req.body.post_id},function(err,result){
    if(result.length==0){  
    Common.update('post',{'user_id':req.body,'id':req.body.post_id},{'pin_status':1},function(err,postPin){
    {
      if(err)
      res.send(err);
      res.send({"error":false,"status":200,"message":'Post pin successfull.','is_saved':1});  
    }
   });
  }
    else
    {
      Common.update('post',{'user_id':req.body,'id':req.body.post_id},{'pin_status':1},function(err,postPinRemove){
       if(err)
      res.send(err);
      res.send({"error":false,"status":200,"message":'Post unpin successfull.','is_saved':0});  
      });
    }
  });
 }
 else
 {
  res.send({"error":true,"status":2,"message":'User not active please contact to admin.'});
 }
 });   
   
 }
};

exports.get_stories = function(req,res){
  if(!req.body.user_id)
 {
          res.send({
          "error":true,
          "status": 400,
          "message": 'Please provide post and user.'
      });
  }
  else
  {

   Postdata.getAllpost(req.body,function(err,postinfo){
      if(err)
      res.send(err)
    if(postinfo.length>0){

      postinfo.reduce(function(promiesRes,postelement,index){
       return promiesRes 
        .then(function(data){
        return new Promise(function(resolve, reject) {
         User.getPostData(postelement.id,function(err,postdata){
         postelement.img =postdata;
         postinfo.post=postelement;
         resolve(postinfo);
        });
         })
         })
          .then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post_comment','post_id=' + postelement.id ,function(err,postCommentdata){
          postinfo.post.comment_count= postCommentdata[0].countData;
         resolve(postinfo);
        });
         })
        })
        //.then(function(data){
        // return new Promise(function(resolve, reject) {
        //  Common.getCount('post_like','post_id=' + postelement.id ,function(err,postLikedata){
        //   postinfo.post.like_count= postLikedata[0].countData;
         
         
        //  resolve(postinfo);
        // });
        //  })
        //  })
         .then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post_share','post_id=' + postelement.id ,function(err,postsharedata){
          postinfo.post.share_count= postsharedata[0].countData;
         
         
         resolve(postinfo);
        });
         })
         }).then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post_saved',"post_id='" + postelement.id + "' AND user_id='"+req.body.user_id+"'" ,function(err,postsavedata){
          if(postsavedata[0].countData >0)
          {
          postinfo.post.is_saved= 1;
          }
          else
          {
           postinfo.post.is_saved= 0;
          }
         
         resolve(postinfo);
        });
         })
         }).then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post_like',"post_id='" + postelement.id + "' AND user_id='"+req.body.user_id+"'" ,function(err,likedata){
          if(likedata[0].countData >0)
          {
          postinfo.post.is_like= 1;
          }
          else
          {
           postinfo.post.is_like= 0;
          }
         
         resolve(postinfo);
        });
         })
         }).then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post',"id='" + postelement.id + "' AND user_id='"+req.body.user_id+"' AND pin_status='1'" ,function(err,postpindata){
          if(postpindata[0].countData >0)
          {
          postinfo.post.is_pin= 1;
          }
          else
          {
           postinfo.post.is_pin= 0;
          }
         
         resolve(postinfo);
        });
         })
         })
        .catch(function(error) {
         
          res.send({
              "error":true,
              "status": 400,
              "message": 'some error'
          });
          return error.message;
      })
      },Promise.resolve(null)).then(arrayOfResults => { // Do something with all results
        res.send({
           "error":false,
            "status": 200,
            "message": 'User data',
            'data' : arrayOfResults
        });

    });
     }
     else
     {
      res.send({
          "error":false,
          "status": 400,
          "message": 'No data found.',
      });
     } 
    });
  }
  
  
};


exports.post_like =async function(req, res) {
 if(!req.body.user_id || !req.body.post_id)
 {
          res.send({
          "error":true,
          "status": 400,
          "message": 'Please provide user and post.'
      });
  }
   else
   {
    req.body.updated_at = Date.now();
    req.body.created_at = Date.now();
    Common.checkUser(req.body.user_id,function(err,userData){
     if(userData.length>0)
     {
    Common.getallDataWhere('post_like',{'user_id':req.body.user_id,'post_id':req.body.post_id},function(err,result){
    if(result.length==0){  
    Common.insert('post_like',req.body,async function(err,postLike){
    {
      if(err)
      res.send(err);
      res.send({"error":false,"status":200,"message":'Post like successfull.','is_like':1,'reaction_code':req.body.reaction_code});  
      var postdetail = await chat.getPostDateails(req.body.post_id);
      var postuser = await chat.getUserDateails(postdetail[0].user_id);
      if(req.body.user_id != postdetail[0].user_id){
      if(postdetail[0].contest_id!=0){
              fcmNotifi.pushnotification('PETLUAV',userData[0].full_name +' has reacted  on your Post', postuser[0].device_token, '1009');
              chat.saveNotification(req.body.user_id,postdetail[0].user_id,req.body.post_id,0,'like',' has reacted  on your post.','1009');
	    }
	    else if(postdetail[0].group_id!=0)
	    {
	           fcmNotifi.pushnotification('PETLUAV',userData[0].full_name +' has reacted  on your Post', postuser[0].device_token, '1002');
	          chat.saveNotification(rreq.body.user_id,postdetail[0].user_id,req.body.post_id,0,'like',' has reacted  on your post.','1002');
	       
	    }
	    else
	    {
	         fcmNotifi.pushnotification('PETLUAV',userData[0].full_name +' has reacted  on your post', postuser[0].device_token, '1001');
	              chat.saveNotification(req.body.user_id,postdetail[0].user_id,req.body.post_id,0,'like',' has reacted  on your post.','1001');
	    }
      }
	    }

   });
  }
    else
    {
      if(req.body.reaction_code=='0'){
      Postdata.deleteLike(req.body.user_id,req.body.post_id,function(err,postLikeRemove){
       if(err)
      res.send(err);
      res.send({"error":false,"status":200,"message":'Post dislike successfull.','is_like':0,'reaction_code':req.body.reaction_code});  
      });
    }
   
   else
   {
   	Common.update('post_like',{'post_id':req.body.post_id,"user_id":req.body.user_id}, {'reaction_code':req.body.reaction_code,'updated_at':req.body.updated_at,'created_at':req.body.created_at}, function(err, postReaction) {
    res.send({"error":false,"status":200,"message":'Post like successfull.','is_like':2,'reaction_code':req.body.reaction_code});
     });
   }
}
  });
 
     }
     else
     {
        res.send({"error":true,"status":400,"message":'User not active please contact to admin.'});
     } 
    
});    
 }
};

exports.post_comment = function(req, res) {
    if (!req.body.user_id || !req.body.post_id || !req.body.comment) {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please provide user and post and comment.'
        });
    } else {
        req.body.updated_at = Date.now();
        req.body.created_at = Date.now();
        Common.checkUser(req.body.user_id, function(err, userData) {
            if (userData.length > 0) {
                Common.insert('post_comment', req.body,async function(err, postLike) {
                    {
                        if (err)
                            res.send(err);
                        res.send({
                            "error": false,
                            "status": 200,
                            "message": 'Post comment successfull.'
                        });
                       var postdetail = await chat.getPostDateails(req.body.post_id);
                       var postuser = await chat.getUserDateails(postdetail[0].user_id);
                       if(postdetail[0].user_id != req.body.user_id){
                        if(postdetail[0].contest_id!=0) {
                                fcmNotifi.pushnotification('PetLUAV',userData[0].full_name +' commented on your contest Post', postuser[0].device_token, '1008');
                                chat.saveNotification(req.body.user_id,postdetail[0].user_id,req.body.post_id,0,'comment',' commented on your contest Post!','1008');
                      }
                      else if(postdetail[0].group_id!=0)
                      {
                             fcmNotifi.pushnotification('PetLUAV',userData[0].full_name +' commented on your group Post', postuser[0].device_token, '1007');
                            chat.saveNotification(req.body.user_id,postdetail[0].user_id,req.body.post_id,postdetail[0].group_id,'comment',' commented on your Post!','1007');
                         
                      }
                      else
                      {
                           fcmNotifi.pushnotification('PetLUAV',userData[0].full_name +' commented on your Post', postuser[0].device_token, '1006');
                                chat.saveNotification(req.body.user_id,postdetail[0].user_id,req.body.post_id,0,'comment',' commented on your Post!','1006');
                      }
                     } 
                  }
                });


            } else {
                res.send({
                    "error": true,
                    "status": 400,
                    "message": 'User not active please contact to admin.'
                });
            }

        });
    }
};


exports.post_comment_like = function(req, res) {
    if (!req.body.user_id || !req.body.post_comment_id) {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please provide user and comment.'
        });
    } else {
        req.body.updated_at = Date.now();
        req.body.created_at = Date.now();
        Common.checkUser(req.body.user_id, function(err, userData) {
            if (userData.length > 0) {

                Common.getallDataWhere('post_comment_favourite', {
                    'user_id': req.body.user_id,
                    'post_comment_id': req.body.post_comment_id
                }, function(err, result) {
                    if (result.length == 0) {
                        Common.insert('post_comment_favourite', req.body, function(err, postCommentFav) {
                            {
                                if (err)
                                    res.send(err);
                                res.send({
                                    "error": false,
                                    "status": 200,
                                    "message": 'Comment like successfull.',
                                    'is_like': 1
                                });
                            }
                        });
                    } else {
                        Postdata.deleteCommentLike(req.body.user_id, req.body.post_comment_id, function(err, postCommentFavRemove) {
                            if (err)
                                res.send(err);
                            res.send({
                                "error": false,
                                "status": 200,
                                "message": 'Comment dislike successfull.',
                                'is_like': 0
                            });
                        });
                    }
                });

            } else {
                res.send({
                    "error": true,
                    "status": 400,
                    "message": 'User not active please contact to admin.'
                });
            }

        });
    }
};



exports.get_post_comment = function(req, res) {
    if (!req.body.user_id || !req.body.post_id) {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please provide user and post.'
        });
    } else {

        Common.checkUser(req.body.user_id, async function(err, userData) {
            if (userData.length > 0) {
                var commentData = await Postdata.getParentPost(req.body.post_id);
                if (commentData.length > 0) {
                    commentData.reduce(function(promiesRes, postCommentement, index) {
                        return promiesRes
                            .then(function(data) {
                                return new Promise(function(resolve, reject) {
                                    Postdata.getSubComment(postCommentement.id, async function(err, postCommentdata) {
                                       var subCommentdataInfo = [];
                                       for (const subCommentdata of postCommentdata) {
                                          var contents = await Postdata.getSubCommentLike(subCommentdata.id,req.body.user_id);
                                          if(contents.length>0)
                                          {
                                             subCommentdata.is_like=1; 
                                          }
                                          else
                                          {
                                            subCommentdata.is_like=0;
                                          } 
                                          subCommentdataInfo.push(subCommentdata); 
                                        }
                                        postCommentement.subComment = subCommentdataInfo;
                                      resolve(commentData);
                                    });
                                })
                            }).then(function(data) {
                                return new Promise(function(resolve, reject) {
                                    Common.getCount('post_comment_favourite', "post_comment_id='" + postCommentement.id + "' AND user_id='" + req.body.user_id + "'", function(err, commentLikedata) {
                                        if (commentLikedata[0].countData > 0) {
                                            postCommentement.is_like = 1;
                                        } else {
                                            postCommentement.is_like = 0;
                                        }

                                        resolve(commentData);
                                    });
                                })
                            })
                            .catch(function(error) {
                               
                                res.send({
                                    "error": true,
                                    "status": 400,
                                    "message": 'some error'
                                });
                                return error.message;
                            })
                    }, Promise.resolve(null)).then(arrayOfResults => { // Do something with all results
                        res.send({
                            "error": false,
                            "status": 200,
                            "message": 'Post comment.',
                            'data': arrayOfResults
                        });

                    });



                } else {
                    res.send({
                        "error": false,
                        "status": 400,
                        "message": 'No data found.'
                    });
                }


            } else {
                res.send({
                    "error": true,
                    "status": 400,
                    "message": 'User not active please contact to admin.'
                });
            }

        });
    }
};

exports.create_a_group = function(req, res) {
 var form = new formidable.IncomingForm();
 form.parse(req, function (err, fields, files) {
  var oldpath = files.filetoupload.path;
    //var new_pet = new Pet(fields);
   if(fields.group_admin_user_id==""){
   res.send({
            "error":false,
            "status": 400,
            "message": 'Please provide admin user,group name and image.'
        });
        }
else{
    Common.checkUser(fields.group_admin_user_id, function(err, userData) {
      if (userData.length > 0){
      Postdata.checkPostGroup(fields.group_name,async function(err,groupData){
     if(groupData.length == 0){
     var currentTime =  Date.now();
    var newpath = constant.BASE_PATH+'post_group/'+currentTime+path.extname(files.filetoupload.name);
    fs.rename(oldpath, newpath, function (err) {
        if (err) throw err;
        
      });
     fields.group_img = currentTime+path.extname(files.filetoupload.name);
     fields.updated_at = Date.now();
     fields.created_at = Date.now();
     Common.insert('groups',fields,async function(err, groupData) {
     	
    if(err)
      res.send(err);
     	var friends_id = fields.friends_id;
        friends_idarr=friends_id.split(',');
  	 for(h=0;h<friends_idarr.length;h++)
      {

      var userData = await chat.getUserDateails(fields.group_admin_user_id);
      var inviteddata = await chat.getUserDateails(friends_idarr[h]);

      if (fields.privacy==0) 
      {
  			if (inviteddata.length>0) 
  			{
  				fcmNotifi.pushnotification('PetLUAV',userData[0].full_name +' Invited you to join group', inviteddata[0].device_token, '1010');
  			}
				chat.saveNotification(fields.group_admin_user_id,friends_idarr[h],0,groupData.insertId,'invited you to join the public group',' invited you to join the public group','1010');

      }
      else
      {
      		if (inviteddata.length>0) 
  			{
  				fcmNotifi.pushnotification('PetLUAV',userData[0].full_name +' Invited you to join group', inviteddata[0].device_token, '1010');
  			}
				chat.saveNotification(fields.group_admin_user_id,friends_idarr[h],0,groupData.insertId,'invited you to join the private group',' invited you to join the private group','1010');

      }
  	  // if(fields.privacy==0)  {
  	 	
       
     
     //  if(inviteddata.length>0)
     //  {
     //  fcmNotifi.pushnotification('PetLUAV',userData[0].full_name +' added to public group', inviteddata[0].device_token, '1012');
     //   }
     //    chat.saveNotification(fields.group_admin_user_id,friends_idarr[h],groupData.insertId,'added to public group ',' added to public group','1012');
     //     Common.insert('group_members',{"user_id":friends_idarr[h],"group_id":groupData.insertId,"updated_at":Date.now(),
     //                "created_at":Date.now()}, function(err, groupmemeber) {
                           
     //                        });
  			// 	   }
  			// 	   else
  			// 	   {
  			// 	   	 if(inviteddata.length>0)
     //  {
     //  fcmNotifi.pushnotification('PetLUAV',userData[0].full_name +'Invited you to join group', inviteddata[0].device_token, '1010');
     //   }
     //    chat.saveNotification(fields.group_admin_user_id,friends_idarr[h],groupData.insertId,'invited you to join the private group',' invited you to join the private group','1010');
  			// 	   }
  				}
     res.send({
            "error":false,
            "status": 200,
            "message": 'Group created successfull.'
        });
    });
    }
    else
    {
     res.send({
            "error":false,
            "status": 400,
            "message": 'Group name already exits.'
        });
    }
    });
    }
    else
    {
      res.send({
      "error":false,
      "status": 2,
      "message": 'User not active please contact to admin.'
      });
    } 
   });
 }
 });

};

exports.getNotification =async function(req,res)
{
	 if (req.body.user_id=="") {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please provide user.'
        });
    }
    else
    {

    	var notificationss = await chat.getNotification(req.body.user_id);
    	
    	if(notificationss.length > 0)
       {
        res.send({
        "error":false,
        "status": 200,
        "message": 'Notification',
        "data": notificationss
        });
       }
       else
       {
        res.send({
        "error":true,
        "status": 400,
        "message": 'Data not found.'
        });
       }
    }	
}
exports.get_all_group= function(req, res)
{
 if (req.body.user_id=="") {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please provide user.'
        });
    }
    else
    {
      Common.checkUser(req.body.user_id, async function(err, userData){
      if(userData.length > 0)
      {
       var postGroup = await Postdata.getPostGroup(req.body.user_id);
        if(postGroup.length > 0)
       {
        res.send({
        "error":false,
        "status": 200,
        "message": 'Post group data.',
        "data": postGroup
        });
       }
       else
       {
        res.send({
        "error":false,
        "status": 400,
        "message": 'Data not found.'
        });
       }
      }
      else
      {
      res.send({
      "error":false,
      "status": 2,
      "message": 'User not active please contact to admin.'
      });
      }
    });
 }
};


exports.inviteToGroup = async function(req, res)
{
 if (req.body.user_id=="" || req.body.user_id==undefined || req.body.group_id=="" || req.body.group_id==undefined  ) {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please provide user id ,Group id.'
        });
    }
    else {
        var groupInfo = await chat.getgroupbyid(req.body.group_id,req.body.user_id);
    var friends_id = req.body.friends_id;
        friends_idarr=friends_id.split(',');
  	 for(h=0;h<friends_idarr.length;h++)
      {
      
      var userData = await chat.getUserDateails(req.body.user_id);
      var inviteddata = await chat.getUserDateails(friends_idarr[h]);

       if (groupInfo[0].privacy==0) 
      {
  			if (inviteddata.length>0) 
  			{
  				fcmNotifi.pushnotification('PetLUAV',userData[0].full_name +' Invited you to join group', inviteddata[0].device_token, '1010');
  			}
				chat.saveNotification(req.body.user_id,friends_idarr[h],0,req.body.group_id,'invited you to join the public group',' invited you to join the public group','1010');

      }
      else
      {
      		if (inviteddata.length>0) 
  			{
  				fcmNotifi.pushnotification('PetLUAV',userData[0].full_name +' Invited you to join group', inviteddata[0].device_token, '1010');
  			}
				chat.saveNotification(req.body.user_id,friends_idarr[h],0,req.body.group_id,'invited you to join the private group',' invited you to join the private group','1010');

      }


  	  // if(groupInfo[0].privacy==0)  {
  	 	
     //  if(inviteddata.length>0)
     //  {
     //  fcmNotifi.pushnotification('PetLUAV',userData[0].full_name +' added to public group', inviteddata[0].device_token, '1012');
     //   }
     //    chat.saveNotification(req.body.user_id,friends_idarr[h],req.body.group_id,'added to public group ','added to public group','1012');
      
     //     Common.insert('group_members',{"user_id":friends_idarr[h],"group_id":req.body.group_id,"updated_at":Date.now(),
     //                "created_at":Date.now()}, function(err, groupmemeber) {
     //                       console.log(err);
     //                        });
  			// 	   }
  			// 	   else
  			// 	   {
  			// 	   	 if(inviteddata.length>0)
     //  {
     //  fcmNotifi.pushnotification('PetLUAV',userData[0].full_name +'Invited you to join group', inviteddata[0].device_token, '1010');
     //   }
     //    chat.saveNotification(req.body.user_id,friends_idarr[h],req.body.group_id,'invited you to join the private group',' invited you to join the private group','1010');
  			// 	   }
  				}
     res.send({
            "error": false,
            "status": 200,
            "message": 'User Invited to join group'
        });
  }
}

exports.get_my_group = function(req, res)
{
if (req.body.user_id=="") {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please provide user.'
        });
    }
    else
    {
      Common.checkUser(req.body.user_id, async function(err, userData){
      if(userData.length > 0)
      {
       //var myGroup = await Postdata.getMyGroup(req.body.user_id,req.body.group_name);
       var myjGroup = await Postdata.getMyJionGroup(req.body.user_id);

        var myGroup = await Postdata.getMyGroup(req.body.user_id);
        for(i=0;i<myGroup.length;i++) {
        myjGroup.push(myGroup[i]);

       }
       if(myjGroup.length > 0)
       {
        final_result  = _.uniqBy(myjGroup, 'id');
        res.send({
        "error":false,
        "status": 200,
        "message": 'Post group data.',
        "data": final_result
        });
       }
       else
       {
        res.send({
        "error":false,
        "status": 400,
        "message": 'Data not found.'
        });
       }
      }
      else
      {
      res.send({
      "error":false,
      "status": 2,
      "message": 'User not active please contact to admin.'
      });
      }
    });
 }
};



exports.get_my_joined_group = function(req, res)
{
 if (req.body.user_id=="") {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please provide user.'
        });
    }
    else
    {
      Common.checkUser(req.body.user_id, async function(err, userData){
      if(userData.length > 0)
      {
       //var myGroup = await Postdata.getMyGroup(req.body.user_id,req.body.group_name);
       var myGroup = await Postdata.getMyJionGroup(req.body.user_id);
       if(myGroup.length > 0)
       {
        res.send({
        "error":false,
        "status": 200,
        "message": 'Post group data.',
        "data": myGroup
        });
       }
       else
       {
        res.send({
        "error":false,
        "status": 400,
        "message": 'Data not found.'
        });
       }
      }
      else
      {
      res.send({
      "error":false,
      "status": 2,
      "message": 'User not active please contact to admin.'
      });
      }
    });
 }
};


exports.join_group = function(req, res) {
    if (!req.body.user_id || !req.body.group_id) {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please provide user and post.'
        });
    } else {
        req.body.updated_at = Date.now();
        req.body.created_at = Date.now();
        Common.checkUser(req.body.user_id, function(err, userData) {
            if (userData.length > 0) {
           Common.getallDataWhere('group_members', {'user_id': req.body.user_id,'group_id': req.body.group_id
                },async function(err, result) {
                    if (result.length == 0) {
                      
                        
                        Common.insert('group_members', req.body, function(err, postLike) {
                            {
                                if (err)
                                    res.send(err);
                                res.send({
                                    "error": false,
                                    "status": 200,
                                    "message": 'Group join successfull.',
                                    'is_join': 1
                                });
                            }
                        });
                      
                    } else {
                        Postdata.deleteMember(req.body.user_id, req.body.group_id, function(err, postLikeRemove) {
                            if (err)
                                res.send(err);
                            res.send({
                                "error": false,
                                "status": 200,
                                "message": 'Remove from group.',
                                'is_join': 0
                            });
                        });
                    }
                });

            } else {
                res.send({
                    "error": true,
                    "status": 2,
                    "message": 'User not active please contact to admin.'
                });
            }

        });
    }
};


exports.create_a_group_post = function(req, res) {
 
    var form = new formidable.IncomingForm(),
        files = [],
        insId = '';
    fields = [];
    postType = '';
    var promise1 = new Promise(function(resolve, reject) {
        form.parse(req, (err, fields, files) => {
            var new_post = new Postdata(fields);
            new_post.group_id = fields.group_id;
            postType = fields.post_type;
                        Common.insert('post', new_post, function(err, user) {
                if(err)
       {
        res.send({
            "error":false,
            "status": 400,
            "message": 'Please remove single comma from post description.'
        });
       }else
       {
        insId = user.insertId;
        resolve(form);
       }
            });
        });
    });

    form.on('field', function(field, value) {
        fields.push([field, value]);
    })
    promise1.then(function(form) {
        for (var k = 0; k < form.openedFiles.length; k++) {
            var oldpath = form.openedFiles[k].path;
            var newfname = k + Date.now() + path.extname(form.openedFiles[k].name);
            var newpath = constant.BASE_PATH + 'post/' + newfname;
            fs.rename(oldpath, newpath, function(err) {
                if (err) throw err;


            });



            var sdata = {
                'post_id': insId,
                'post_type': postType,
                'post_data_url': newfname,
                'updated_at': Date.now(),
                'created_at': Date.now()
            }
            Common.insert('post_data', sdata, function(err, user) {

            });
        }


    });
    promise1.then(function(form) {
        res.send({
            "error": false,
            "status": 200,
            "message": 'done'
        });
    }).
    catch(function() {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please try again'
        });
    });

};

exports.get_group_stories = function(req,res){
  if(!req.body.user_id)
 {
          res.send({
          "error":true,
          "status": 400,
          "message": 'Please provide post and user.'
      });
  }
  else
  {

   Postdata.getGroupApprovedPost(req.body,function(err,postinfo){
      if(err)
      res.send(err)
    if(postinfo.length>0){
      postinfo.reduce(function(promiesRes,postelement,index){
       return promiesRes 
        .then(function(data){
        return new Promise(function(resolve, reject) {
         User.getPostData(postelement.id,function(err,postdata){
         postelement.img =postdata;
         postinfo.post=postelement;
         resolve(postinfo);
        });
         })
         })
          .then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post_comment','post_id=' + postelement.id ,function(err,postCommentdata){
          postinfo.post.comment_count= postCommentdata[0].countData;
         resolve(postinfo);
        });
         })
        })
        //.then(function(data){
        // return new Promise(function(resolve, reject) {
        //  Common.getCount('post_like','post_id=' + postelement.id ,function(err,postLikedata){
        //   postinfo.post.like_count= postLikedata[0].countData;
         
         
        //  resolve(postinfo);
        // });
        //  })
        //  })
         .then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post_share','post_id=' + postelement.id ,function(err,postsharedata){
          postinfo.post.share_count= postsharedata[0].countData;
         
         
         resolve(postinfo);
        });
         })
         }).then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post_saved',"post_id='" + postelement.id + "' AND user_id='"+req.body.user_id+"'" ,function(err,postsavedata){
          if(postsavedata[0].countData >0)
          {
          postinfo.post.is_saved= 1;
          }
          else
          {
           postinfo.post.is_saved= 0;
          }
         
         resolve(postinfo);
        });
         })
         }).then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post_like',"post_id='" + postelement.id + "' AND user_id='"+req.body.user_id+"'" ,function(err,likedata){
          if(likedata[0].countData >0)
          {
          postinfo.post.is_like= 1;
          }
          else
          {
           postinfo.post.is_like= 0;
          }
         
         resolve(postinfo);
        });
         })
         }).then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post',"id='" + postelement.id + "' AND user_id='"+req.body.user_id+"' AND pin_status='1'" ,function(err,postpindata){
          if(postpindata[0].countData >0)
          {
          postinfo.post.is_pin= 1;
          }
          else
          {
           postinfo.post.is_pin= 0;
          }
         
         resolve(postinfo);
        });
         })
         })
        .catch(function(error) {
        
          res.send({
              "error":true,
              "status": 400,
              "message": 'some error'
          });
          return error.message;
      })
      },Promise.resolve(null)).then(arrayOfResults => { // Do something with all results
        res.send({
           "error":false,
            "status": 200,
            "message": 'User data',
            'data' : arrayOfResults
        });

    });
     }
     else
     {
      res.send({
          "error":false,
          "status": 400,
          "message": 'No data found.',
      });
     } 
    });
  }
};

exports.get_group_info = async function(req,res){
  if(!req.body.group_id)
 {
          res.send({
          "error":true,
          "status": 400,
          "message": 'Please provide group id and user.'
      });
  }
  else
  {
     var groupData = await chat.getgroupbyid(req.body.group_id,req.body.user_id);
     var groupmemeber= await chat.getgroupmember(req.body.group_id);  
      var memebertype= await chat.checkGroupMemberType(req.body.group_id,req.body.user_id);  


     groupmemeber= _.uniqBy(groupmemeber, 'user_id');
    
     if(groupData.length==0) {
        
      res.send({
            "error": true,
            "status": 400,
            "message": 'No Group Found.'
        });
     }
     else { 
      
      Postdata.getGroupPost({"type":memebertype,"user_id":req.body.user_id,"post_cat":"","pet_id":"","group_id":req.body.group_id,"search_data":"","short_by":""},function(err,postinfo){
      if(err)
      res.send(err)
    if(postinfo.length>0){
      postinfo.reduce(function(promiesRes,postelement,index){
       return promiesRes 
        .then(function(data){
        return new Promise(function(resolve, reject) {
         User.getPostData(postelement.id,function(err,postdata){
         postelement.img =postdata;
         postinfo.post=postelement;
         resolve(postinfo);
        });
         })
         })
          .then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post_comment','post_id=' + postelement.id ,function(err,postCommentdata){
          postinfo.post.comment_count= postCommentdata[0].countData;
         resolve(postinfo);
        });
         })
        })
        
         .then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post_share','post_id=' + postelement.id ,function(err,postsharedata){
          postinfo.post.share_count= postsharedata[0].countData;
         
         
         resolve(postinfo);
        });
         })
         }).then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post_saved',"post_id='" + postelement.id + "' AND user_id='"+req.body.user_id+"'" ,function(err,postsavedata){
          if(postsavedata[0].countData >0)
          {
          postinfo.post.is_saved= 1;
          }
          else
          {
           postinfo.post.is_saved= 0;
          }
         
         resolve(postinfo);
        });
         })
         }).then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post_like',"post_id='" + postelement.id + "' AND user_id='"+req.body.user_id+"'" ,function(err,likedata){
          if(likedata[0].countData >0)
          {
          postinfo.post.is_like= 1;
          }
          else
          {
           postinfo.post.is_like= 0;
          }
         
         resolve(postinfo);
        });
         })
         }).then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post',"id='" + postelement.id + "' AND user_id='"+req.body.user_id+"' AND pin_status='1'" ,function(err,postpindata){
          if(postpindata[0].countData >0)
          {
          postinfo.post.is_pin= 1;
          }
          else
          {
           postinfo.post.is_pin= 0;
          }
         
         resolve(postinfo);
        });
         })
         })
        .catch(function(error) {

          res.send({
              "error":true,
              "status": 400,
              "message": 'some error'
          });
          return error.message;
      })
      },Promise.resolve(null)).then(arrayOfResults => { // Do something with all results
        
        groupData[0].total_member=0;
        groupData[0].groupmemeber=[];
        groupData[0].total_post=0;
        groupData[0].grouppost=[];
        groupData[0].total_member=groupmemeber.length;
        groupData[0].groupmemeber=groupmemeber;
        groupData[0].total_post=arrayOfResults.length;
        groupData[0].grouppost=arrayOfResults;

        res.send({
            "error": false,
            "status": 200,
            "message": 'group Info',
            "data":groupData[0]
        });

    });
     }
     else
     {
       groupData[0].total_member=0;
        groupData[0].groupmemeber=[];
        groupData[0].total_post=0;
        groupData[0].grouppost=[];
        groupData[0].total_member=groupmemeber.length;
        groupData[0].groupmemeber=groupmemeber;
       

        res.send({
            "error": false,
            "status": 200,
            "message": 'group Info',
            "data":groupData[0]
        });
     } 
    });


        
     }
    
     
  }
};
exports.approwDisaprowgrouppost = function(req,res)
{
    if (req.body.user_id=="" || req.body.post_id=="" || req.body.status=="") {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please provide user and group.'
        });
    } 
    else
    {
       Common.update('post',{"id":req.body.post_id},{"group_admin_aproove":req.body.status},function(err,update){
                        if(err)
                        {
                          res.send({
                            "error": true

                            ,
                            "status": 400,
                            "message": "Server not responed try after some time."
                        });
                        }
                        else
                        {
                          res.send({
                            "error": false,
                            "status": 200,
                            "message": 'Post updated.'
                        });
                        } 
                        });

    }
}
exports.contest_post_comment = function(req, res) {
    if (req.body.user_id=="" || req.body.contest_post_id=="" || req.body.comment=="" || req.body.contest_id=="") {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please provide user and post and comment.'
        });
    } else {
        req.body.updated_at = Date.now();
        req.body.created_at = Date.now();
        Common.checkUser(req.body.user_id, function(err, userData) {
            if (userData.length > 0) {
                Common.insert('contest_comment', req.body, function(err, postcommentData) {
                    if(err)
                       {
                         res.send({
                            "error": false,
                            "status": 400,
                            "message": "Server not responed try after some time."
                        });
                       }
                       else
                       {
                        
                        Common.getCount('contest_comment',"contest_id='" + req.body.contest_id + "' AND contest_post_id='" + req.body.contest_post_id + "'",function(err,CommentCount){
                        var comment_count  = CommentCount[0].countData;
                        
                        Common.update('contest_post',{"id":req.body.contest_post_id},{"comment_count":comment_count},function(err,CommentCount){
                        if(err)
                        {
                          res.send({
                            "error": false,
                            "status": 400,
                            "message": "Server not responed try after some time."
                        });
                        }
                        else
                        {
                          res.send({
                            "error": false,
                            "status": 200,
                            "message": 'Post comment successfull.'
                        });
                        } 
                        });
                        });
                      } 
                   
                });
                } else {
                res.send({
                    "error": true,
                    "status": 2,
                    "message": 'User not active please contact to admin.'
                });
            }

        });
    }
};

exports.contest_post_share = function(req, res) {
    if (req.body.user_id=="" || req.body.contest_post_id=="" || req.body.contest_id=="") {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please provide user and post.'
        });
    } else {
        req.body.updated_at = Date.now();
        req.body.created_at = Date.now();
        Common.checkUser(req.body.user_id, function(err, userData) {
            if (userData.length > 0) {
                Common.insert('contest_share', req.body, function(err, postshareData) {
                    if(err)
                       {
                         res.send({
                            "error": false,
                            "status": 400,
                            "message": "Server not responed try after some time."
                        });
                       }
                       else
                       {
                        
                        Common.getCount('contest_share',"contest_id='" + req.body.contest_id + "' AND contest_post_id='" + req.body.contest_post_id + "'",function(err,CommentCount){
                        var share_count  = CommentCount[0].countData;
                        Common.update('contest_post',{"id":req.body.contest_post_id},{"share_count":share_count},function(err,shareCount){
                        if(err)
                        {
                          res.send({
                            "error": false,
                            "status": 400,
                            "message": "Server not responed try after some time."
                        });
                        }
                        else
                        {
                          res.send({
                            "error": false,
                            "status": 200,
                            "message": 'Post share successfull.'
                        });
                        } 
                        });
                        });
                      } 
                });
                } else {
                res.send({
                    "error": true,
                    "status": 2,
                    "message": 'User not active please contact to admin.'
                });
            }

        });
    }
};



exports.post_share = function(req, res) {
    if (req.body.user_id=="" || req.body.post_id=="") {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please provide user and post.'
        });
    } else {
        req.body.updated_at = Date.now();
        req.body.created_at = Date.now();
        Common.checkUser(req.body.user_id, function(err, userData) {
            if (userData.length > 0) {
                Common.insert('post_share', req.body, function(err, postshareData) {
                   if(err)
                       {
                         res.send({
                            "error": false,
                            "status": 400,
                            "message": "Server not responed try after some time."
                        });
                       }
                       else
                       {

                        res.send({
                            "error": false,
                            "status": 200,
                            "message": 'Post share successfull.'
                        });
                      } 
                  
                });
                } else {
                res.send({
                    "error": true,
                    "status": 2,
                    "message": 'User not active please contact to admin.'
                });
            }

        });
    }
};

exports.contest_post_rating = function(req, res) {
    if (req.body.user_id=="" || req.body.contest_post_id=="" || req.body.contest_id=="" || req.body.rating=="") {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please provide user and post.'
        });
    } else {
        req.body.updated_at = Date.now();
        req.body.created_at = Date.now();
        Common.checkUser(req.body.user_id, function(err, userData) {
            if (userData.length > 0) {
            Common.getallDataWhere('contest_rating',{'user_id': req.body.user_id,'contest_post_id': req.body.contest_post_id,'contest_id': req.body.contest_id}, function(err, result) {
                    if (result.length == 0)
                    {
                     Common.insert('contest_rating', req.body, function(err, postshareData) {
                     if(err)
                       {
                         res.send({
                            "error": false,
                            "status": 400,
                            "message": "Server not responed try after some time."
                        });
                       }
                       else
                       {
                        
                        Common.getAvg('contest_rating',"contest_id='" + req.body.contest_id + "' AND contest_post_id='" + req.body.contest_post_id + "'",function(err,ratingCount){
                        var rating_count  = ratingCount[0].avgData;
                        Common.update('contest_post',{"id":req.body.contest_post_id},{"rating_count":rating_count},function(err,shareCount){
                        if(err)
                        {
                          res.send({
                            "error": false,
                            "status": 400,
                            "message": "Server not responed try after some time."
                        });
                        }
                        else
                        {
                          res.send({
                            "error": false,
                            "status": 200,
                            "message": 'Post rating successfull.'
                        });
                        } 
                        });
                        });
                      } 
                   
                });
                    }
                    else
                    {
                     Common.update('contest_rating',{"contest_post_id":req.body.contest_post_id,"contest_id":req.body.contest_id},req.body, function(err, postshareData) {
                     if(err)
                       {
                         res.send({
                            "error": false,
                            "status": 400,
                            "message": "Server not responed try after some time."
                        });
                       }
                       else
                       {
                        
                        Common.getAvg('contest_rating',"contest_id='" + req.body.contest_id + "' AND contest_post_id='" + req.body.contest_post_id + "'",function(err,ratingCount){
                        var rating_count  = ratingCount[0].avgData;
                        Common.update('contest_post',{"id":req.body.contest_post_id},{"rating_count":rating_count},function(err,shareCount){
                        if(err)
                        {
                          res.send({
                            "error": false,
                            "status": 400,
                            "message": "Server not responed try after some time."
                        });
                        }
                        else
                        {
                          res.send({
                            "error": false,
                            "status": 200,
                            "message": 'Post rating successfull.'
                        });
                        } 
                        });
                        });
                      } 
                   
                });
                    }
                });
               } else {
                res.send({
                    "error": true,
                    "status": 2,
                    "message": 'User not active please contact to admin.'
                });
            }

        });
    }
};

exports.singlePost = function(req,res)
{
  if(req.body.post_id=="" || req.body.user_id =="")
  {
    res.send({
            "error": true,
            "status": 400,
            "message": 'Please check All fields.'
        });
  }
  else
  {
    Common.checkUser(req.body.user_id, async function(err, userData){
      if (userData.length > 0){
         var postData = await Postdata.postInfoById(req.body.post_id,req.body.user_id);
         var commentData = await Postdata.getParentPost(req.body.post_id);
         console.log(postData);
         if(postData.length>0)
         {
          postData.reduce(function(promiesRes,postelement,index){
       return promiesRes 
        .then(function(data){
        return new Promise(function(resolve, reject) {
         User.getPostData(postelement.id,function(err,postdata){
         postelement.img =postdata;
         postData.post=postelement;
         resolve(postData);
        });
         })
         }).then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post_saved',"post_id='" + postelement.id + "' AND user_id='"+req.body.user_id+"'" ,function(err,postsavedata){
          if(postsavedata[0].countData >0)
          {
          postData.post.is_saved= 1;
          }
          else
          {
           postData.post.is_saved= 0;
          }
         
         resolve(postData);
        });
         })
         }).then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post_like',"post_id='" + postelement.id + "' AND user_id='"+req.body.user_id+"'" ,function(err,likedata){
          if(likedata[0].countData >0)
          {
          postData.post.is_like= 1;
          }
          else
          {
           postData.post.is_like= 0;
          }
         
         resolve(postData);
        });
         })
         }).then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post',"id='" + postelement.id + "' AND user_id='"+req.body.user_id+"' AND pin_status='1'" ,function(err,postpindata){
          if(postpindata[0].countData >0)
          {
          postData.post.is_pin= 1;
          }
          else
          {
           postData.post.is_pin= 0;
          }
         
         resolve(postData);
        });
         })
         })
        .catch(function(error) {
         
          res.send({
              "error":true,
              "status": 400,
              "message": 'some error'
          });
          return error.message;
      })
      },Promise.resolve(null)).then(arrayOfResults => { // Do something with all results
        if(commentData.lenght>0)
        {
         arrayOfResults.commentData = commentData;
        }
        else
        {
         arrayOfResults.commentData = [];
        }
        res.send({
           "error":false,
            "status": 200,
            "message": 'User data',
            'data' : arrayOfResults[0]
        });

    });


          } else {
          res.send({
              "error": false,
              "status": 400,
              "message": 'No data found.'
          });
      }


       }
      else
      {
        res.send({
        "error": true,
        "status": 2,
        "message": 'User not active please contact to admin.'
        });
      }
  });
  }  
}

exports.searchByName = function(req, res) {
if (!req.body.user_id || !req.body.search_data) {
        res.send({
            "error": true,
            "status": 400,
            "message": 'Please enter search data.'
        });
    }
    else
    {
     
     Common.checkUser(req.body.user_id, async function(err, userData){
      if (userData.length > 0){
       var userData = await Postdata.getUserLike(req.body.user_id,req.body.search_data);
       var petData = await Postdata.getPetLike(req.body.search_data);
       var keyword = await Postdata.getKeywordLike(req.body.search_data);
       var reletedkeyword = await Postdata.getreletedkeyword(keyword,req.body.search_data);
       var searchData = {};
      
       searchData.userData = userData;
       searchData.petData = petData;
       searchData.tags = reletedkeyword;
      
      res.send({
                    "error": true,
                    "status": 200,
                    "message": 'Search Data.',
                    "data" : searchData
                });
      }
      else
      {
        res.send({
                    "error": true,
                    "status": 2,
                    "message": 'User not active please contact to admin.'
                });
      }
     });

    }
  };








