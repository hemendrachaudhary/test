var Pet = require('../model/petModel.js');
var Common = require('../model/commonModel.js');
var formidable = require('formidable');
var fs = require('fs');
var path = require('path');
var constant = require('../config/constant.js');

exports.create_a_pet = function(req, res) {
 var form = new formidable.IncomingForm();
 form.parse(req, function (err, fields, files) {
  var oldpath = files.filetoupload.path;
    var new_pet = new Pet(fields);
   if(!new_pet.pet_name){
   res.send({
            "error":false,
            "status": 400,
            "message": 'Please provide pet.'
        });
        }
else{
   var currentTime = Date.now();
    var newpath = constant.BASE_PATH+'pet/'+currentTime+path.extname(files.filetoupload.name);
    fs.rename(oldpath, newpath, function (err) {
        if (err) throw err;
          // console.log(err);
          // res.status(200).send({ error:true, message: 'Done' });
     
      });
     new_pet.pet_image = currentTime+path.extname(files.filetoupload.name);
     Common.insert('pet_info',new_pet, function(err, pet) {
    if(err)
      res.send(err);
     res.send({
            "error":false,
            "status": 200,
            "message": 'Pet added successfull.'
        });
    });
   
 }
 });   
};


exports.follow_pet = function(req, res) {
 if(!req.body.user_id || !req.body.pet_id)
 {
          res.send({
          "error":true,
          "status": 400,
          "message": 'Please provide pet and user.'
      });
  }
   else
   {
    req.body.updated_at = Date.now();
    req.body.created_at = Date.now();
    Common.getSinglerow('pet_info',"id='" + req.body.pet_id + "' AND user_id='"+req.body.user_id+"'",function(err,petRes){
     if(petRes.length==0){ 
    Common.getallDataWhere('pet_followers',{'user_id':req.body.user_id,'pet_id':req.body.pet_id},function(err,result){
    if(result.length==0){  
    Common.insert('pet_followers',req.body,async function(err,petFollow){
    {
      if(err)
      res.send(err);
      res.send({"error":false,"status":200,"message":'Pet followed.','is_follow':1});  
        var followinguser = await chat.getUserDateails(req.body.user_id);
        var followpetuser = await chat.getUserDateails(petRes[0].user_id);
        if(petRes[0].user_id != req.body.user_id){
        fcmNotifi.pushnotification('PetLUAV',followinguser[0].full_name +' started following your pet!', followpetuser[0].device_token, '1005');
        chat.saveNotification(req.body.user_id,petRes[0].user_id,0,0,'following',' started following your pet!','1005');
      }
    }
   });
  }
    else
    {
      Pet.deletePetFollower(req.body.user_id,req.body.pet_id,function(err,petfollowRemove){
       if(err)
      res.send(err);
      res.send({"error":false,"status":200,"message":'Pet unfollowed.','is_follow':0});  
      });
    }
  });
 }
 else
 {
  res.send({"error":true,"status":400,"message":'You can not follow your pet.'});
 }
  });   
 }
};


 exports.get_pet_info = async function(req,res){
 console.log(req.body)
  if(req.body.pet_id=="" || req.body.user_id=="" )
  {
   res.send({
          "error":true,
          "status": 400,
          "message": 'Please provide pet and user.'
      });
  }
  else
  {
    var  petinfo      = await   Pet.getPetInfo(req.body.pet_id);
    var  petPostCount = await   Pet.getCount('post','pet_id=' + req.body.pet_id);
    var  petViewCount = await   Pet.getCount('view_pet','pet_id=' + req.body.pet_id);
    var  petFollowerCount = await   Pet.getCount('pet_followers','pet_id=' + req.body.pet_id);
    var  petFollower = await   Pet.getCount('pet_followers',"pet_id='" + req.body.pet_id + "' AND user_id='"+req.body.user_id+"'");
    var  postinfo = await Pet.getPostInfo(req.body.pet_id,req.body.user_id);
    var tempData = [];
    

    postinfo.reduce(function(promiesRes,postelement,index){
       return promiesRes 
        .then(function(data){
        return new Promise(function(resolve, reject) {
         Pet.getPostData(postelement.id,function(err,postdata){
         postelement.img =postdata;
         postinfo.post=postelement;
         resolve(postinfo);
        });
         })
         })
          .then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post_comment','post_id=' + postelement.id ,function(err,postCommentdata){
          postinfo.post.comment_count= postCommentdata[0].countData;
         
         
         resolve(postinfo);
        });
         })
         }).then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post_like','post_id=' + postelement.id ,function(err,postLikedata){
          postinfo.post.like_count= postLikedata[0].countData;
         
         
         resolve(postinfo);
        });
         })
         }).then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post_share','post_id=' + postelement.id ,function(err,postsharedata){
          postinfo.post.share_count= postsharedata[0].countData;
         
         
         resolve(postinfo);
        });
         })
         }).then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post_saved',"post_id='" + postelement.id + "' AND user_id='"+req.body.user_id+"'" ,function(err,postsavedata){
          if(postsavedata[0].countData >0)
          {
          postinfo.post.is_saved= 1;
          }
          else
          {
           postinfo.post.is_saved= 0;
          }
         
         resolve(postinfo);
        });
         })
         }).then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post_like',"post_id='" + postelement.id + "' AND user_id='"+req.body.user_id+"'" ,function(err,likedata){
          if(likedata[0].countData >0)
          {
          postinfo.post.is_like= 1;
          }
          else
          {
           postinfo.post.is_like= 0;
          }
         
         resolve(postinfo);
        });
         })
         }).then(function(data){
        return new Promise(function(resolve, reject) {
         Common.getCount('post','id=' + postelement.id ,function(err,postpindata){
          if(postpindata[0].countData >0)
          {
          postinfo.post.is_pin= 1;
          }
          else
          {
           postinfo.post.is_pin= 0;
          }
         
         resolve(postinfo);
        });
         })
         })
        .catch(function(error) {
          console.log(' -- error: ', error);
          res.send({
              "error":true,
              "status": 400,
              "message": 'some error'
          });
          return error.message;
      })
      },Promise.resolve(null)).then(arrayOfResults => { // Do something with all results
        console.log(arrayOfResults);
        if(arrayOfResults!=null)
        {
          if(petinfo.length>0){
        petinfo[0].post = arrayOfResults;
      }
        }
        else
        { 
          console.log(petinfo);
          if(petinfo.length>0){
          petinfo[0].post = [];
        }
        }
        if(petFollower[0].countData>0)
        {
          petinfo[0].is_follow = 1;
        }
        else
        {
          petinfo[0].is_follow = 0;
        }
        petinfo[0].pet_post_count = petPostCount[0].countData;
        petinfo[0].pet_view_count = petViewCount[0].countData;
        petinfo[0].pet_follower_count = petFollowerCount[0].countData;
         res.send({
           "error":false,
            "status": 200,
            "message": 'Pet data',
            'data' : petinfo[0]
        });

    });

  

  
 }
};





exports.get_pet_by_user = function(req,res){
  if(req.body.user_id=="")
  {
    res.send({
          "error":true,
          "status": 400,
          "message": 'Please provide user.'
      });
  }
  else
  {
    Pet.getPetByUser(req.body.user_id,function(err,petData){
      if(err)
      res.send(err)
      if(petData.length>0){
      res.send({
          "error":false,
          "status": 200,
          "message": 'Pet data.',
          "data" : petData
      });
     }
     else
     {
       res.send({
          "error":true,
          "status": 400,
          "message": 'No data dound.',
      });
     } 
    })
  }
};


exports.get_post_category = function(req,res){
  Pet.getPetByUser('post_category',function(err,catData){
      if(err)
      res.send(err)
    if(catData.length>0){
      res.send({
          "error":false,
          "status": 200,
          "message": 'Post category data.',
          "data" : catData
      });
     }
     else
     {
      res.send({
          "error":true,
          "status": 400,
          "message": 'No data found.',
      });
     } 
    });
  
};



exports.get_pet_type = function(req,res){
  Pet.getPetType(function(err,petTypeData){
      if(err)
      res.send(err)
    if(petTypeData.length>0){
      res.send({
          "error":false,
          "status": 200,
          "message": 'Pet type data.',
          "data" : petTypeData
      });
     }
     else
     {
      res.send({
          "error":true,
          "status": 400,
          "message": 'No data found.',
      });
     } 
    });
  
};

exports.get_pet_breed = function(req,res){
  Common.getallDataWhere('breed',{'status':'1'},function(err,breedData){
      if(err)
      res.send(err)
    if(breedData.length>0){
      res.send({
          "error":false,
          "status": 200,
          "message": 'Pet breed data.',
          "data" : breedData
      });
     }
     else
     {
      res.send({
          "error":true,
          "status": 400,
          "message": 'No data found.',
      });
     } 
    });
  
};


exports.view_pet = function(req, res) {
 if(!req.body.user_id || !req.body.pet_id)
 {
          res.send({
          "error":true,
          "status": 400,
          "message": 'Please provide pet and user.'
      });
  }
   else
   {
    req.body.updated_at = Date.now();
    req.body.created_at = Date.now();
    Common.getSinglerow('pet_info',"id='" + req.body.pet_id + "' AND user_id='"+req.body.user_id+"'",function(err,petRes){
     if(petRes.length==0){ 
    Common.getallDataWhere('view_pet',{'user_id':req.body.user_id,'pet_id':req.body.pet_id},function(err,result){
    if(result.length==0){  
    Common.insert('view_pet',req.body,function(err,petView){
    {
      if(err)
      res.send(err);
      res.send({"error":false,"status":200,"message":'Pet view successfull.','is_view':1});  
    }
   });
  }
    else
    {
      res.send({"error":false,"status":400,"message":'Pet alerady view.'});  
    }
  });
 }
 else
 {
  res.send({"error":true,"status":400,"message":'You can not follow your pet.'});
 }
  });   
 }
};


exports.update_a_pet = function(req, res) {
 var form = new formidable.IncomingForm();
 form.parse(req, function (err, fields, files) {
  
 
    var new_pet = new Pet(fields);
   if(!new_pet.pet_name){
   res.send({
            "error":false,
            "status": 400,
            "message": 'Please provide pet.'
        });
        }
else{
  var petData =  {"pet_name":fields.pet_name,"pet_dob":fields.pet_dob,"pet_about":fields.pet_about,"gender":fields.gender};
    Common.checkUser(new_pet.user_id, function(err, userData) {
            if (userData.length > 0) {
    var currentTime = Date.now();
    if(JSON.stringify(files) != '{}')
    {
     var oldpath = files.filetoupload.path;
    var newpath = constant.BASE_PATH+'pet/'+currentTime+path.extname(files.filetoupload.name);
    fs.rename(oldpath, newpath, function (err) {
        if (err) throw err;
          // console.log(err);
          // res.status(200).send({ error:true, message: 'Done' });
     
      });
     petData.pet_image = currentTime+path.extname(files.filetoupload.name);
   }
     
     Common.update('pet_info',{id:fields.pet_id},petData, function(err, pet) {
    if(err)
      res.send(err);
     res.send({
            "error":false,
            "status": 200,
            "message": 'Pet updated successfull.'
        });
    });
   }
   else {
          res.send({
              "error": true,
              "status": 2,
              "message": 'User not active please contact to admin.'
          });
      }
   });  
   
 }
 });   
};


exports.get_near_by_pet = function(req, res) {

   if(!req.body.user_id){
   res.send({
            "error":false,
            "status": 400,
            "message": 'Please check all fields.'
        });
        }
else{
    Common.checkUser(req.body.user_id, function(err, userData) {
    if (userData.length > 0) {
    Pet.nearByPet(req.body.user_id,req.body.lat,req.body.lng,function(err,petData){
      if(petData.length > 0)
      {
        res.send({
            "error":true,
            "status": 200,
            "message": 'Pet data.',
            "data": petData
        });
      }
      else
      {
        res.send({
            "error":true,
            "status": 400,
            "message": 'No data found.'
        });
      }
    })
   }
   else {
          res.send({
              "error": true,
              "status": 2,
              "message": 'User not active please contact to admin.'
          });
      }
   });  
   
 }

};


exports.delete_pet = async function(req,res){
  if(req.body.pet_id=="" || req.body.user_id=="" )
  {
   res.send({
          "error":true,
          "status": 400,
          "message": 'Please provide pet and user.'
      });
  }
  else
  {
    Common.checkUser(req.body.user_id, async function(err, userData) {
    if (userData.length > 0)
    {
    var  petinfo          = await   Pet.deletePetData(req.body.pet_id);
    var  petPostCount     = await   Pet.deletePostData(req.body.pet_id);
    var  petViewCount     = await   Pet.deleteViewData(req.body.pet_id);
    var  petFollowerCount = await   Pet.deletePetFollowerData(req.body.pet_id);
    res.send({
              "error": true,
              "status": 200,
              "message": 'Pet deleted successfull.'
          });
    }
    else
    {
          res.send({
              "error": true,
              "status": 2,
              "message": 'User not active please contact to admin.'
          });
      }

  });
    
  }
 }

 exports.get_all_pet = function(req,res){
  if(req.body.user_id=="")
  {
    res.send({
          "error":true,
          "status": 400,
          "message": 'Please provide user.'
      });
  }
  else
  {
    Pet.get_all_pet(req.body.user_id,function(err,petData){
      if(err)
      res.send(err)
      if(petData.length>0){
      res.send({
          "error":false,
          "status": 200,
          "message": 'Pet data.',
          "data" : petData
      });
     }
     else
     {
       res.send({
          "error":true,
          "status": 400,
          "message": 'No data dound.',
      });
     } 
    })
  }
};
 














